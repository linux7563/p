<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><title>ทำให้ P2P และ B2B การ ชำระ เงิน Perfect Money</title>
<META NAME="Keywords" CONTENT="คุณสมบัติ Perfectmoney, Perfect Money">
<META name="description" content="Perfect Money พบ ระบบ การ ชำระ เงิน ที่ ปลอดภัย ที่สุด และ บริการ ทาง การเงิน ที่ ง่าย ที่สุด ที่ จะ ให้ โอน เงิน ทั่ว โลก. รับ สกุล เงิน โอน เงิน ผ่าน ธนาคาร และ การ ชำระ เงิน SMS ท่าน เว็บไซต์. ทอง ซื้อ ส่ง หรือ รับ เงิน ด้วย โปรเซสเซอร์ ชำระ เงิน ที่ ปลอดภัย มาก ที่สุด ใน อินเทอร์เน็ต ">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/TH.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH" selected>ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">ลง ทะเบียน</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">ล็อกอิน </font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">แลกเปลี่ยน</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tour</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">ช่วยเหลือ</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">ศูนย์ ความ ปลอดภัย</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/th_TH/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/th_TH/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">ล็อกอิน</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>บ้าน</span></a>
								<a href="about.php" class="selectedd"><span>เกี่ยว กับ เรา</span></a>
								<a href="features.php"><span>คุณลักษณะ</span></a>
								<a href="fees.php"><span>ค่าธรรมเนียม</span></a>
								<a href="evoucher-info.php"><span>บัตรกำนัลอิเล็กทรอนิกส์</span></a>
                <a href="guarantees.php"><span>ับประกัน</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>ติดต่อ เรา</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>อัตรา <font color='#F01010'>PM Exchange</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>สำรวจความคิดเห็น</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money:ให้การบริการและสินค้าที่มีคุณภาพ<br><br>
<a href="statistics.php">ตรวจสอบผลปัจจุบัน</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>คำถามที่ถูกถามบ่อย</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">มีค่าใช้จ่ายเท่าไรในการยืนยันบัญชี?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">กระบวนการยืนยันนั้นฟรีอย่างสิ้นเชิง</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">ฉันสามารถถอนเงินของฉันเข้าไปยังบัญชีของคนอื่นได้หรือไม่?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">คุณสามารถถอนเงินของคุณเข้าไปในบัญชีธนาคารใดก็ได้ คุณเพียงแค่ต้องตรวจสอบว่าข้อมูลผู้รับทั้งหมดนั้นถูกต้อง</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4"> คุณสมบัติ</font> <font size="4" color="#F01010">Perfect Money</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">ระบบ Perfect Money ทำงาน กับ ชุด เครื่องมือ ที่ สะดวก ที่สุด ถิ่นฐาน ระหว่าง ลูกค้า.
      <p>ค่า ของ turnovers ยอด รวม ทั้ง ระยะ เวลา การ ลง ทะเบียน ไม่ ส่ง ผล กระทบ ต่อ สิทธิ ประโยชน์ ของ การ ใช้ โอกาส ของ ระบบ. </p>
      <p>ลูกค้า ของ Perfect Money ทุก คน เป็น เรื่อง สำคัญ มาก และ เรา ไม่ ได้ distinctions ใด ๆ ขณะ ที่ ให้ บริการ คุณ. <br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>ลูกค้า สถานะ บุคคล
  </b></font></p>
<p class="txt">เพื่อ ให้ การ ทำ ธุรกรรม ง่าย ขึ้น ทั้ง สอง ฝ่าย Perfect Money divides ผู้ ใช้ ตาม สาม สถานะ ได้ โดย ระบบ ลูกค้า ที่ เสร็จ สิ้น การ ลง ทะเบียน: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      กำหนด ให้ ลูกค้า ที่ จดทะเบียน ใหม่ ทั้งหมด โดย ไม่ ใช้ ข้อ จำกัด ใด ๆ ใน การ ใช้ ระบบ.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      กำหนด ให้ ลูกค้า ที่ ใช้ งาน นาน กว่า 1 ปี หรือ มี มูลค่า ชัดเจน ของ ผล ประกอบ การ ยอด. การ ปรับ รุ่น บัญชี ปกติ  ลูกค้า มี การ ส่ง คำขอ แยก ลูกค้า บริการ. สถานะ เงินรางวัล   ถือว่า จำนวน ของ คณะ กรรมการ ค่า ต่ำ กว่า ลูกค้า ที่ มี สถานะ ปกติ มัก จะ ต้อง จ่าย. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      ได้ รับ มอบหมาย จาก ความ พึง พอใจ ของ Perfect Money การ บริหาร เพื่อ คู่ ค้า เพื่อ เพิ่ม ประสิทธิภาพ การ ชำระ เงิน B2B ของ บริษัท ที่ ทำงาน ธุรกิจ ของ พวก เขา ผ่าน ทาง อินเทอร์เน็ต.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>สถานะการยืนยันของลูกค้า
  </b></font></p>
<p class="txt">เราสนับสนุนให้ลูกค้าของเราในการผ่านขั้นตอนการยืนยันง่าย ๆ โดยการอัปโหลดเอกสารระบุตัวตนที่ออกโดยภาครัฐและให้หมายเลขโทรศัพท์ บัญชีที่ได้รับการยืนยันแล้วจะได้รับการเข้าถึงฟังก์ชันการทำงานบัญชีเต็มรูปแบบ โดยผลประโยชน์บางส่วนรวมถึง: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>ค่าธรรมเนียมที่ต่ำกว่า<br><br>
		ตัวเลือกการรักษาความปลอดภัยเพิ่มเติม<br><br>
		เพิ่มความไว้วางใจให้กับบัญชีของคุณจากลูกค้าคนอื่น <br><br>
		การคืนค่าบัญชีที่ง่ายดาย หากคุณทำรหัสผ่านของคุณสูญหายหรือไม่สามารถเข้าถึงมันได้ไม่ว่าจะด้วยเหตุผลใด ๆ </td>
  </tr>
</table>
<br>
<p>คุณ สามารถ เลือก ย่อย กลุ่ม ของ บัญชี ของ คุณ ขึ้น อยู่ กับ วัตถุประสงค์ และ ผล ประกอบ การ คาด: ส่วน บุคคล สำหรับ การ ใช้ บุคคล หรือ ธุรกิจ . <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>วิธี การ สะดวก และ ง่าย กองทุน บัญชี: </b></font><br>
  <br>
เมื่อ ใช้ ระบบ Perfect Money ลูกค้า ได้ สะดวก และ ง่าย ใน การ ใช้ เครื่องมือ เพื่อ ให้ P2P และ การ ชำระ เงิน P2B. สำหรับ PM การ ชำระ เงิน ของ ลูกค้า สำหรับ ผลิตภัณฑ์ หรือ บริการ ใน การ เปิด อินเทอร์เน็ต ใน การ ทำงาน ง่ายๆ ตาม เวลา ใน การ ทำงาน แทบ จะ ไม่ เกิน 1 วินาที นี้. ขณะ นี้ จะ ไม่ เกิด ปัญหา การ แลกเปลี่ยน ธนบัตร จริง หรือ เสมือน ของ คุณ ลง ใน Perfect Money.   <br>
  <br>
  <b>การ ฝาก เงิน ใน ระบบ สามารถ ดำเนิน การ ดังนี้</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">โอน เงิน ผ่าน ธนาคาร </font></b> <br>
     เป็น วิธี ที่ สะดวก ใน กองทุน บัญชี ของ คุณ. เมื่อ ได้ รับ การ เชื่อถือ โอน เงิน ใน บัญชี PM จะ ทำ ภายใน 30 วินาที. <br>
        <br>
        <b><font color="B01111">สกุล เงิน อิเล็กทรอนิกส์</font> </b><br>
        ระบบ Perfect Money ทำงาน กับ จำนวน มาก ของ สกุล e-และ เหตุ นี้ เงิน บัญชี สามารถ ดำเนิน การ โดย สกุล. รายการ ดัง กล่าว สามารถ ทำงาน โดย อัตโนมัติ ผ่าน ทาง ร้าน ค้า เหล่า นี้ ระบบ การ ชำระ เงิน <br>
        <br>
        <b><font color="B01111">พันธมิตร ตลาดหลักทรัพย์ </font></b><br>
แทน วิธี การ โอน เงิน ใน บัญชี ของ ท่าน อื่น. หลาย สกุล เงิน ของ คู่ ค้า แลกเปลี่ยน นายอำเภอ เงิน และ เวลา ของ พวก เขา เชื่อถือ ได้ พิสูจน์ ได้ เปลี่ยน เงิน ใน บัญชี ระบบ เข้า ทำงาน ง่าย และ ปลอดภัย.
<br>
        <br>
        <b><font color="B01111">จัดเก็บมูลค่าสกุลเงินดิจิทัล </font></b><br>
บัญชี Perfect Money ที่กำหนดในรูปหน่วยค่าเงินในสกุลเงินดิจิทัลคือโอกาสที่ยอดเยี่ยมในการจัดเก็บมูลค่า ซึ่งไม่เหมือนกับกระเป๋าสตางค์สกุลเงินดิจิทัลโดยบัญชี Perfect Money ไม่จำเป็นต้องใช้ความเชี่ยวชาญด้านเทคนิคเพื่อตั้งค่าหรือรักษาความปลอดภัย การจัดเก็บมูลค่าในบัญชี Perfect Money เป็นการสร้างความมั่นใจว่าคุณสามารถเลี่ยงความเสี่ยงที่เกี่ยวข้องกับกระเป๋าสตางค์ที่อาจส่งผลให้เกิดการขาดทุนในสกุลเงินดิจิทัลอย่างถาวร อย่างเช่นความล้มเหลว/การขโมยฮาร์ดแวร์หรือรหัสผ่านหาย ทีม Perfect Money ได้กำจัดความท้าทายของสกุลเงินดิจิทัลในขณะที่ช่วยให้คุณเพลิดเพลินกับความท้าทาย
</p>
    </td>
  </tr>
</table>
<br>
<br>
เพื่อ ความ สะดวก ของ ลูกค้า Perfect เงิน ให้ เป็น ไป ได้ ของ การ ชำระ เงิน ของ บัญชี ที่ มี ชนิด ใด สกุล e-. ใน กรณี นี้ Perfect Money ทันที จะ ดำเนิน ธุรกรรม ใน อัตรา กำไร สูงสุด.
<p>การ ดูแล ลูกค้า แต่ละ ระบบ Perfect Money ดอกเบี้ย ราย เดือน เพื่อ เพิ่ม ยอด เงิน ใน บัญชี ของ ลูกค้า ต่ำ สุด. <br>
เงิน ของ คุณ ทำงาน สำหรับ คุณ ที่ เหลือ คุณ แม้ว่า. </p>
<p>หาก ยอด เงิน ใน บัญชี ไม่ ใช้ โดย ลูกค้า จะ สามารถ ถอนเงิน จาก บัญชี ของ ลูกค้า โดย เครื่องมือ ที่ ใช้ ใน การ ฝาก. </p>
<p>โดย โอน เงิน ผ่าน ธนาคาร ให้ การ แปลง เป็น ชนิด ของ สกุล เงิน และ แลกเปลี่ยน ใด ลูกค้า ของ Perfect Money สามารถ รับ เงิน ได้ ใน เวลา สั้น. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>ฟังก์ชัน การ ทำงาน </b></font><br>
  <br>
สำหรับ ลูกค้า ที่ ดำเนิน ธุรกิจ ที่ เชื่อม ต่อ กับ ระบบ อินเตอร์เน็ต Perfect Money เสนอ แพ็คเกจ ที่ ดี ที่สุด ของ โซลูชัน ทาง ธุรกิจ รวม ทั้ง เครื่องมือ ทำงาน สะดวก ของ ถิ่นฐาน พัฒนา พิเศษ โดย การเงิน PM ขณะ ที่ การ พิจารณา ความ ต้องการ ของ รัฐ-of-ศิลปะ ธุรกิจ IT. <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>สะดวก และ ง่าย รายงาน ราย ละเอียด บัญชี ของ คุณ </strong></font><br>
        ได้ รับ แจ้ง เกี่ยว กับ การ ดำเนิน งาน ทาง การเงิน ใหม่ ให้ ดู แผนภูมิ และ งบ เรี ยล ไท ม์ . </p>
      <p><strong><font color="#990000">ระบบ การ ชำระ เงิน กำเริบ อัตโนมัติ ตั้ง </font></strong><br>
        เครื่องมือ นี้ ถูก ออกแบบ มา เพื่อ จัดการ ค่า ใช้ จ่าย ราย เดือน ของ องค์กร ของ คุณ จะ ช่วย ให้ การ ชำระ เงิน ใน โหมด อัตโนมัติ. </p>
      <p><strong><font color="#990000">ศูนย์ บริการ ลูกค้า บุคคล ของ ธุรกิจ Perfect Money</font></strong><br>
       ลูกค้า งาน สนับสนุน ออนไลน์ 24\7\365 โหมด. ผู้เชี่ยวชาญ ของ เรา พร้อม ที่ จะ ตอบ คำถาม ที่ เป็น ประโยชน์ กับ คุณ ๆ.</p>
      <p><strong><font color="#990000">ผู้ ประกอบ การ ค้า API Perfect</font></strong><br>
ความ คิดเห็น ของ เกณฑ์ ของ ฟังก์ชัน ความ น่า เชื่อถือ และ ความ ปลอดภัย เรา ไม่ คาด หวัง อนาล็อก ของ Perfect Money ใน การ ปรากฏ ใน ไม่ กี่ ปี ถัด ไป. วิศวกร Perfect Money ดัง กล่าว ได้ สร้าง เครื่องมือ ที่ ช่วย ให้ โครงสร้าง ของ ธุรกิจ การ จัด ระเบียบ ใด ๆ ใน กระบวนการ สาย การ ขาย ผลิตภัณฑ์ หรือ บริการ การ เข้าถึง เนื้อหา ที่ มี ความ สะดวก และ ความ ปลอดภัย สูงสุด. <br>
      </p><p><strong><font color="#990000">ผจัดเก็บสกุลเงินดิจิทัล</font></strong><br>
Perfect Money ช่วยให้ลูกค้าของเราสามารถที่จะส่ง รับหรือจัดเก็บสินทรัพย์ Bitcoin ได้อย่างปลอดภัย เราให้บริการแพลตฟอร์มที่ปลอดภัยและน่าเชื่อถือสำหรับการดำเนินการธุรกรรมใด ๆ ที่กำหนดในรูปหน่วยค่าเงิน Bitcoin คุณไม่จำเป็นต้องดาวน์โหลดและใช้กระเป๋าสตางค์ Bitcoin ที่ไม่สะดวกสบายและซับซ้อนเลย เพียงฝากเงินไปยังบัญชี Perfect Money B ของคุณและระบบจะดูแลในส่วนที่เหลือ<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>ความ ปลอดภัย</b></font><br>
<br>
ระบบ รักษา ความ ปลอดภัย Perfect Money ได้ รับ การ พัฒนา โดย กลุ่ม งาน วิจัย ทาง วิทยาศาสตร์ ของ ผู้เชี่ยวชาญ ใน ด้าน การ รักษา ความ ปลอดภัย ข้อมูล และ การเงิน. วิศวกร PM มี การ จัดการ เพื่อ สร้าง เครื่องมือ ที่ เหมาะ สำหรับ การ รักษา ความ ปลอดภัย ของ ลูกค้า โดย ใช้:
<p>- ประสบการณ์ ระยะ ยาว ของ นัก วิเคราะห์ PM ใน การ ดำเนิน งาน กับ ตราสาร ทาง การเงิน ใน ขนาด ใหญ่ หนึ่ง ; <br>
  - เทคโนโลยี - ของ ปัญญา ประดิษฐ์ การ ตรวจ สอบ สิทธิ ของ ลูกค้า; <br>
  - การ ตรวจ สอบ แบบ ออนไลน์ ของ ระดับ ความ ปลอดภัย และ การ ป้องกัน ลูกค้า โดย บริการ รักษา ความ ปลอดภัย ของ Perfect Money. <br>
  <br>
  <b>กล่อง เครื่องมือ ด้าน ความ ปลอดภัย ของ ลูกค้า PM มี ดัง ต่อ ไป นี้ :</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">ตรวจ สอบ บุคคล </font></b> <br>
เครื่องมือ นี้ ใช้ สำหรับ ตัว ของ บัญชี ลูกค้า PM. เครื่อง มือ นี้ เป็น ประเภท ตา เทียม สำหรับ Perfect Money ซึ่ง ไม่ จำเป็น ต้อง ตระหนัก ถึง คน โดย / ใบหน้า ของ เขา เธอ แต่ มี ความ เป็น ไป ได้ ที่ จะ ระบุ คอมพิวเตอร์ ที่ ใช้ ใน การ เข้า บัญชี. ใน กรณี ที่ การ ตรวจ สอบ ลูกค้า จะ ทำ จาก  หรือ  ที่ อยู่ ที่ ไม่ เกี่ยว กับ เจ้าของ บัญชี ระบบ บล็อก เข้า บัญชี และ ส่ง รหัส ความ ปลอดภัย เพิ่มเติม อีเมล์  ที่ ระบุ ใน ระหว่าง การ ลง ทะเบียน บัญชี. เปลี่ยน ที่ อยู่ จะ ทำ ที ละ ด้วย ความ ช่วยเหลือ ของ Perfect Money ศูนย์ สนับสนุน.
        <br>
        <br>
        <b><font color="B01111">การ ตรวจ สอบ SMS </font></b><br>
ระบบ นี้ ใช้ สำหรับ การ สร้าง การ เชื่อม ต่อ ตรรกะ ระหว่าง บัญชี ลูกค้า และ จำนวน เซลล์ ของ ตน ที่ ระบบ ส่ง รหัส ยืนยัน เพื่อ ระบุ เจ้าของ บัญชี จริง. ระบบ SMS ล็อกอิน  เป็น ดี ที่สุด และ เชื่อถือ ได้ วิธี การ ป้องกัน ลูกค้า ที่ ไม่ใช่ เข้า บัญชี รับ อนุญาต เนื่องจาก เวลา ที่ ใช้ ใน การ ดำเนิน การ ทั้งหมด ของ การ แลกเปลี่ยน โค้ด และ บัญชี เป็น ของ ใส่ สั้น มาก และ ไม่ เพียงพอ สำหรับ การ ดำเนิน งาน แตก.
        <br>
        <br>
        <b><font color="B01111">ป้องกัน CodeCard </font></b> <br>
ลูกค้า ได้ รับ บัตร ที่ มี ภาพ กราฟิก ของ รหัส ที่ ส่ง ถึง / เธอ เขา อยู่ อีเมล์ . เพื่อ ยืนยัน การ ทำ รายการ ระบบ จะ ส่ง ลูกค้า สอบถาม ใน การ ส่ง คำ สั่ง สุ่ม รหัส ยืนยัน จาก บัตร ที่. CodeCard เป็น มาตรการ ป้องกัน ความ สะดวก และ เชื่อถือ ได้ เพื่อ ยืนยัน การ ทำ รายการ. มัน ได้ พิสูจน์ ตัว เอง ใน ส่วน ของ สถาบัน การเงิน ที่ เด่น ชัด ที่สุด ใน โลก นี้. <br>
    </td>
  </tr>
</table>
<br>
<br>
แนว ทาง ประชาธิปไตย ของ Perfect Money ระบบ ชำระ เงิน ช่วย ให้ ลูกค้า ตัดสินใจ โดย อิสระ ที่ ตั้ง ค่า ความ ปลอดภัย เขา / เธอ ต้องการ ที่ จะ ใช้ สำหรับ / บัญชี ของ เขา เธอ ทุก. ลูกค้า ของ ทุก PM จะ ทำให้ ประนีประนอม กับ เขา / ตัว เอง และ เลือก / ขอบ ของ เธอ ความ สะดวก ของ การ ใช้ และ รักษา บัญชี จาก ไม่ใช่ ดู อำนาจ หรือ ใช้.
<p><strong>ระบบ Perfect Money จะ เผื่อแผ่ ให้ ลูกค้า ใด. </strong></p>
<p>เรา ได้ สร้าง เครื่องมือ ที่ มี ประสิทธิภาพ สูงสุด ใน การ ควบคุม ทาง การเงิน ของ คุณ และ เรา หวัง ว่า จะ ช่วย ให้ ลูกค้า ของ เรา มือ ฟรี ใน อดีต ของ นโยบาย การเงิน ของ ตนเอง. ลูกค้า ทุก คน เป็น สิ่ง สำคัญ สำหรับ เรา และ ข้อเท็จจริง ที่ ว่า คุณ เลือก Perfect Money entitles เรา เพื่อ ให้ ลูกค้า ของ เรา ที่ มี โอกาส สูงสุด ใน การ ควบคุม บัญชี ของ ตน โดย ไม่ กลัว ใด ถูก บล็อค.
</p>
<p>งาน ของ ระบบ รักษา ความ ปลอดภัย Perfect Money คือ การ ให้ โอกาส สูงสุด ให้ กับ ลูกค้า ของ เรา สำหรับ การ ก่อสร้าง ระบบ รักษา ความ ปลอดภัย สำหรับ  การเงิน ของ พวก เขา. ระบบ รักษา ความ ปลอดภัย ร่วม กับ ฝ่าย วิจัย วิทยาศาสตร์ ของ Perfect Money ตลอด เวลา ไม่ เพียง พัฒนา ระบบ ความ ปลอดภัย ใหม่ แต่ ยัง มี ที่ จำหน่าย ของ กลุ่ม ผู้เชี่ยวชาญ สำหรับ แบบ จำลอง วิธี การ ทั้งหมด ที่ เป็น ไป ของ ระบบ แตก เพื่อ ที่ จะ ใช้ ข้อมูล นี้ ใน อนาคต สำหรับ การ ก่อสร้างของ  ดิจิตอล ทั่ว ระบบ. </p>
<p>สำหรับ ลูกค้า ของ เรา ด้าน อื่น ๆ ของ หน้า จอ คอมพิวเตอร์ Perfect Money เงิน ได้ สร้าง บริษัท ทาง การเงิน ที่ มี ความ เป็น ไป ได้ นับ พัน ที่ ซ่อน อยู่ หลัง ประตู เล็ก เท่านั้น - ช่อง เข้า สู่ ระบบ ใน หน้า หลัก. ให้ มัน สูง เวลา เปิด ประตู นี้ เพื่อ ดู จักรวาล ของ Perfect Money! <br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script>ทำให้ P2P และ B2B การ ชำระ เงิน Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "th_TH", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">พันธมิตร โปรแกรม</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">ประกาศ ตาม กฎหมาย</font></a>
| <a href="privacy.php"><font color="#b50b0b">นโยบาย ความ เป็น ส่วนตัว </font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">เงื่อนไข การ ใช้ งาน </font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>