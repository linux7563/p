<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><title>Réalisez des paiements P2P et B2B avec Perfect Money</title>
<META NAME="Keywords" CONTENT="possibilités, perfectmoney, perfect money">
<META name="description" content="Le système de paiement Perfect Money ouvre le plus simple et sûr service financier pour la réalisation de transfert bancaires à tout le monde. Recevez les valeurs électroniques, des transfert bancaires et des paiements SMS sur Votre site Web, achetez de l’or, envoyez ou recevez d’argent avec le système de paiement le plus sûr sur Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/FR.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR" selected>Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Inscription</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Échangeurs</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Demo</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Aide</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centre de securite</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/fr_FR/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/fr_FR/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Entrée</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Accueil</span></a>
								<a href="about.php" class="selectedd"><span>A propos</span></a>
								<a href="features.php"><span>Fonctionnalités</span></a>
								<a href="fees.php"><span>Commissions</span></a>
								<a href="evoucher-info.php"><span>E-Vouchers</span></a>
                <a href="guarantees.php"><span>Garanties</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contactez nous</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>taux d’échanges <font color='#F01010'>Perfect Money</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sondage public</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money :<br><br>
<a href="statistics.php">Consulter les résultats en temps réel</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Questions fréquentes</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">What is the commission for a funds deposit via bank transfer?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">En ce moment nous ne prenons pas de commissions pour les consignations de transferts bancaires, mais certaines banques intermédiaires peuvent prendre des commissions pour la réalisation technique de transfert.
</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Quel est le montant des frais pour les dépôts par services de change ?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Chaque fournisseur de service de change établit ses propres frais. Vous pouvez en savoir plus à ce sujet sur leurs sites Web. </font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Apprenez-en plus sur les «Questions et Réponses»</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br>
<font size="4">Fonctionnalités de <font size="4" color="#F01010">Perfect Money</font></b></font></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Le système Perfect Money utilise les meilleurs outils existants pour fournir à ses clients une solution globale et performante de paiement en ligne. <p>Ni votre balance ni votre date d’inscription ne vous limitent dans l’utilisation de Perfect Money : vous aurez toujours accès à toutes les fonctionnalités disponibles.</p>Chaque client de Perfect Money présente pour nous une grande valeur et nous ne faisons pas de différence entre nos utilisateurs: tous doivent être satisfaits.
<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Le statut de l’utilisateur</b></font></p>
<p class="txt">Dans le but de simplifier l’utilisation du système pour toutes les parties impliquées, nous avons mis en place une graduation de nos utilisateurs, qui se décline en 3 statuts : <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      le présent statut s’attribue aux tous nouveaux usagers et n’applique aucune limitation en utilisant le système.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
le présent statut s’applique à l’usager ayant plus d’un an d’ancienneté ou ayant atteint une haute balance dans son compte Perfect Money. Les utilisateurs possédant le statut Premium se voient appliqués des frais encore plus faibles sur leur transactions. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
le présent statut s’applique uniquement aux partenaires choisis par l’administration de Perfect Money. L’obtention du présent type de statut s’effectue le plus souvent pour optimiser les paiement B2B pour les compagnies utilisant Perfect Money dans leur business sur Internet.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>État de la vérification client</b></font></p>
<p class="txt">Nous encourageons nos clients à passer une simple procédure de vérification en chargeant des pièces d'identité officielles et en indiquant un numéro de téléphone mobile. Les comptes vérifiés offrent un accès à toutes les fonctions du compte. Parmi les quelques avantages figurent :<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Des frais plus bas<br><br>
   Des options de sécurité supplémentaires<br><br>
	 Une meilleure confiance envers votre compte par d'autres clients<br><br>
	 Restauration de compte facile, si vous perdez votre mot de passe ou ne pouvez pas accéder pour une raison quelconque.
	 </td>
  </tr>
</table>
<br>
<p>De plus, Perfect Money vous propose 2 sous-statuts : l’usager souhaitant s’enregistrer comme une personne privée choisi le sous-statut Personal, et une personne souhaitant utiliser son compte Perfect Money pour son business sur internet choisi le souus-statut Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>De nombreuses et confortables méthodes de dépôt/retrait: </b></font><br>
  <br>
En utilisant le système Perfect Money, l’utilisateur possède le meilleur outil, performant et simple, pour effectuer des paiements P2P et P2B. Le paiement d’une marchandise ou d’un service sur Internet est, avec Perfect Money, une simple opération qui ne vous prends pas plus de quelques seconde. De plus, le dépôt de votre argent, virtuel ou réel, sur Perfect Money, ne présente aucun souci.<br>
  <br>
  <b>Vous pouvez créditer votre compte Perfect Money par les moyens suivants:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Le virement bancaire </font></b> <br>
est accepté pour créditer votre  compte Perfect Money. Le transfert de vos fonds est effectué en moins de 30 secondes. <br>
        <br>
        <b><font color="B01111">Les e-currencies</font> </b><br>
sont également un moyen d’envoyer de l’argent sur votre compte Perfect Money. En effet, nous travaillons avec différentes e-currencies, à l’instar de  webmoney, e-gold, pecunix. Ces opérations peuvent être réalisées automatiquement à partir de votre compte Perfect Money.<br>
        <br>
        <b><font color="B01111">Nos échangeurs d’e-currencies partenaires </font></b><br>
vous permettent également de déposer de l’argent sur votre compte Perfect Money. Nos partenaires sont des échangeurs sérieux et honnêtes, qui ont prouvé la qualité de leur services au cours de leur travail. <br>
        <br>
        <b><font color="B01111">Stocker la valeur de la crypto-monnaie</font></b><br>
Les comptes Perfect Money libellés dans une crypto-monnaie spécifique constituent une excellente opportunité pour stocker de la valeur. Contrairement aux portefeuilles en crypto-monnaie, les comptes Perfect Money ne nécessitent pas d'expertise technique pour configurer et maintenir la sécurité. Stocker de la valeur sur les comptes Perfect Money vous garantit que vous évitez les risques associés aux portefeuilles qui peuvent entraîner la perte définitive de la crypto-monnaie, tels que la panne logicielle ou le vol et la perte d'un mot de passe. L'équipe Perfect Money a éliminé les défis des crypto-monnaies tout en vous permettant de profiter de leurs avantages.</p>
    </td>
  </tr>
</table>
<br>
<br>
Pour le confort des utilisateurs il est possible de déposer sur votre compte Perfect Money n’importe quel devise : dans ce cas votre dépôt sera converti aux taux le plus avantageux. De plus, pour chaque utilisateur, Perfect Money calcule par rapport à votre balance des intérêts mensuels qui sont déposés sur votre compte chaque mois. Votre argent travaille pour vous même quand vous dormez.<br>
<p>Vous pouvez également retirer votre argent de Perfect Money par ces mêmes moyens de paiements. En utilisant le virement bancaire, les e-currencies et les échangeurs, les clients de Perfect Money peuvent toujours recevoir leur argent dans les plus brefs délais.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Fonctionnement</b></font><br>
  <br>
Pour les utilisateurs participant à des activités basées sur l’internet, le système de Perfect Money propose la solution optimale, qui inclut des instruments favorables et fonctionnels des calculs élaborés par les experts financiers de Perfect Money pour les besoins de tout business actuel.  <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Des relevés détaillés et commodes facilitent la gestion de la comptabilité</strong></font><br>
       Vous pouvez trouver facilement les informations sur toutes vos opérations financières, consulter des graphiques…tout cela en ligne!</p>
      <p><strong><font color="#990000">Des transactions instantanées et possibles n’importe quand </font></strong><br>
Avec Perfect Money, vos transactions sont effectuées instantanément et peuvent être effectuées à n’importe quelle heure du jour ou de la nuit, 365 jours pas an.</p>
      <p><strong><font color="#990000">Le centre de support individuel des clients de Perfect Money</font></strong><br>
Le support on-line pour nos clients 24/24 , 7/7, 365/365. Nous sommes prêts à répondre à vos questions, mettant à votre disposition notre expertise de la finance en ligne.</p>
      <p><strong><font color="#990000">Interface de paiement pour marchands parfaite</font></strong><br>
Nous vous proposons l’interface de paiement ultime, élaborée selon des critères d’ergonomie et de sécurité sélectifs qui en font la meilleure solution pour accepter les paiements en ligne et développer votre business. Les ingénieurs de Perfect Money ont créé l’instrument à l’aide duquel il est très facile et sûr d’organiser la vente de produits, de services ou autres dans n’importe quel secteur commercial.<br>
      </p><p><strong><font color="#990000">Stockez des crypto-monnaies</font></strong><br>
Perfect Money permet à ses clients d'envoyer, de recevoir et de stocker des actifs Bitcoins en toute sécurité. Nous fournissons une plateforme sûre et fiable pour effectuer des transactions libellées en Bitcoins. Vous n'avez pas besoin de télécharger et d'utiliser un portefeuille Bitcoins compliqué et peu pratique. Déposez des fonds sur votre compte B Perfect Money et le système s'occupera du reste.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>La sécurité</b></font><br>
<br>
Le système de sécurité de Perfect Money a été élaboré par une groupe des spécialistes dans le domaine de la sécurité informatique et financière. Ces ingénieurs ont réussi à créer l’instrument idéal de protection électronique pour l’utilisateur en utilisant:
<p>- l’expérience de plusieurs années de travail des analystes de Perfect Money avec de très gros montants dans dans la sphère financière; <br>
  - des technologies avancées permettant l’identification de l’usager ; <br>
  - la surveillance continue et en temps réel du niveau de sécurité et de défense des utilisateurs de Perfect Money. <br>
  <br>
  <b>L’instrument de la défense de l’usager de PM se compose de:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">La vérification de l’authenticité de l’utilisateur</font></b> <br>
Cette technologie est utilisée pour authentifier l’utilisateur tentant de se connecter à son compte Perfect Money. Il est une aide artificielle utile pour Perfect Money et pour votre sécurité, ne permettant pas de voir réellement le visage de l’utilisateur mais donnant la possibilité de tracer l’ordinateur avec qui est réalisée la tentative de connexion. L’entrée au compte est bloquée si un changement d’adresse IP ou de navigateur, et un code de sécurité est envoyé directement sur l’e-mail de l’utilisateur : pour se connecter, l’utilisateur devra fournir le code secret qui lui aura été envoyé.
        <br>
        <br>
        <b><font color="B01111">Authentification par SMS</font></b><br>
Ce système vous permet de vous connecter à votre compte à l’aide d’un code de sécurité qui vous sera envoyé directement à votre numéro de téléphone mobile, relié à votre compte Perfect Money. L’authentification par SMS se présente comme le mode le plus sécurisé pour accéder à votre compte, car on ne peux accéder à votre compte dans votre téléphone mobile et que le coût de ce service est très faible.
        <br>
        <br>
        <b><font color="B01111">La «CodeCard»</font></b> <br>
L’utilisation de cet outil permet à l’utilisateur de valider ses transactions à l’aide d’une CodeCard confidentielle, qui vous sera envoyée à votre e-mail. Pour la confirmation d’une transaction, le système demande à l’utilisateur de renseigner une des ligne de sa CodeCard, auquel lui seul a accès. La CodeCard est une mesure de sécurité complémentaire, recommandée pour une sécurité optimale et pour se protéger contre les transactions non désirées.<br>
    </td>
  </tr>
</table>
<br>
<br>
Le système Perfect Money donne à l’utilisateur la possibilité de choisir lui-même quelles outils de sécurité il souhaite activer ou désactiver. Chaque utilisateur fixe ses propres règles comme il le souhaite pour préserver la sécurité de son compte Perfect Money.
<p><strong>Le système Perfect Money s’adapte également à chaque utilisateur.</strong></p>
<p>Nous avons créé l’instrument optimal pour gérer vos finances en ligne et nous essayons de donner une liberté complète à l’utilisateur qui édifie lui-même sa politique de gestion, de comptabilité et de sécurité. Chaque client est très important pour nous : en effet chaque personne utilisant notre système Perfect Money a le droit de l’utiliser comme il l’entends, d’appliquer sa propre politique de gestion et de profiter de toutes les possibilités de système.</p>
<p>Notre objectif est de proposer à l’utilisateur un système adaptable et modifiable par chacun, avec de nombreux niveaux de sécurité, pour gérer ses finances en ligne. Le service de sécurité et le département scientifique de Perfect Money élaborent ensemble de nouveaux système de sécurité et dispose d’un groupe de spécialistes tenant constamment compte des nouvelles informations et technologies de sécurité, dans le but d’ appliquer ces information au futur pour édifier une forteresse digitale: Perfect Money.</p>
<p>Perfect Money a créé pour ses clients une corporation financière avec des milliers de possibilités, qui se cache de l‘autre côte du moniteur, derrière une petite porte qui s’appelle «Accéder à votre compte» sur la page principale. Alors, il est le temps pour vous de découvrir l’univers de Perfect Money…<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-france.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script>Réalisez des paiements P2P et B2B avec Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "fr_FR", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">programme d’affiliation</font></a> | <a href="sample-api.php"><font color="#b50b0b">interfaces de paiements Perfect Money</font></a> | <a href="legal.php"><font color="#b50b0b">mentions légales</font></a>
              | <a href="privacy.php"><font color="#b50b0b">politique de confidentialité</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> | <a href="tos.html"><font color="#b50b0b">conditions d'utilisations</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"><font color="#b50b0b">La carte du site</font></a></font></font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>