<script src="js/jquery.1.9.min.js"></script>
<script src="http://localhost/files/player/mediaelement-and-player.min.js"></script>
<link rel="stylesheet" href="http://localhost/files/player/mediaelementplayer.css" />
<script>
    $(document).ready(function(){
        $('#video_player').mediaelementplayer();
    });
</script>
<video width="977" height="550" id="video_player" src="http://localhost/files/guide/guide.mp4" type="video/mp4" poster="http://localhost/img/tour/poster.jpg" controls="controls" preload="none"></video>