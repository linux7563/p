<?php

require_once "library.php";
$name = get_my_name($_SERVER['PHP_SELF']);
$country_code = get_vcc();


if(isset($_COOKIE['lang'])){
    $file_to_open = "about.html_lang=".$_COOKIE['lang'].".html";
    include $file_to_open;
}else {
    if(!isset($_COOKIE['lang'])){setcookie("lang", $country_code, 0, "/");}
    $file_name = "about.html_lang=".$_COOKIE['lang'].".html";
    if (file_exists($file_name)) {
        include $file_name;
    } else {
        setcookie("lang", "en_US", 0, "/");
        include "about.html_lang=".$_COOKIE['lang'].".html";
    }
}