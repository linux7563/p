<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><title>Make P2P and B2B payment with Perfect Money</title>
<META NAME="Keywords" CONTENT="features, perfectmoney, perfect money">
<META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/PK.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN" selected>Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">سائن اپ کر</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">لاگ ان</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">ایکسچینجرز</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">مدد</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">ٹور</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">سیکورٹی سینٹر</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/ur_IN/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/ur_IN/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">لاگ ان</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>ہوم</span></a>
								<a href="about.php" class="selectedd"><span>ہمارے بارے میں</span></a>
								<a href="features.php"><span>خصوصیات</span></a>
								<a href="fees.php"><span>فیس</span></a>
								<a href="evoucher-info.php"><span>کے ای-واؤچ</span></a>
                <a href="guarantees.php"><span>ضمانتیں</span></a>
                <a href="faq.php"><span>اکثر پوچھے جانے والے سوالات</span></a>
                <a href="contact.php"><span>ہم سے رابطہ کریں</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color=‘#F01010’>PM</font> تبادلہ کی شرحیں</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61647.7&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57557.27</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2279.94&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.324</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/31.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>عوامی رائے شماری</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: خدمت کا معیار اور مصنوعات<br><br>
<a href="statistics.php">واقع فوراً نتائج دیکھیں</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>اکثر پوچھے جانے والے سوالات</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">کسی بینک وائر کے ذریعہ کوئی رقم جمع کرتے وقت مجھے کیوں ایک مصدقہ مبادلہ سروس فراہم کار متعین کرنا چاہیے؟</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">ہمارا ادائیگی سسٹم صرف Perfect Money میں موجود اکاؤنٹس کے اندرونی ٹرانسفر پر ہی عمل درآمد کرتا ہے۔ بینک وائر کے ذریعہ رقم کو جمع کرنے اور نکالنے کے سارے عمل کو مصدقہ مبادلہ سروس فراہم کار کے ذریعہ انجام دیا جاتا ہے۔</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">مجھے "تجزیات" سیکشن کی ضرورت کیوں ہے؟</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">یہ Perfect Money کے گاہکوں کو کرنسی مارکیٹ کے بارے میں باخبر رہنے میں مدد کرتا ہے، تازہ ترین مالی خبریں فراہم کرتا ہے، اور مبادلہ کی شرحوں کی حرکیات کا تجزیہ کرنے میں مدد کرتا ہے (چارٹس دستیاب ہیں)۔ آپ ان مبادلہ کی شرحوں کے بارے میں نوٹیفیکیشن کی رکنیت بھی حاصل کر سکتے ہیں جو آپ کے ای میل یا موبائل فون پر بھیجے جاتے ہیں۔</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> کی خصوصیات</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top"><p>Perfect Money کا سسٹم ایک کِٹ ٹولز کے ذریعہ چلتا ہے، جو کہ گاہکوں کے درمیان لین دین کی ادائیگی کا سب سے آرامدہ وسیلہ ہے۔</p>
      <p>بیلنس ٹرن اوور کی قدر اور ساتھ ہی ساتھ رجسٹریشن کی مدّت اس سسٹم کے مواقع کے استعمال کے امتیازات پر اثر انداز نہیں ہوتی۔</p>
      <p>Perfect Money کا ہرگاہک نہایت اہم ہے اور آپ کی خدمت کرتے ہوئے ہم کسی قسم کا امتیاز نہیں برتتے۔</p>
      <p><br>
      </p>
    </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>گاہک کی انفرادی حیثیت</b></font></p>
<p class="txt">لین دین کو دونوں فریقوں کے لئے آسان تر بنانے کے لئے Perfect Money، رجسٹریشن پر صارفین کو سسٹم کے ذریعہ حاصل کردہ تین درجوں کے مطابق تقسیم کرتا ہے۔<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">عام</font></b> <br>
      یہ درجہ تمام نئے رجسٹر شدہ گاہکوں کو، سسٹم کے استعمال کی کسی بھی پابندیوں اطلاق و حدود کے بغیر تفویض کیا جاتا ہے۔ <br>
      <br>
      <b><font color="B01111">پریمیئم</font></b><br>
      ایک سال سے زائد عرصہ کے فعال یا ایک صراحت کردہ بیلنس ٹرن اوور کی قدر رکھنے والے گاہکوں کو تفویض کیا جاتا ہے۔ نارمل کھاتہ کو اب گریڈ کرنے کے لئے، گاہک کو کسٹمر سروس کے نام ایک علیحدہ درخواست بھیجنی ہوتی ہے۔ پریمیئم درجہ میں یہ خصوصیت پائی جاتی ہے کہ اس درجہ میں نارمل درجہ والے گاہکوں کے ذریعہ ادا کی جانے والی کمیشن فیس کی تعداد کم تر ہوتی ہے۔<br>
      <br>
      <b><font color="B01111">پارٹنر</font></b> <br>
    کا درجہ  Perfect Money ایڈمنسٹریشن کی اپنی صوابدید کے مطابق پارٹنرس کو انٹرنیٹ کے ذریعہ اپنے کاروبار چلانے والی کمپنی کی B2B ادائیگیوں کو مفید بنانے کے لئے تفویض کیا جاتا ہے۔</td>
  </tr>
</table>
<br>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>گاہک کی تصدیق کی حیثیت
  </b></font></p>
<p class="txt">ہم اپنے گاہکوں کو سرکاری طور پر جاری کردہ شناختی دستاویزات کو اپ لوڈ کرتے ہوئے اور اپنا موبائل فون نمبر فراہم کرتے ہوئے توثیق کے آسان عمل سے گذرنے کی ترغیب دیتے ہیں۔ تصدیق کردہ اکاؤنٹ آپ کو اکاؤنٹ افعال کی مکمل رسائی فراہم کرتا ہے۔ بعض فوائد میں شامل ہے:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><p>کم تر فیس</p>
      <p>اضافی سیکوریٹی اختیارات</p>
      <p>دوسرے گاہکوں کی جانب سے آپ کے اکاؤنٹ کے لیے اضافی اعتماد</p>
    <p>آسان اکاؤنٹ کی بحالی، اگر آپ سے آپ کا پاسورڈ کھو جائے یا آپ کسی وجہ سے رسائی نہ حاصل کرسکیں</p></td>
  </tr>
</table>
<br>
<p>مقصد اور پیشگوئی کردہ ٹرن اوور پر منحصر آپ اپنے کھاتہ کے ذیلی گروپ کو  منتخب کر سکتے ہیں۔ شخصی، انفرادی استعمال کے لئے، یا کاروباری۔<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>اکاونٹ کو فنڈ بھیجنے کے لئے آرامدہ اور آسان طریقے:</b></font><br>
  <br>
  Perfect Money سسٹم کے استعمال سے گاہکوں کو P2P اور P2B ادائیگیوں کے لئے ایک آرامدہ اور استعمال کے لئے آسان ٹول میسر ہوتا ہے۔ ایک PM گاہک کے لئے، اشیا اور خدمات کی انٹرنیٹ میں ادائیگی آسان عمل میں تبدیل ہو جاتی ہے، کیونکہ اس عمل کے لئے صرف ہونے والا وقت مشکل سے 1 سکینڈ سے زیادہ ہوتا۔ اب اپنے اصلی یا مجازی بینک نوٹوں کو Perfect Money میں تبدیل کرنا کوئی مسئلہ نہیں ہے۔<br>
  <br>
  <b>اپنے سسٹم میں رقم جمع کرنے کو درج ذیل طریقہ پر انجام دیا جا سکتا ہے:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p><font color="B01111">وائر ٹرانسفر</font><br />
      اپنے کھاتہ کو فنڈ کرنے کا ایک آرامدہ طریقہ ہے۔ رقم کو PM کھاتہ میں جمع کرنے کا عمل، رقم کی منتقلی  کی رسید ملنے کے 30 سکینڈ کے اندرانجام پاتا ہے۔</p>
      <p><font color="B01111">الیکٹرانک کرنسی</font><br />
      Perfect Money سسٹم متعدد ای-کرنسیوں کے ساتھ کام کرتا ہے، اور اس بنا پراکاونٹ کی فنڈنگ ای-کرنسیوں کے ذریعہ انجام دی جا سکتی ہے۔ اس قسم کے لین دین کو ان ادائیگیوں کے سسٹمز کے ذریعہ خودبخود طور پر انجام  دیا جا سکتا ہے۔</p>
      <p><font color="B01111">ایکسچینج پارٹنرس</font><br />
      آپ کے کھاتہ میں رقم جمع کرنے کا ایک دوسرا طریقہ فراہم کرتا ہے۔ Perfect Money کےایکسچینج پارٹنرز کی متعدد کرنسیوں اور ان کی  گزرتے وقت کے ساتھ ثابت شدہ - معتبریت نے سسٹم کے کسی کھاتہ میں رقم جمع کرنے کو ایک آسان اور محفوظ عمل بنا دیا ہے۔</p>
      <p><font color="B01111">Crypto-Currency Value اسٹور</font><br />
      مخصوص کریپٹو-کرنسی والے Perfect Money کے اکاؤنٹس قدروں کو جمع رکھنے کا ایک بہترین موقع ہیں۔ کریپٹو کرنسی ویلیٹس کے برخلاف، Perfect Money اکاؤنٹس کو سیٹ اپ کرنے اور محفوظ طریقہ پر اس کا رکھ رکھاؤ کرنے کے لئے کسی تکنیکی مہارت کی ضرورت نہیں ہوتی ہے۔ Perfect Money اکاؤنٹس میں قدروں کو اسٹور کرنا اس امر کو یقینی بناتا ہے کہ آپ ویلیٹ سے وابستہ جوکھموں سے بچے رہیں جن سے کریپٹو کرنسی کا مستقل نقصان ہوتا ہے، جیسے کہ ہارڈویئر کی ناکامی/چوری ہوجانا اور پاسورڈ گم ہوجانا۔ Perfect Money کی ٹیم کریپٹو کرنسیوں کے چیلنجوں کو دور کرتے ہوئے آپ کو فوائد سے لطف اندوز ہونے دیتی ہے۔</p>
      <p class="txt">&nbsp;</p>
    </td>
  </tr>
</table>
<br>
<br>
<p>گاہکوں کے آرام کے لئے Perfect Money، کسی بھی قسم کی ای-کرنسی کے ذریعہ سے کھاتوں میں رقم جمع کرنے کا ایک امکان فراہم کرتا ہے۔ اس معاملہ میں، Perfect Money سب سے زیادہ قابل منافع شرح پر فوری طور پر لین دین کو انجام دے گا۔</p>
<p>ہر ایک گاہک کا خیال رکھتے ہوئے، Perfect Money سسٹم گاہک کے کم از کم اکاونٹ بیلنس میں ماہانہ سود کی رقم جمع کرے گا۔<br />
  آپ کی رقم آپ کے لئے اس وقت بھی کام کرے گی، جب آپ آرام کریں گے۔</p>
<p>اگراکاؤنٹ بیلنس کو گاہک کے ذریعہ خرچ نہیں کیا جائے تو، گاہک کے کھاتوں سے رقم کو جمع کرنے کے لئے استعمال کئے گئے ٹولز کے ذریعہ رقم کو واپس نکالا بھی جا سکتا ہے۔</p>
<p>وائر ٹرانسفر، کسی بھی قسم کی کرنسی میں منتقلی یا  تبدیلی اور ایکسچینجرز کا استعمال کرتے ہوئے Perfect Money کے گاہک اپنی رقم کو ایک کم از کم ممکنہ وقت میں حاصل کر سکتے ہیں۔</p>
<br>
  <br>
  <p><strong><font size="3">کاکردگی</font></strong></p>
  <p>ایسے گاہکوں کے لئے جن کی کاروباری سرگرمیاں انٹرنیٹ کے ساتھ جڑی ہوئی ہیں، Perfect Money سسٹم کاروباری حلوں کا ایک بہترین پیکیج، بشمول ادائیگیوں  کے آسان کاکردگی والےٹولز،  فراہم کرتا ہے، جن کو PM فائنانسیرز نے جدید ترین آئی ٹی کاروبار کی ضروریات کو ملحوظ رکھتے ہوئے خصوصی طور پر تیار کیا ہے۔</p>
  <br>
  <br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p><font color="B01111">آرامدہ اور تفصیلی رپورٹیں، آپ کی اکاونٹنگ کو آسان بناتی ہیں</font><br />
      نئے مالیاتی آپریشنز کے متعلق اطلاعات حاصل کریں، چارٹس اور واقعی فوری اسٹیٹمنٹ ملاحظہ کریں۔</p>
      <p><font color="B01111">خودکار موعودہ ادائیگیوں کی ترتیب کا نظام</font><br />
      اس ٹول کو آپ کے ادارہ کے ماہانہ اخراجات کو منظم کرنے کے مقصد سے تشکیل دیا گیا ہے؛ یہ خود بخود طرز پر ادائیگیوں کی انجام دہی میں مدد دیتا ہے۔</p>
      <p><font color="B01111">Perfect Money کے کاروباری گاہکوں کے انفرادی سپورٹ کا مرکز</font><br />
      گاہکوں کا آن لائن سپورٹ 24/7/365 (یعنی دن کے چوبیس گھنٹے، ہفتہ کے ساتھ دن ، سال کے 365 دن) کام کرتا ہے۔ ہمارے ماہرین آپ کی دلچسپی والے کسی بھی سوالات کے جوابات دینے کے لئے تیار ہیں۔</p>
      <p><font color="B01111">Perfect API Merchant</font><br />
      کاکردگی، اعتماد، اور سلامتی کی ہماری کسوٹیوں کے تصور کے بنیاد پرہمیں اگلے چند سالوں میں Perfect Money کے مماثل کسی کمپنی کے وجود میں آنے کی کوئی توقع نہیں ہے۔ Perfect Money انجنیئروں نے ایک ایسا ٹول تیار کیا ہے، جو کسی بھی کاروباری ڈھانچہ کواشیا کی فروخت، خدمات یا زیادہ سے زیادہ آسانی اور حفاظت کے ساتھ رسائی کو کسی بھی قسم کے آن لائن طریقہ سے انجام دینے میں تعاون دیتا ہے۔</p>
      <p><font color="B01111">Store Crypto-Currency</font><br />
      Perfect Money ہمارے گاہکوں کو بِٹ کوائن اسیٹس کو بھیجنے، وصول کرنے اور ذخیرہ کرنے کے قابل بناتا ہے۔ ہم بٹ کوائن میں ہونے والے کسی بھی لین دین کوانجام دینے کے لئے ایک محفوظ اور قابل اعتماد پلیٹ فارم فراہم کرتے ہیں۔ آپ کو ایک پیچیدہ اور دقت طلب بٹ کوائن ویلیٹ ڈاؤن لوڈ اور استعمال کرنے کی کوئی ضرورت نہیں ہوتی۔ اپنے Perfect Money بی اکاؤنٹ میں فنڈ جمع کرائیں اور سسٹم بقیہ تمام چیزوں کا خیال رکھے گا۔</p>
      <p class="txt"><br>
      </p>
    </td>
  </tr>
</table>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>سیکیوریٹی</b></font><br>
<br>
<p>Perfect Money کا حفاظتی نظام  معلومات اور مالیات کے تحفظ کے شعبہ کے خصوصی ماہرین پر مشتمل ایک سائنسی تحقیقی گروپ کے ذریعہ تیار کیا گیا ہے۔ PM انجنیئروں نے درج ذیل  کے استعمال سے گاہکوں کے لئے ایک مثالی ٹول تیار کرنے میں کامیابی حاصل کی ہے:</p>
<p>- PM تجزیہ کاروں کے مالیاتی انسٹرومنٹس کے بڑے پیمانہ پرچلانے کا طویل مدتی تجربہ؛<br />
  - گاہکوں کی توثیق کی مصنوعی دانشمندی کی ٹیکنالوجیاں؛<br />
  -Perfect Money کی حفاظتی خدمات کے ذریعہ انجام دی جانے والی  حفاظتی سطح اورگاہکوں کے تحفظ  کی آن لائن نگرانی۔<br>
  <br>
  <b>PM  گاہکوں کے سیکورٹی ٹول باکس میں حسب ذیل شامل ہیں:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p><font color="B01111">شناخت کی جانچ</font><br />
      اس ٹول کو PM کھاتہ کے گاہک کی شناخت کے لئے استعمال کیا جاتا ہے۔ یہ انسٹرومنٹ Perfect Money کے لئے ایک مصنوعی آنکھ کا کام انجام دیتا ہے، جو کسی شخص کو لازمی طور پر چہرے کے ذریعہ شناخت نہیں کرتا لیکن کھاتہ میں داخل ہونے کے لئے استعمال کردہ کمپیوٹر کی شناخت کے امکانات ضرور فراہم کرتا ہے۔ گاہک کی توثیق آئی پی ایڈریس  کے نیٹ یا سب نیٹ کے ذریعہ انجام دی جاتی ہے، جس کا اکاونٹ کے مالک سے تعلق نہیں ہوتا، سسٹم اکاونٹ میں داخلہ کو بلاک کرتا ہے اور سسٹم رجسٹریشن کے موقع پر فراہم کردہ ای میل کو اضافی حفاظتی کوڈ فراہم کرتا ہے۔ آئی پی ایڈریس کی تبدیلی Perfect Money سپورٹ سینٹر کی مدد سے انفرادی طور پر انجام دی جاتی ہے۔</p>
      <p>ا<font color="B01111">یس ایم ایس کے ذریعہ توثیق</font><br />
      یہ نظام گاہک کے کھاتہ اور اس کے سیل فون نمبر کے درمیان، جس کو سسٹم کھاتہ کے حقیقی مالک کی شناخت کے لئے ایک توثیقی کوڈ بھیجتا ہے، ایک منطقی ربط پیدا کرنے کے لئے استعمال کیا جاتا ہے۔ ایس ایم ایس لاگ اِن سسٹم  گاہکوں کے کھاتہ میں غیر مجاز داخلہ سے تحفظ کا ایک سب سے زیادہ مکمل اور قابل اعتماد طریقہ ہے، کیونکہ کوڈ کے تبادلہ اور اس کے کھاتہ میں داخلہ کے لئے استعمال ہونے والا وقت بہت ہی مختصر ہوتا ہے اور کسی بھی کریکنگ آپریشن کے لئے نا کافی ہوتا ہے۔</p>
      <p><font color="B01111">کوڈ کارڈ پروٹیکشن</font><br />
      گاہک کو کوڈ کی گرافِک تصویر والا ایک کارڈ موسول ہوتا ہے، جو اس کے ایمیل پر بھیجا جا تا ہے۔ لین دین کی توثیق کے لئے، سسٹم گاہک کو ایک  کارڈ سے قطعی کوڈ کی بلاترتیب طور پر ترسیل  کے لئے ایک انکوائری بھیجتا ہے۔ کوڈ کارڈ لین دین کی توثیق کا ایک آرامدہ اور قابل اعتماد  طریقہ ہے۔ یہ دنیا بھر کے سب سے زیادہ معروف مالیاتی اداروں کی اکثریت کے ذریعہ آزمودہ طریقہ ہے۔</p>
      <p class="txt"><br>
    </td>
  </tr>
</table>
<br>
<br>
Perfect Money کے ادائیگی نظام کا جمہوری طریقہ کار، ہر ایک گاہک کو اس بات کا فیصلہ کرنے کے قابل بناتا ہے کہ وہ اپنے کھاتہ میں کس حفاظتی ترتیبات کو استعمال میں لائے۔ PM کا ہر ایک گاہک اپنے ساتھ ایک مفاہمت کرتا ہے اور اپنے استعمال کے لئے اپنی ذاتی آسانی کو منتخب کرتا ہے اور اپنے کھاتہ کو غیر مجاز ملاحظہ یا استعمال سے روکتا ہے۔
<p><strong>Perfect Money نظام کسی بھی گاہک کے لئے کشادہ دل ہے۔ </strong></p>
<p>ہم نے آپ کے مالیاتی کنٹرول کے لئے سب سے زیادہ آرامدہ ٹولز تیار کئے ہیں اور ہم اپنے گاہکوں کو ان کی اپنی  مالیاتی پالیسی کے لئے اختیار فراہم کرنے کی اُمید رکھتے ہیں۔ ہر ایک گاہک ہمارے لئے اہمیت رکھتا ہے، اور یہ حقیقت کہ آپ نے Perfect Money کو منتخب کیا ہے، ہمیں اپنے گاہکوں کو بلاک کئے جانے کے کسی بھی خوف کے بغیر زیادہ سے زیادہ مواقع  فراہم کرنے کا اعزازعطا کرتی ہے۔</p>
<p>Perfect Money سیکورٹی سسٹم کا کام، اپنے گاہکوں کو اپنی مالیات کے تحفظ کے متعدد سطحی حفاظتی نظام کو تیار کرنے کے لئے زیادہ سے زیادہ مواقع فراہم کرنا ہے۔ یہ سیکورٹی نظام Perfect Money کے سائنسی تحقیقی شعبہ کے ساتھ مل کر نہ صرف نئے سیکورٹی نظام کو مسلسل طور پرتیارکرتا ہے، بلکہ سسٹم کے کریکنگ کے ہر ممکنہ طریقہ کار کی تمثیل کے لئے ماہرین کا ایک گروپ اس کے زیر اختیار ہے، جونظام کے اطراف ڈیجیٹل قلعہ بندی کی تعمیر کے لئے مستقبل میں معلومات کو استعمال کرسکتا ہے۔</p>
<p>کمپیوٹر اسکرین کے دوسرے کنارے پر موجود ہمارے گاہکوں کے لئے، Perfect Money نے ایک مالیاتی کارپوریشن تشکیل دیا ہے، جس میں ایک چھوٹے سے دروازے کے پیچھے ہزاروں امکانات مخفی ہیں- لاگ اِ ن فیلڈ اصل صفحہ پر۔ لہذا،  Perfect Money کی کائنات کو دریافت کرنے کے لئے یہ ایک موزوں ترین وقت ہے!</p>
<p><br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Perfect Money میں سائن ان کریں - جو کہ ادائیگی کرنے والا مستقبل کا نظام ہے!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script>Make P2P and B2B payment with Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ur_IN", getExpDate(30, 0, 0), "/");

          </script><style type="text/css">
.arabic{
  direction:rtl;
}
.atable{
text-align:right;
}
.a1{
  	padding-right:30px;
  	margin-right:30px;
}
</style>
<a href="promotion_materials.php"><font color="#b50b0b">الحاق یافتہ پروگرام</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect Money اے پی آئی | قانو</font></a> | <a href="legal.php"><font color="#b50b0b">نوٹس | رازداری کی</font></a>
| <a href="privacy.php"><font color="#b50b0b">لیسی | استع</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b"> کی شرائط</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">سائٹ میپ</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>