<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><title>Make P2P and B2B payment with Perfect Money</title>
<META NAME="Keywords" CONTENT="features, perfectmoney, perfect money">
<META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/IN.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN" selected>Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">साइनअप</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">लॉगिन</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">विनिमयकर्ता</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">टूर</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">सहायता</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">सुरक्षा केंद्र</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="http://localhost/img/lang/hi_IN/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/hi_IN/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">लॉगिन</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>होम</span></a>
								<a href="about.php" class="selectedd"><span>हमारे बारे मे</span></a>
								<a href="features.php"><span>विशेषताएं</span></a>
								<a href="fees.php"><span>फीस</span></a>
								<a href="evoucher-info.php"><span>ई-वाउचर</span></a>
                <a href="guarantees.php"><span>गारंटी</span></a>
                <a href="faq.php"><span>अक्सर पूछे जाने वाले प्रश्न</span></a>
                <a href="contact.php"><span>हमसे संपर्क करें</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> विनिमय दरें</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61647.7&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57557.27</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2279.94&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.324</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>सार्वजनिक मतदान</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: सेवा की गुणवत्ता और उत्पाद<br><br>
<a href="statistics.php">रियल-टाइम में परिणाम देखें</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>अक्सर पूछे जाने वाले प्रश्न</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">न्यूनतम और अधिकतम ऋण अवधि क्या है?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">न्यूनतम ऋण अवधि 1 दिन है। अधिकतम ऋण अवधि 365 दिन है।</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">वह अधिकतम राशि क्या है जिसे मैं बैंक वायर के जरिए निकाल सकता हूँ?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">इसकी कोई निर्धारित सीमा नहीं है।</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> की विशेषताएं</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Perfect Money प्रणाली का संचालन उपकरणों की एक किट से किया जाता है जो ग्राहकों के बीच निपटानों के लिए सबसे सुविधाजनक है।

      <p>शेषराशि की आवाजाही का मूल्य और रजिस्ट्रेशन की अवधि प्रणाली के अवसरों के उपयोग करने के विशेषाधिकारों को प्रभावित नहीं करती है। </p>
      <p>Perfect Money का हर ग्राहक बहुत महत्वपूर्ण है और आपकी सेवा करते समय हम कोई भेदभाव नहीं करते हैं। <br>
      </p>
    </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>ग्राहक व्यक्तिगत स्थिति</b></font></p>
<p class="txt">लेनदेनों को दोनों पक्षों के लिए अधिक आसान बनाने के लिए Perfect Money अपने उपयोगकर्ताओं को ग्राहकों के रजिस्ट्रेशन पूरा करने के बाद प्रणाली द्वारा प्राप्त की गई तीन स्थितयों के अनुसार विभाजित करता है:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">सामान्य</font></b> <br>
      प्रणाली के उपयोग पर बिना कोई सीमाएं लागू किए सभी नए रजिस्टर किए गए ग्राहकों को आबंटित। <br>
      <br>
      <b><font color="B01111">प्रीमियम</font></b><br>
      1 वर्ष से अधिक समय से सक्रिय या शेषराशि की आवाजाही के एक निश्चित मूल्य वाले ग्राहक को आबंटित। सामान्य खाते को अपड्रेड करने के लिए ग्राहक को ग्राहक सेवा को एक अलग अनुरोध भेजना होगा। प्रीमियम स्थिति यह अनुमान लगाती है कि कमीशन फीस की संख्या सामान्य स्थिति वाले ग्राहकों द्वारा आम तौर पर अदा की जाने वाली फीस से कम होगी।<br>
      <br>
      <b><font color="B01111">भागीदार</font></b> <br>
    इंटरनेट के माध्यम से अपने व्यवसायों का संचालन करने वाली कंपनियों के B2B भुगतानों को इष्टतम करने के लिए केवल Perfect Money प्रशासन के विवेक द्वारा भागीदारों को आबंटित।</td>
  </tr>
</table>
<br>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>ग्राहक सत्यापन स्थिति
  </b></font></p>
<p class="txt">हम अपने ग्राहकों को सरकार द्वारा जारी पहचान दस्तावेज अपलोड करके और मोबाइल नंबर प्रदान करके सरल सत्यापन प्रक्रिया को पूरा करने के लिए प्रोत्साहित करते हैं। सत्यापित खाता आपको खाते की पूर्ण कार्यात्मकता सुलभ कराता है। इसके कुछ लाभ ये हैं:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>
      कम फीस<br>
      <br>
      अतिरिक्त सुरक्षा विकल्प<br>
      <br>
      दूसरे ग्राहक की ओर से आपके खाते के प्रति विश्वास में वृद्धि<br>
      <br>
    यदि आपका पासवर्ड खो गया है, या आप किसी कारण से उस तक नहीं पहुँच पाते हैं तो खाते की आसान बहाली</td>
  </tr>
</table>
<br>
<p>आप प्रयोजनों और अनुमानित कारोबार पर निर्भर करते हुए अपने खाते का उप-समूह चुन सकते हैं: व्यक्तिगत उपयोग के लिए, निजी,या व्यवसाय।<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>खाते के वित्तपोषण के लिए सुविधापूर्ण और आसान तरीके: </b></font><br>
  <br>
  Perfect Money प्रणाली का उपयोग करते समय ग्राहक के पास P2P और B2B भुगतान करने के लिए एक सुविधापूर्ण और उपयोग में आसान साधन होता है। PM ग्राहक के लिए इंटरनेट पर उत्पादों या सेवाओं के लिए भुगतान एक सरल काम में बदल जाते हैं, क्योंकि इस काम में 1 सेकंड से अधिक का समय नहीं लगता है। अब आपके असली या आभासी बैंकनोटों को Perfect Money में बदलना कोई समस्या नहीं है।<br>
  <br>
  <b>इस प्रणाली में पैसे निम्न प्रकार से जमा किए जा सकते हैं:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">वायर अंतरण</font></b> <br>
        य़ह आपके खाते के वित्तपोषण का सुविधापूर्ण तरीका है। अंतरण के प्राप्त होने के बाद पैसे को PM खाते में 30 सेकंड के भीतर क्रेडिट कर दिया जाता है। <br>
        <br>
        <b><font color="B01111">इलेक्ट्रॉनिक करेंसी</font> </b><br>
        Perfect Money प्रणाली कई प्रकार की ई-करेंसियों के साथ काम करती है और इसलिए, खाते में वित्तपोषण ई-करेंसियों के माध्यम से किया जा सकता है। ऐसे लेनदेन इन भुगतान प्रणालियों के जरिए स्वचालित रूप से निष्पादित किए जा सकते हैं।<br>
        <br>
        <b><font color="B01111">विनिमय भागीदार</font></b><br>
आपके खाते का वित्तपोषण करने का एक और तरीका है। Perfect Money के विनिमय भागीदारों की बहु-करेंसी और उनकी समय-सिद्ध विशवसनीयता प्रणाली के खाते के वित्तपोषण को एक सरल और सुरक्षित संचालन में बदल देती है।<br>
<br>
        <b><font color="B01111">क्रिप्टो-करेंसी मूल्य का भंडारण करे</font></b><br>
किसी विशिष्ट क्रिप्टो-करेंसी में नामित Perfect Money खाते मूल्य का भंडारण करने का शानदार अवसर हैं। क्रिप्टो-करेंसी वॉलटों की तुलना में, Perfect Money खातों के सेटअप और सुरक्षित रखरखाव के लिए तकनीकी विशेषज्ञता की जरूरत नहीं पड़ती है। Perfect Money खातों में मूल्य भंडारित करके आप सुनिश्चित करते हैं कि आप वॉलट से संबद्ध जोखिमों, जैसे हार्डवेयर की विफलता/चोरी पासवर्ड का खो जाने से बच जायं जिनके कारण क्रिप्टो-करेंसी का स्थायी नुकसान होता है। Perfect Money टीम क्रिप्टो-करेंसियों की चुनौतियों का उन्मूलन करती है और आपको उनके फायदों का आनंद लेने का अवसर देती है।</p>
    </td>
  </tr>
</table>
<br>
<br>
ग्राहकों की सुविधा के लिए Perfect Money किसी भी प्रकार की ई-करेंसी से खाते के वित्तपोषण की संभावना प्रदान करता है। इस मामले में Perfect Money सबसे फायदेमंद दर पर लेनदेन का तत्काल संचालन करेगा।<br />
रप्रत्येक ग्राहक का ध्यान रखते हुए Perfect Money प्रणाली ग्राहक के खाते की न्यूनतम शेषराशि में मासिक ब्याज जमा करती है। आपका पैसा तब भी काम करता है जब आप आराम करते हैं।
<p>यदि कोई ग्राहक खाते की शेषराशि को खर्च नहीं करता है, तो पैसे जमा करने के लिए प्रयुक्त साधनों के माध्यम से ग्राहक के खाते से पैसे निकालना संभव है।</p>
<p>वायर अंतरण, किसी भी प्रकार की करेंसी में रूपांतरण और विनिमयकर्ताओं का उपयोग करके Perfect Money के ग्राहक हमेशा ही अपने पैसे सबसे कम संभव समय में प्राप्त कर सकते हैं।<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>कार्यात्मकता</b></font><br>
  <br>
  जिन ग्राहकों की व्यापार गतिविधि इंटरनेट के साथ जुड़ी हुई है उनके लिए Perfect Money प्रणाली आधुनिक आईटी व्यवसाय की जरूरतों को ध्यान में रखते हुए PM वित्त-विशेषज्ञों द्वारा विशेष रूप से विकसित निपटानों के सुविधाजनक कार्यशील साधनों सहित व्यवसाय समाधानों का एक इष्टतम पैकेज पेश करती है।<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>सुविधाजनक और विस्तृत रिपोर्टें आपके लेखांकन को सरल बनाती हैं</strong></font><br>
        नए वित्तीय संचालनों की सूचना प्राप्त करें, चार्ट और वास्तविक-समय ब्यौरा देखें।</p>
      <p><strong><font color="#990000">स्वचालित आवर्ती भुगतान सेटअप की प्रणाली</font></strong><br>
        इस साधन की परिकल्पना आपके उपक्रम के मासिक खर्चों को संगठित करने के लिए की गई है; इससे स्वचालित मोड में भुगतान संभव होते हैं। </p>
      <p><strong><font color="#990000">Perfect Money के व्यवसाय ग्राहकों के लिए वैयक्तिक समर्थन का केंद्र </font></strong><br>
        ग्राहकों के लिए ऑनलाइन सहायता 24\7\365 मोड में काम करती है। हमारे विशेषज्ञ आपकी दिलचस्पी के किसी भी प्रश्न का उत्तर देने के लिए तत्पर हैं। </p>
      <p><strong><font color="#990000">Perfect API Merchant</font></strong><br>
        कार्यात्मकता, विश्वसनीयता और सुरक्षा के मापदंडों पर हमारी राय को देखते हुए अगले कुछ वर्षों में Perfect Money के समान किसी कंपनी के प्रकट होने की हमें आशा नहीं है। Perfect Money के इंजीनियरों ने ऐसा उपकरण बनाया है जो किसी भी व्यवसाय संरचना को अधिकतम आसानी और सुरक्षा के साथ उत्पाद विक्रय, सेवा या सामग्री तक पहुँच की किसी भी ऑनलाइन प्रक्रिया संगठित करने में सक्षम करता है।<br>
      </p>
      <p><strong><font color="#990000">क्रिप्टो-करेंसी का भंडारण करें</font></strong><br>
        Perfect Money हमारे ग्राहकों को बिटकॉइन आस्तियाँ सुरक्षित रूप से भेजने, प्राप्त करने और भंडारित करने में सक्षम करता है। हम बिटकॉइन में नामित किसी भी लेनदेन को निष्पादित करने के लिए सुरक्षित और विश्वसनीय मंच प्रदान करते हैं। आपको जटिल और सुविधाहीन बिटकॉइन वॉलट डाउनलोड करने और उसका उपयोग करने की जरूरत नहीं है। अपने Perfect Money B खाते में पैसे जमा करें और प्रणाली शेष काम अपने आप कर लेगी।<br>
    </p></td>
  </tr>
</table>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>सुरक्षा</b></font><br>
<br>
Perfect Money सुरक्षा प्रणाली का विकास सूचना और वित्त सुरक्षा के क्षेत्र में विशेषज्ञों के एक वैज्ञानिक शोध समूह ने किया है। PM के इंजीनियरों ने ग्राहकों की सुरक्षा के लिए निम्नलिखित का उपयोग करके एक आदर्श उपकरण तैयार किया है:
<p>- PM के विश्लेषकों का बड़े पैमाने पर वित्तीय उपकरणों के साथ संचालन का दीर्घावधि अनुभव;<br>
  - ्राहक के प्रमाणीकरण की कृत्रिम बुद्धिमत्ता की प्रौद्योगिकियाँ;<br>
  - Perfect Money की सुरक्षा सेवा द्वारा निष्पादित सुरक्षा स्तर और ग्राहक की सुरक्षा की ऑनलाइन निगरानी।<br>
  <br>
  <b>PM के ग्राहक के सुरक्षा टूलबॉक्स में निम्नलिखित शामिल है:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">पहचान की जाँच</font></b> <br>
        इस उपकरण का उपयोग PM के खाते के ग्राहक की पहचान के लिए किया जाता है। यह उपकरण Perfect Money के लिए एक तरह की कृत्रिम आँख होता है जो किसी व्यक्ति की पहचान उसके चेहरे से नहीं करता है बल्कि खाते में प्रवेश करने के लिए प्रयुक्त कम्प्यूटर को पहचानने की संभावना प्रदान करता है। यदि ग्राहक का प्रमाणीकरण खाते के स्वामी से असंबंधित IP पतों के नेट या सबनेट से किया गया है, तो प्रणाली खाते में प्रवेश को ब्लॉक कर देती है और खाते के रजिस्ट्रेशन के समय निर्दिष्ट ई-मेल को एक अतिरिक्त सुरक्षा कोड भेजती है। IP पते में परिवर्तन Perfect Money सहायता केंद्र की मदद से वैयक्तिक रूप से किया जाता है।
        <br>
        <br>
        <b><font color="B01111">एसएमएस प्रमाणीकरण</font></b><br>
        इस प्रणाली का उपयोग ग्राहक के खाते और उसके सेल नंबर के बीच एक तार्किक कनेक्शन के निर्माण के लिए किया जाता है जिसे प्रणाली खाते के असली मालिक की पहचान करने के लिए एक पुष्टिकरण कोड भेजती है। एसएमएस लॉगिन प्रणाली खाते में अनधिकृत प्रवेश से ग्राहक की सुरक्षा की सबसे सटीक और विश्वसनीय पद्धति है क्योंकि कोड के आदान-प्रदान के पूरे संचालन और उसे खाते में प्रविष्ट करने में बहुत थोड़ा सा समय लगता है जो पता लगाने के लिए अपर्याप्त होता है।<br>
        <br>
        <b><font color="B01111">कोडकार्ड सुरक्षा </font></b> <br>
        ग्राहक को उसके ई-मेल पते पर भेजा गया ग्राफिक चित्र वाला एक कार्ड प्राप्त होता है। लेनदेन की पुष्टि के लिए प्रणाली ग्राहक को उस कार्ड से निश्चित कोड के बेतरतीब वितरण के बारे में एक प्रश्न भेजती है। कोडकार्ड लेनदेनों की पुष्टि करने का एक सुविधाजनक और विश्वसनीय उपाय है। इसने दुनिया के सबसे प्रमुख वित्तीय संस्थानों में से अधिकांश में अपनी उपयोगिता साबित की है।<br>
    </td>
  </tr>
</table>
<br>
<br>
Perfect Money का प्रजातांत्रिक दृष्टिकोण हर ग्राहक को स्वतंत्र रूप से फैसला करने में सक्षम बनाता है कि उसे अपने खाते के लिए किन सुरक्षा सेटिंग्स का उपयोग करना चाहिए। PM का हर ग्राहक स्वयं से एक समझौता करता है और खाते को अनधिकृत रूप से देखे जाने या उसका उपयोग किए जाने से बचाने के लिए अपनी सुविधानुसार उपाय का चुनाव करता है।
<p><strong>Perfect Money प्रणाली हर ग्राहक के लिए  उदार है।</strong></p>
<p>हमने आपके वित्तीय नियंत्रण के लिए सबसे प्रभावी साधन बनाए हैं और हम अपने ग्राहकों को उनकी अपनी आर्थिक नीति बनाने के लिए मुक्त हस्त देने की आशा रखते हैं। हमारे लिए हर ग्राहक बहुत महत्वपूर्ण है और यह तथ्य कि आपने Perfect Money का चुनाव किया है, हमें अपने ग्राहकों को उनके खातों को ब्लॉक किए जाने के भय के बिना अधिकतम अवसर प्रदान करने का अधिकार देता है। </p>
<p>Perfect Money सुरक्षा प्रणाली का काम हमारे ग्राहकों को उनके वित्तों के लिए बहुस्तरीय सुरक्षा प्रणाली का निर्माण करने के लिए अधिकतम अवसर प्रदान करना है। सुरक्षा प्रणाली Perfect Money के वैज्ञानिक शोध विभाग के साथ मिलकर न केवल नई सुरक्षा प्रणालियों का लगातार विकास करती है, बल्कि उसके पास प्रणाली को भेदने के सभी संभव तरीकों के प्रतिरूपण के लिए विशेषज्ञों का एक समूह भी उपलब्ध है ताकि भविष्य में प्रणाली के चारों ओर डिजिटल साम्राज्य के निर्माण के लिए इस जानकारी का उपयोग किया जा सके।</p>
<p>कम्प्यूटर स्क्रीन के दूसरी ओर स्थित हमारे ग्राहकों के लिए Perfect Money ने एकमात्र नन्हे से द्वार - मुख्य पेज पर लॉगिन फील्ड - के पीछे छिपी हजारों संभावनाओं वाला एक वित्तीय निगम बनाया है। इसलिए, अब इस द्वार को खोलने और Perfect Money के ब्रह्मांड का अन्वेषण करने का समय है!<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Perfect Money - भविष्य की भुगतान प्रणाली में  में साइनअप करें!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script>Make P2P and B2B payment with Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "hi_IN", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">सहायक कंपनी प्रोग्राम</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect Money API</font></a> | <a href="legal.php"><font color="#b50b0b">कानूनी सूचना</font></a>
| <a href="privacy.php"><font color="#b50b0b">निजता नीति</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">उपयोग की शर्तों</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">साइट मैप</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>