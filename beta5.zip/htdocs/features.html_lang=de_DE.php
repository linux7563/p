<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><title>Machen Sie  P2P- und B2B-Zahlungen mit Perfect Money</title>
<META NAME="Keywords" CONTENT="Möglichkeiten, perfectmoney, perfect money">
<META name="description" content="Das Zahlungssystem Perfect Money öffnet den einfachsten und sichersten Finanzservice für Ausführung von Geldüberweisungen in der ganzen Welt. Empfangen Sie E-Währungen, Banküberweisungen und SMS-Zahlungen auf Ihrer Webseite. Kaufen Sie Gold, senden bzw. empfangen Sie Geldmittel mit dem am meisten sichersten Zahlungssystem im Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/DE.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE" selected>Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Registrierung</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Umtauschstellen</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Reise durch die Site</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Hilfe</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Sicherheitszentrum</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="http://localhost/img/lang/de_DE/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/de_DE/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Login</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="http://localhost"><span>Home</span></a>
								<a href="about.php" class="selectedd"><span>Über uns</span></a>
								<a href="features.php"><span>Möglichkeiten</span></a>
								<a href="fees.php"><span>Gebühren</span></a>
								<a href="evoucher-info.php"><span>E-Vouchers</span></a>
                <a href="guarantees.php"><span>Garantien</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Kontakt</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Umtauschkurse in <font color='#F01010'>Perfect Money</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Öffentliche Umfrage</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Qualität von Service & Produkten<br><br>
<a href="statistics.php">Ergebnisse direkt sehen</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Die am meisten gestellten Fragen</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Für welche CMS bietet Perfect Money bereits fertige Plug-ins an? </font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Aktuell bieten wir fertige Plug-ins für die folgenden CMS: ZenCart,ShopCMS, osCommerce, ShopScript, Cube Art, VirtueMart, CS Cart, Ubercart, Xcart, PHPShop, Open Cart, Presta Shop, Drupal, WHMCS, Word Press, PHPFox, Magento, Simpla, Amiro.CMS, MODX, EMI.CMS, Moodle, Diafan.CMS, Joomla, SHOPOS, HostCMS, NetCat, Invision.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Ich habe eine Überweisung an Perfect Money über einen Transaktionsdienst getätigt, der nicht als zertifizierter Partner aufgeführt ist. Jetzt sehe ich das Geld nicht auf meinem Konto… </font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Heutzutage erstellen viele Betrüger falsche Transaktionsdienste. Wir empfehlen dringend, nur Anbieter zu nutzen, die durch unser System zertifiziert wurden, und von deren Integrität wir überzeugt sind. Gelder, die durch einen zertifizierten Transaktionsdienstleister überwiesen werden, erscheinen umgehend auf Ihrem Konto. </font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Lesen mehr Fragen and Antworten</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> Möglichkeiten</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Das System Perfect Money bietet nur solche Instrumente an, die höchstbeqem für die gegenseitigen Abrechnungen unter Kunden sind.<br><br>
Bei Benutzung von unseren Kunden aller Systemmöglichkeiten spielen für uns keine Rolle der Kennziffer vom Geldumlauf auf dem Konto sowie  die Verjährungsfrist der Registrierung im System.<br><br>Wir legen Wert auf jeden Kunde von Perfect Money und wir machen keine Unterschiede bei Betreuung unserer Kunden.
<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Individueller Benutzerstatus</b></font></p>
<p class="txt">Zwecks beiderseitiger Bequemlichkeit bei Durchführung der Transaktionen werden Alle Benutzer von Perfect Money in drei Gruppen mit entsprechenden Status geteilt. Der bestimmte Status wird dem Kunde am Ende der Registrierung verliehen: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      dieser Status wird alle neuen Kunden verliehen. Er steckt dem Kunde keine Grenzbedingungen bei Benutzung des Systems. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      dieser Status wird dem Kunde nach ein Jahr nach der Registrierung im System oder beim Erreichen von bestimmten Umschlagskennzahlen auf dem Kundenkonto verliehen. Jeder Kunde ist berechtigt  einen separaten Antrag zur Erhöhung seines Status zu stellen. Mit dem Premium-Status werden für Sie einige Provisionsgebühren verringert (im Vergleich mit Normal-Status). <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      dieser Status wird dem Kunde nach einem einseitigen Beschluss der Geschäftsleitung  von Perfect Money verliehen. Dieser Status wird meistens zur Optimierung der B2B-Zahlungen im Bezug auf Firmen mit Internet-Business.</td>
  </tr>
</table>
<br>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Überprüfungsstatus des Kunden
  </b></font></p>
<p class="txt">Wir ermutigen unsere Kunden, ein einfaches Überprüfungsverfahren durch das Hochladen von vom Staat herausgegebenen Ausweispapieren und die Angabe einer Handynummer zu bestehen. Überprüfte Konten ermöglichen Zugriff auf alle Kontofunktionen. Zu einigen Vorteilen gehören:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>
      Niedrigere Gebühren<br><br>
      Zusätzliche Sicherheitsmöglichkeiten<br><br>
      Andere Kunden werden Ihrem Konto mehr vertrauen<br><br>
      Einfache Kontowiederherstellung, wenn Sie Ihr Passwort verlieren oder aus irgendeinem Grund nicht darauf zugreifen können</td>
  </tr>
</table>
<br>
<p>Außerdem werden bei Registrierung in Perfect Money zwei Nebenstatus zur Auswahl angeboten. Ein Benutzer, der als Privatkunde registriert hat, bekommt den Nebenstatus Personal, ein Geschäftskonto – den Nebenstatus Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Schnelle und benutzerfreundliche Auffüllung des Guthabens: </b></font><br>
  <br>
  Benutzer von Perfect Money verfügt über ein benutzerfreundliches und einfaches Instrument für die P2P- und P2B-Zahlungen. Bezahlung von Waren bzw. Dienstleistungen im Internet verwandelt sich in eine ganz einfache Operation, für die unser Kunde weniger als eine Sekunde braucht. Von nun an wird Ihnen der Währungsumtausch Ihrer realen oder virtuellen Scheine in Perfect Money keine Mühe kosten. <br>
  <br>
  <b>Einnahme von Geldmitteln ins System wird folgenderweise verwirklicht:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Banküberweisung</font></b> <br>
        Ein sehr bequemer Weg der Auffüllung Ihres Guthabens.  Nach Bestätigung des Einganges von Banküberweisung werden die Gelder im Laufe von 30 Sekunden auf Ihr Perfect Money- Konto eingenommen. <br>
        <br>
        <b><font color="B01111">Elektronische Gelder</font> </b><br>
        Das System Perfect Money arbeitet mit verschiedenen elektronischen Währungen, in diesem Zusammenhang kann die Auffüllung Ihres Guthabens mit Hilfe solcher Währungen, wie webmoney, e-gold oder pecunix erfolgt werden. Solche Operationen können automatisch durch Merchants anderer elektronischen Zahlungssystemen vorgenommen werden. <br>
        <br>
        <b><font color="B01111">Unsere Partner-Umtauschpunkte </font></b><br>
        Auffüllung Ihres Guthabens ist auch mit Hilfe von unseren Partner-Umtauschpunkten möglich. Unsere Partner-Umtauschpunkte sind multivalutarisch, sie sind höchstsicher, was die Auffüllung Ihres Guthabens einfach und sicher macht.
				<br>
        <br>
        <b><font color="B01111">Aufbewahrung Guthabens in der Kryptowährung</font></b><br>
        In einer bestimmten Kryptowährung angegebene Perfect Money Konten sind eine hervorragende Möglichkeit, um Guthaben aufzubewahren. Anders als Wallets der Kryptowährung erfordern Perfect Money Konten kein Fachwissen zur Einrichtung oder sicheren Erhaltung. Die Aufbewahrung von Guthaben auf Perfect Money Konten gewährleistet die Vermeidung von mit der Wallet zusammenhängenden Risiken, die zum dauerhaften Verlust der Kryptowährung führen können, sowie Versagen/Diebstahl der Hardware oder der Verlust des Passwortes. Das Perfect Money Team hat die Herausforderungen der Kryptowährungen beseitigt, während es Ihnen ermöglicht, die Vorteile zu genießen.</p>
    </td>
  </tr>
</table>
<br>
<br>
Für uns ist die Benutzerfreundlichkeit wichtig, daher ermöglichen wir unseren Kunden, Geldmittel in jeglicher Währung auf das Konto einzunehmen. In solchem Falle kann Perfect Money für Sie beliebige Währung in andere nach einem meistgünstigsten Umtauschkurs  augenblicklich konvertieren.
<p>Wir sorgen für jeden Kunde, daher bietet das System Perfect Money unseren Kunden monatliche Bonuszinsrechnungen für den minimalen Saldo auf Benutzerkonto. <br>
Ihr Geld arbeitet für Sie sogar wenn Sie sich erholen!</p>
<p>Falls der Saldo am Benutzerkonto nicht bis zum Ende ausgegeben worden ist, können Sie mit Hilfe derselben Instrumente als für Geldeinnahme Ihr Geld vom Konto abheben. Durch Banküberweisung, Währungsumtausch oder mit Hilfe unserer Partner-Umtauschpunkte können Sie jederzeit Ihre Geldmittel in allerkürzester Frist bekommen. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Funktionalität</b></font><br>
  <br>
Für die Benutzer, deren Geschäftstätigkeit mit Internet verbunden ist, bietet Perfect Money ein optimales Paket von Businessentscheidungen, das bequeme, funktionsgemäße Abrechnungsinstrumente miteinschließt, die von Finanzfachleuten von Perfect Money zwecks Bedürfnisbefriedigung des modernen IZ-Business ausgearbeitet wurden.  <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Benutzerfreundlicher und detaillierter Auszug vereinfacht Ihre Buchhaltung </strong></font><br>
        Erfahren Sie über Ihre neue Finanztransaktionen, sehen Sie Ihre Berichte online durch. </p>
      <p><strong><font color="#990000">Automaische Bezahlung der regelmäßigen Rechnungen gemäß Zeitplan </font></strong><br>
Dieses Instrument dient zur Regelung der monatlichen Ausgaben Ihres Business, und zwar ermöglicht es regelmäßige Zahlungen automatisch ausführen zu lassen.</p>
      <p><strong><font color="#990000">Unterstützungszentrum Perfect Money für Geschäftskunden </font></strong><br>
        Unterstützungsdienst von Perfect Money Steht Ihnen gerne zur Verfügung online rund um die Uhr in Regime 24\7\365. Unsere Fachleute sind immer bereit Ihre beliebige Frage zu beantworten.</p>
      <p><strong><font color="#990000">Perfektes API Merchant </font></strong><br>
        Wir bieten Ihnen ein Zahlungsinstrument an, für das keine Analoge unter anderen elektronischen Zahlungssystemen nach Kriterien von Funktionalität, Sicherheit und Zuverlässigkeit in nächster Zukunft erstellt werden können. Ingenieure von Perfect Money erstellten solch ein Instrument, das jederzeit es allen Businessstrukturen ermöglicht, den Verkauf von Waren, Dienstleistungen bzw. Content-Zugang maximal einfach und sicher zu organisieren.<br>
      </p>
			<p><strong><font color="#990000">Aufbewahrung von Kryptowährung</font></strong><br>
        Perfect Money ermöglicht unseren Kunden, sicher Bitcoin Vermögen zu senden, zu empfangen und aufzubewahren. Wir bieten eine sichere und zuverlässige Plattform zur Durchführung beliebiger in Bitcoins angegebener Transaktionen. Sie müssen keine komplizierte und umständliche Bitcoin Wallet herunterladen und benutzen. Zahlen Sie Gelder auf Ihr Perfect Money B Konto ein und das System erledigt den Rest.<br>
      </p>
			</td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sicherheit</b></font><br>
<br>
Das Sicherheitssystem von Perfect Money wurde von einer Gruppe der Fachleute im Bereich Informations- und Finanzsicherheit ausgearbeitet.  Ingenieure von Perfect Money schafften es, ein ideales Kundenschutzinstrument zu erstellen, mit Hilfe von:
<p>- vieljährigen Arbeitserfahrungen von Perfect Money-Analysten mit großen Geldsummen im Finanzbereich; <br>
  - Technologien von künstlicher Intelligenz bei Benutzerauthentisierung; <br>
  - Online-Monitoring des Sicherheitsniveaus und des Kundenschutzes seitens Sicherheitsdiensts von Perfect Money. <br>
  <br>
  <b>Zum Kundenschutz von Perfect Money gehört:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>

    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Kontrolle der  Benutzerauthentizität </font></b> <br>
        Dieses Instrument wird zur Erkennung des wirklichen Kontoinhabers in Perfect Money benutzt. Es tritt als ein künstlicher Auge von Perfect Money auf, der obwohl kein Gesicht des Benutzers zu sehen ermöglicht, kann aber den Computer bestimmen, von wo der Eingangsversuch ins System gemacht wird. Bei Benutzerauthentisierung aus dem Netz oder Nebennetz von IP-Adressen, die zum Kontoinhaber nichts zu tun haben, wird der Kontoeingang blockiert, und das System sendet einen Sicherheitszusatzkode auf E-Mail, die bei Registrierung in System angegeben wurde. Änderung von IP-Adresse erfolgt individuell über das Unterstützungszentrum von Perfect Money.
        <br>
        <br>
        <b><font color="B01111">SMS-Autorisation </font></b><br>
        Das vorliegende System wird zwecks Erstellung einer logischen Verbindung zwischen dem Benutzerkonto und seiner Handynummer benutzt, an die ein Bestätigungskode gesendet wird. SMS-Autorisation ist eines der sichersten Schutzverfahren von unbefugtem Eingang ins System, da es die Zeit, gebraucht für das ganze Verfahren von Sendung eines Kodes und danach seiner Eintragung beim Eingang ins Systemkonto, ganz wenig und nicht genügend zum Einbruch ins System ist.
        <br>
        <br>
        <b><font color="B01111">Schlüsselkarte</font></b> <br>
        Bei einer Transaktion wird dem Benutzer eine Karte mit bildlicher Darstellung des Kodes  an E-Mail geschickt. Zur Bestätigung der Transaktion schickt das System dem Benutzer eine Anfrage über die Zufallszahl auf der Karte. Die Schlüsselkarte ist ein bequemes und sicheres Zusatzschutzmittel für die Bestätigung von Transaktionen, die  sich einen guten Ruf in größten Finanzsystemen der Welt erworben hat.<br>
    </td>
  </tr>
</table>
<br>
<br>
Demokratische Gesinnung von Perfect Money gibt jedem Kunde eine Möglichkeit selbst zu entscheiden, welche Sicherheitseinstellungen er bei Benutzung seines Kontos braucht.  Jeder Kunde von Perfect Money geht einen Kompromiss mit sich selbst ein und wählt seine Grenze zwischen der Bequemlichkeit und dem Schutz seines Kontos von einer unbefugten Sichtung bzw. Benutzung.
<p><strong>Das System Perfect Money hat ein liberales Verhältnis zu jedem Kunde. </strong></p>
<p>Wir schafften ein maximal effektives Instrument zur Finanzverwaltung und bemühen uns eine volle Handlungsfreiheit dem Kunde beim Aufbau seiner Geldpolitik zu geben. Wir legen Wert auf jeden Kunde und die Tatsache, dass er oder sie bei Perfect Money gelandet hat, fühlt uns dankbar und zwingt uns unser Bestes zu machen. Wir bemühen uns unseren Kunden maximale Möglichkeiten zu geben, ihre Finanzen zu verwalten ohne Angst zu haben, dass ihre Kontos blockiert werden können.
</p>
<p>Die erste Aufgabe des Sicherheitssystem von Perfect Money ist es einem Kunde maximale Möglichkeiten zu geben, ein Mehrniveausicherheitssystem zum Finanzschutz  aufzubauen. Das Sicherheitdienst und die Wissenschaftsabteilung von Perfect Money entwickeln ständig neue Sicherheitssystemen, außerdem verfügen sie über eine Gruppe von Fachleuten zur Nachbildung allermöglichsten Systemeinbruchsmethoden zwecks Benutzung dieser Informationen weiterhin zur  Aufbau von digitalen Festigungswerke. </p>
<p>Perfect Money schaffte für seine Kunden eine Finanzkorporation jenseits des Bildschirmes mit tausenden Möglichkeiten, die sich nur hinter  einer kleinen Tür versteckt sind – hinter dem Feld „Eingans ins System“ auf unsere Home-Seite. Wohlan, es ist schon Zeit diese kleine Tür zu öffnen, damit für sich das Weltall Perfect Money zu entdecken… <br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-german.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script>Machen Sie  P2P- und B2B-Zahlungen mit Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "de_DE", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate
              Program</font></a> | <a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Rechtsmäßige Benachrichtigung</font></a>
              | <a href="privacy.php"><font color="#b50b0b">Rechtsvorschriften</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
              | <a href="tos.html"><font color="#b50b0b">Geschäftsbedingungen</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>