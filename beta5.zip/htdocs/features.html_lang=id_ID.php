<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><title>Membuat pembayaran P2P dan B2B dengan Perfect Money</title>
<META NAME="Keywords" CONTENT="layanan-layanan, perfectmoney, perfect money">
<META name="description" content="Perfect Money menemukan sistem pembayaran yang paling aman dan layanan keuangan paling mudah untuk melakukan transfer uang diseluruh duina. Menerima mata uang elektronik, transfer bank dan SMS pembayaran pada website e-commerce Anda.Membeli emas, mengirim atau menerima uang dengan prosesor pembayaran yang paling aman di Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/ID.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID" selected>Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Daftar</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Pertukaran</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tur
</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Bantuan  </font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Pusat Keamanan</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/id_ID/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/id_ID/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Masuk</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Halaman depan</span></a>
								<a href="about.php" class="selectedd"><span>Tentang Kami</span></a>
								<a href="features.php"><span>Fitur</span></a>
								<a href="fees.php"><span>Biaya</span></a>
								<a href="evoucher-info.php"><span>E-Voucher</span></a>
                <a href="guarantees.php"><span>Jaminan</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Hubungi kami</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Kurs</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>pernyataan publik</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Kualitas Layanan & Produk<br><br>
<a href="statistics.php">Lihat hasil secara langsung</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Pertanyaan yang sering ditanyakan</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Bagaimana cara menarik dana ke mata uang digital lain?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Jika Anda ingin menarik mata uang Perfect Money Anda, Anda harus menghubungi salah satu penyedia Layanan Penukaran Bersertifikat. Daftar ini selalu tersedia di https://www.perfectmoney.is/business-partners.php . Kami sangat menyarankan agar Anda memilih penyedia dengan Skor Kepercayaan yang tinggi.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Apa yang harus saya lakukan jika verifikasi saya ditolak?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Mungkin beberapa informasi yang Anda berikan tidak lengkap atau tidak benar. Anda akan menerima notifikasi melalui sistem tiket internal beserta alasan mengapa dokumen Anda ditolak. Harap perbaiki masalahnya dan coba ajukan verifikasi lagi. Jika Anda merasa yakin ada sesuatu yang salah, silakan hubungi Dukungan Pelanggan kami.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4">Fitur <font size="4" color="#F01010">Perfect Money</font></font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Sistem Perfect Money dioperasikan dengan seperangkat peralatan yang paling nyaman bagi pelaksanaan diantara para pelanggan.
      <p>Nilai dari peralihan saldo serta periode registrasi bukanlah obyek pada penggunaan kesempatan dari sistem tersebut. </p>
      <p>Tiap pelanggan dari Perfect Money sangatlah penting dan kami tidak membuat perbedaan apapun saat melayani anda. <br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status Individual Pelanggan
  </b></font></p>
<p class="txt">Untuk membuat transaksi lebih mudah bagi kedua belah pihak, Perfect Money membagi para user berkaitan dengan tiga status yang diperoleh sistem pelanggan saat proses penyelesaian registrasi:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
Diberikan bagi seluruh Pelanggan yang teregistrasi tanpa batasan penggunaan sistem tersebut. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
Diberikan bagi Pelanggan aktif lebih dari satu tahun atau dengan mendefinisikan nilai dari peralihan saldo. Untuk mengupgrade akun Normal, Pelanggan harus mengirimkan permohonan terpisah ke Customer Service. Status Premium mengasumsikan sejumlah biaya komisi yang kurang dari biaya yang harus dibayar oleh para pengguna dengan status Normal. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
Diberikan hanya oleh Administrasi Perfect Money bagi para partner untuk mengoptimalkan pembayaran B2B dari para perusahaan yang menjalankan bisnisnya melalui internet. </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status verifikasi pelanggan
  </b></font></p>
<p class="txt">Kami menganjurkan pelanggan kami untuk melewati proses verifikasi sederhana dengan mengunggah dokumen identifikasi yang dikeluarkan pemerintah dan memberikan nomor ponsel. Akun yang terverifikasi menyediakan akses ke fungsi akun yang lengkap. Beberapa manfaat antara lain:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Biaya yang lebih rendah<br><br>
		Opsi keamanan tambahan<br><br>
		Kepercayaan yang ditingkatkan pada akun Anda dengan pelanggan lain<br><br>
		Pemulihan akun yang mudah, jika Anda kehilangan kata sandi atau tidak dapat mengaksesnya dengan alasan apa pun<br><br>
      </td>
  </tr>
</table>
<br>
<p>Anda dapat memilih sub kelompok dari akun anda tergantung tujuan dan perkiraan peralihan: Pribadi, untuk kegunaan individual atau Bisnis. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Kenyamanan dan metode-metode mudah untuk membiaya akun:</b></font><br>
  <br>
  Dengan menggunakan sistem Perfect Money, pelanggan memiliki kenyamanan dan perangkat yang mudah untuk membuat P2P dan pembayaran P2P. pembayaran untuk produk atau jasa di internet mengubah pelanggan Perfect Money menjadi sebuah operasi tunggal ketika waktu yang dihabiskan untuk operasi ini jarang sekali melebihi satu detik. Kini bukanlah sebuah masalah untuk mengubah bank notes asli ataupun virtual anda ke dalam Perfect Money.  <br>
  <br>
  <b>Penyimpanan uang ke dalam sistem dapat dilakukan sebagaimana berikut:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Transfer Bank</font></b> <br>
        Merupakan cara nyaman untuk membiayai akun anda. Setelah menerima bukti transfer uang ke akun Perfect Money akan dilakukan dalam waktu 30 detik. <br>
        <br>
        <b><font color="B01111">Mata Uang Elektronik</font> </b><br>
Sistem Perfect Money bekerja dengan angka signifikan dari mata uang elektronik dan berasal dari pembiayaan akun dapat dilakukan seperti webmoney, e-gold, pecunix. Transaksi tersebut dapat dilakukan secara otomatis melalui merchant dari  sistem-sistem pembayaran tersebut. <br>
        <br>
        <b><font color="B01111">Partner Penukaran</font></b><br>
Menampilkan cara lain untuk membiayai akun anda. Mata uang beragam dari partner penukaran di Perfect Money dan reliabilitas handal mengubah pembiayaan akun sistem menjadi operasi yang mudah dan aman. <br>
        <br>
        <b><font color="B01111">Simpan Nilai Mata Uang-Kripto</font></b><br>
Akun Perfect Money yang didenominasikan dalam mata uang-kripto tertentu merupakan kesempatan yang sangat baik untuk menyimpan nilai. Tidak seperti dompet mata uang-kripto, akun Perfect Money tidak memerlukan keahlian teknis untuk menyiapkan dan memeliharanya dengan aman. Dengan menyimpan nilai dalam akun Perfect Money akan memastikan bahwa Anda menghindari risiko terkait dompet yang dapat mengakibatkan kerugian mata uang-kripto secara permanen, seperti kegagalan perangkat lunak/pencurian atau kehilangan kata sandi. Tim Perfect Money telah menghilangkan tantangan mata uang-kripto sementara memungkinkan Anda untuk menikmati keunggulannya.</p>
    </td>
  </tr>
</table>
<br>
<br>
Demi kenyamanan pelanggan, Perfect Money menyediakan kemungkinan pembiayaan akun dengan beragam mata uang elektronik. Dalam hal ini Perfect Money akan segera melakukan transaksi pada rate yang menguntungkan. Pemeliharaan tiap pelanggan, sistem Perfect Money menambahkan bunga bulanan ke saldo akun minimum dari pelanggan. <br>
Uang anda bekerja untuk anda bahkan ketika anda beristirahat.</p>
<p>Jika saldo akun anda tidak dihabiskan oleh pelanggan, maka dimungkinkan untuk menarik uang dari akun pelanggan menggunakan peralatan yang digunakan untuk proses deposito. </p>
<p>Dengan menggunakan transfer bank, perubahan ke dalam beragam jenis mata uang dan para pelanggan dari Perfect Money dapat selalu mendapatkan uang mereka dengan waktu paling cepat. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Fungsionalitas</b></font><br>
  <br>
Bagi para pelanggan yang aktivitas bisnisnya berhubungan dengan internet, Perfect Money menawarkan paket optimal dari solusi bisnis meliputi perangkat fungsional secara khusus dikembangkan oleh para ahli keuangan Perfect Money dengan mempertimbangkan kebutuhan mutlak bisnis IT.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Kenyamanan dan laporan detail menyederhanakan akunting anda</strong></font><br>
        Dapatkan notifikasi mengenai operasi keuangan baru, lihat grafik dan laporan real-time. </p>
      <p><strong><font color="#990000">Sistem dari pengaturan Recurrent Payments otomatis</font></strong><br>
   Perangkat ini dirancang untuk mengatur pengeluaran bulanan dari perusahaan anda dan memungkinkan pembayaran secara otomatis. </p>
      <p><strong><font color="#990000">Pusat dari dukungan individual dari para pelanggan bisnis Perfect Money</font></strong><br>
        Dukungan online bagi pelanggan selama 24/7/365 dan para ahli kami siap menjawab pertanyaan anda. </p>
      <p><strong><font color="#990000">Merchant API Sempurna</font></strong><br>
Kejadian dimana diantara sistem pembayaran lainnya terhadap kriteria fungsionalitas, reliabilitas dan keamanan mungkin terjadi dalam waktu beberapa tahun mendatang. Para insinyur Perfect Money telah membuat perangkat yang memungkinkan struktur bisnis apapun untuk mengorganisasikan proses online apapun dari penjualan produk, jasa atau akses terhadap materi dengan kemudahan dan keamanan maksimal. <br>
      </p><p><strong><font color="#990000">Simpan Mata Uang-Kripto</font></strong><br>
Perfect Money memungkinkan pelanggan kami untuk mengirim, menerima dan menyimpan aset Bitcoin dengan aman. Kami menyediakan platform yang aman dan dapat diandalkan untuk melakukan transaksi yang didenominasi dalam Bitcoin. Anda tidak perlu mengunduh dan menggunakan dompet Bitcoin yang rumit dan tidak nyaman. Setorkan dana ke akun Perfect Money B dan sistem akan mengurus sisanya.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Keamanan</b></font><br>
<br>
Sistem keamanan Perfect Money telah dikembangkan oleh kelompok peneliti di bidang informasi dan keamanan keuangan. Para insinyur Perfect Money telah membuat sebuah perangkat ideal bagi keamanan pelanggan dengan menggunakan:
<p>- pengalaman jangka panjang dari para ahli Perfect Money dalam melakukan operasi keuangan dalam jumlah besar; <br>
  - teknologi dari kecerdasan buatan dari autentikasi pelanggan; <br>
  - pengawasan online dari tingkat keamanan dan perlindungan pelanggan yang dilakukan oleh jasa keamanan Perfect Money. <br>
  <br>
  <b>Toolbox keamanan dari pelanggan Perfect Money meliputi:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Pengecekan Identitas</font></b> <br>
        Perangkat ini digunakan untuk mengidentifikasi akun pelanggan Perfect Money. Instrumen ini merupakan jenis penglihatan buatan bagi Perfect Money yang tidak dapat ditunjukkan oleh pelanggan hidup namun memberikan kemungkinan untuk mengidentifikasi komputer yang digunakan untuk memasukkan akun tersebut. Jika autentikasi pelanggan dilakukan dari internet atau subnet dari alamat IP yang tidak berhubungan dengan pemilik akun, maka sistem akan mencegah orang lain masuk ke akun dan mengirimkan kode keamanan tabahan ke e-mail yang ditentukan sebelumnya saat proses registrasi akun. Pengubahan IP dibuat secara individual melalui Perfect Money Support Center.
        <br>
        <br>
        <b><font color="B01111">Autentikasi SMS</font></b><br>
        Sistem ini digunakan untuk membuat hubungan logis diantara akun pelanggan dan telepon selulernya dimana sistem akan mengirimkan kode konfirmasi untuk identifikasi dari pemilik akun sebenarnya. Sistem SMS Login adalah metode paling sempurna dan paling handal bagi perlindungan pelanggan dari masuknya akun yang tidak terotorisasi ketika waktu yang dibuthkan mengirimkan kode dan masuk ke dalam akunnya sangatlah singkat sehingga tidak mencukupi untuk operasi pembobolan.
        <br>
        <br>
        <b><font color="B01111">Perlindungan Code Card</font></b> <br>
        Dalam metode ini para pelanggan memperoleh sebuah kartu dengan foto grafis dari kode yang dikirimkan melalui e-mail. Sebagai konfirmasi dari transaksi, sistem akan mengirimkan pelanggan sebuah permohonan secara random dari kode mutlak dari kartu tersebut. Code Card adalah perlindungan nyaman dan handal untuk konfirmasi dari transaksi-transaksi yang telah menunjukkan dominasi di institusi-institusi keuangan dunia. <br>
    </td>
  </tr>
</table>
<br>
<br>
Pendekatan demokratis dari sistem pembayaran Perfect Money memungkinkan tiap pelanggan untuk mengambil keputusan secara independen tentang pengaturan keamanan yang dibuthkan untuk akun miliknya. Tiap pelanggan dari Perfect Money membuat penyesuaian dan memilih kenyamanan dari penggunaan dan perlindungan akun miliknya dari pihak atau penggunaan yang tidak terotorisasi.
<p><strong>Sistem Perfect Money yang liberal terhadap pelanggan manapun.</strong></p>
<p>Kami telah membuat perangkat efektif tertinggi untuk kontrol keuangan dan kami berharap memberikan pelanggan kebebasan membentuk aturan keuangan sendiri. Tiap pelanggan sangatlah penting bagi kami dan faktanya kami telah memilih Perfect Money, dalam hal ini menyediakan pelanggan kesempatan maksimal mengontrol akun mereka tanpa kekhawatiran akan dicegah/diblok.
</p>
<p>Tugas sistem keamanan Perfect Money adalah menyediakan kesempatan maksimal bagi pelanggan untuk pembuatan sistem keamanan bertingkat dari keuangannya. Sistem keamanan bersama dengan departemen penelitian dari Perfect Money tidak hanya secara konstan mengembangkan sistem keuangan baru namun juga memiliki kelompok spesialis untuk pemodelan seluruh metode yang mungkin dari sistem pembobolan dengan menggunakan informasi ini di masa mendatang untuk pembuatan sistem pertahanan. </p>
<p>Perfect Money telah membuat bagi para pelanggannya sebuah sisi dari layar sebuah perusahaan keuangan dengan ribuan peluang tersembunyi – bagian Login di halaman utama. Jadi, merupakan waktu penting untuk mengungkap Perfect Money secara menyeluruh. <br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script>Membuat pembayaran P2P dan B2B dengan Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "id_ID", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Program Afiliasi</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Pemberitahuan hukum</font></a>
| <a href="privacy.php"><font color="#b50b0b">Kebijakan privasi</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Persyaratan Penggunaan</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"><font color="#b50b0b">Peta Situs</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>