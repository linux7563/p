<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><title>Membuat pembayaran P2P dan B2B dengan Perfect Money</title>
<META NAME="Keywords" CONTENT="ciri-ciri, perfectmoney, perfect money">
<META name="description" content="Sistem pembayaran Perfect Money menemui perkhidmatan kewangan paling selamat dan paling senang untuk pemindahan wang di seluruh dunia.Menerima e mata wang, kawat bank dan bayaran-bayaran SMS pada laman web e-dagang anda.Membeli emas, menghantar atau menerima wang dengan kaedah pembayaran paling selamat di Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/MY.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY" selected>Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Daftar</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Log Masuk</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Penukar</font></a>`

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Pelancongan</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Bantuan</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Pusat Keselamatan</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/ms_MY/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/ms_MY/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Log Masuk</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Rumah</span></a>
								<a href="about.php" class="selectedd"><span>Tentang Kita</span></a>
								<a href="features.php"><span>Ciri-ciri</span></a>
								<a href="fees.php"><span>Yuran</span></a>
								<a href="evoucher-info.php"><span>E-Baucar</span></a>
                <a href="guarantees.php"><span>Jaminan</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Menghubungi Kami</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Kadar Penukaran <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Tinjauan Pendapat Awam</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Kualiti Perkhidmatan & Produk<br><br>
<a href="statistics.php">Lihat keputusan dalam masa nyata</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Soalan-soalan yang Kerap Ditanya</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Bagaimanakah Semakan Identiti Berfungsi?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Setiap kali seseorang cuba mengakses akaun daripada alamat IP yang berlainan dengan cubaan log masuk yang sebelumnya, atau daripada pelayar yang berlainan, sistem akan menyekat akses dan menghantar pesanan dengan kod PIN yang khas kepada e-mel pengguna yang dinyatakan ketika pendaftarannya. Pengguna diminta untuk memasukkan kod tersebut untuk mengesahkan identitinya untuk melog masuk ke dalam akaun. Pilihan didayakan secara lalai.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Apakah mata wang yang disokong oleh Perfect Money?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Setiap akaun pengguna merupakan akaun pelbagai mata wang. Ia dibahagikan dengan lanjut kepada 4 akaun mata wang yang berlainan: <br>●USD (unit PM, yang bersamaan dengan dolar Amerika Syarikat)<br>●EUR (unit PM, yang bersamaan dengan Euro)<br>●EMAS (unit PM, yang bersamaan dengan besi berharga, ditunjukkan dalam unit aun troy) <br>●Bitcoin (hak milik penerbitan kemasukan dalam pangkalan data awam global rangkaian bitcoin.org bagi pihak Perfect Money dipelihara oleh Startup Research & Investments LLC)</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4"> Ciri-ciri</font> <font size="4" color="#F01010">Perfect Money</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Sistem Perfect Money beroperasi dengan satu alat-alat itulah yang mudah untuk penyelesaian-penyelesaian di antara pelanggan-pelanggan.
      <p>Nilai bagi dibandingkan pusing ganti serta tempoh pendaftaran bukan objek pada menggunakan peluang-peluang bagi sistem.</p>
      <p>Setiap Pelanggan Perfect money adalah amat mustahak dan kita tidak membuat setiap perbezaan semasa berkhidmat anda.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status Pelanggan Individu
  </b></font></p>
<p class="txt">Untuk membuat transaksi-transaksi lebih mudah bagi pihak kedua-duanya Pembahagian Perfect Money bagi pengguna-penggunanya selaras tiga status  sistem pelanggan-pelanggan pada penyiapan pendaftaran: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      Ditugaskan untuk serba baru tanpa Pelanggan berdaftar setiap batasan pemohon pada sistem penggunaan.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      Ditugaskan untuk pelanggan aktif selama lebih 1 tahun atau dengan satu nilai pasti bagi baki perolehan. Bagi meningkatkan akaun Pelanggan Normal  perlu menghantar satu permintaan berasingan untuk Perkhidmatan Pelanggan. Status premium menganggap satu nombor bagi mentauliahkan yuran kurang daripada pelanggan-pelanggan dengan status Normal perlu membayar. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
Ditugaskan oleh tunggal budi bicara Pengurusan Perfect Money pada rakan-rakan untuk optimumkan pembayaran B2B bagi syarikat-syarikat itu selari syarikat-syarikat mereka melalui Internet.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status pengesahan pelanggan
  </b></font></p>
<p class="txt">Kami menggalakkan pelanggan kami untuk lulus proses penentusahan yang ringkas dengan memuat naik dokumen pengenalan yang dikeluarkan oleh pihak kerajaan dan menyediakan nombor mudah alih. Akaun yang disahkan menyediakan akses ke kefungsian akaun sepenuhnya. Beberapa faedah termasuk:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Yuran yang lebih rendah<br><br>
      Pilihan keselamatan tambahan<br><br>
			Kepercayaan dipertingkatkan untuk akaun anda oleh pelanggan lain<br><br>
			Pemulihan semula akaun yang mudah, sekiranya anda kehilangan kata laluan atau tidak dapat mengaksesnya atas apa-apa sebab sekalipun.<br><br></td>
  </tr>
</table>
<br>
<p>Anda boleh memilih subkumpulan bagi akaun anda bergantung pada tujuan dan diramalkan perolehan: Secara peribadi, untuk penggunaan yang masing-masing, atau Perniagaan.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Kemudahan dan Kaedah Mudah untuk Dana Akaun: </b></font><br>
  <br>
Menggunakan sistem Perfect Money Pelanggan merupakan alat mudah dan ia mudah untuk digunakan bagi menjadikan P2P dan P2B bayaran. Untuk pembayaran produk-produk atau perkhidmatan-perkhidmatan dalam Internet memusing untuk pelanggan PM kepada satu operasi mudah sebagai masa dibelanjakan pada operasi jarang sekali melebihi 1 saat. Kini ia bukan satu masalah untuk pertukaran nota bank anda yang sebenar atau maya kepada Perfect Money. <br>
  <br>
  <b>Mendeposit wang kepada sistem boleh dipersembahkan sebagai berikut:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Pindahan kawat </font></b> <br>
Adalah satu cara yang mudah untuk mendana akaun anda. Atas penerimaan bagi pemindahan wang untuk akaun PM akan dipersembahkan dalam 30 saat. <br>
        <br>
        <b><font color="B01111">Mata wang elektronik </font> </b><br>
Sistem kerja Perfect Money dengan satu jumlah penting e matawang dan disebabkan akaun pembiayaan boleh dipersembahkan oleh cara seperti e matawang sebagai webmoney, e emas, pecunix. Transaksi seumpama boleh dipersembahkan secara automatik melalui peniaga-peniaga bagi sistem-sistem pembayaran.<br>
        <br>
        <b><font color="B01111">Pertukaran Rakan</font></b><br>
Mewakili satu lagi cara untuk mendanakan akaun anda. Pelbagai mata wang bagi pertukaran rakan Perfect Money dan mereka membuktikan kebolehpercayaan pusing pembiayaan akaun sistem kepada satu peti besi yang mudah dan selamat.<br>
        <b><font color="B01111">Simpan Nilai Kripto-Mata Wang</font></b><br>
Akaun Perfect Money yang berdenominasi dengan kripto-mata wang tertentu ialah satu peluang menarik untuk menyimpan nilai. Tidak seperti dompet kripto-mata wang, akaun Perfect Money tidak memerlukan kepakaran teknikal untuk ditetapkan atau diselenggara denga selamat. Menyimpan nilai dalam akaun Perfect Money memastikan yang anda mengelakkan daripada risiko berkaitan dompet yang mungkin boleh menyebabkan kerugian kekal kripto-mata wang, seperti kegagalan perkakasan/kecurian atau kehilangan kata laluan. Pasukan Perfect Money telah menghapuskan cabaran daripada kripto-mata wang sambil membolehkan anda menikmati kelebihan yang ditawarkan.
</p>
    </td>
  </tr>
</table>
<br>
<br>
Untuk kemudahan Pelanggan Perfect Money menyediakan satu kemungkinan bagi pembiayaan dengan apa-apa jenis e mata wang. Dalam kes ini Perfect Money akan segera menjalankan transaksi pada kadar yang paling menguntungkan. Mengambil berat bagi pelanggan setiap sistem Perfect Money menambah faedah bulanan untuk mengimbangi akaun bagi pelanggan. <br>
Mengambil berat bagi pelanggan setiap sistem Perfect Money menambah faedah bulanan untuk imbangan akaun minimum bagi pelanggan.</p>
<p>Jika imbangan akaun perbelanjaan bukan dibelanjakan oleh pelanggan ia adalah mungkin untuk mengundurkan wang daripada akaun pelanggan dengan cara  menggunakan mendeposit. </p>
<p>Menggunakan pindahan kawat, penukaran kepada mana-mana jenis mata wang dan pertukaran pelanggan-pelanggan bagi Perfect Money boleh selalu mengenakan wang mereka dalam kala mungkin paling rendah. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Kefungsian</b></font><br>
  <br>
Untuk pelanggan kegiatan perniagaan siapa adalah dikaitkan dengan Internet sistem Perfect Money menawarkan satu pakej optimum penyelesaian perniagaan termasuk alat-alat fungsian penyelesaian-penyelesaian terutamanya dibangunakan oleh pembiayaan kewangan PM dengan pertimbangan keperluan negeri bagi IT perniagaan.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Mudah dan laporan terperinci memudahkan perakaunan anda</strong></font><br>
       Mendapat beritahu tentang operasi-operasi kewangan baru, carta-carta pandangan dan kenyataan masa nyata. </p>
      <p><strong><font color="#990000">Sistem pembayaran semasa automatik</font></strong><br>
        Alat ditubuhkan adalah direkabentuk untuk meletakkan ketertiban perbelanjaan bulanan bagi perusahaan anda dan membenarkan memasukkan automatik mod.</p>
      <p><strong><font color="#990000">Pusat Penyokongan individu  bagi perniagaan Pelanggan Perfect Money</font></strong><br>
        Sokongan dalam talian pelanggan-pelanggan menyisipkan mod 24\7\365, dan pakar-pakar kita adalah bersedia bagi menjawab sebarang soal untuk anda. </p>
      <p><strong><font color="#990000">Kesempurnaan Mesin API </font></strong><br>
Kejadian analogs di mana antara sistem-sistem pembayaran lain di atas kriteria kefungsian, kebolehpercayaan dan keselamatan adalah mustahil dalam beberapa tahun berikutnya. Juruteru Perfect Money telah mencipta alat yang membenarkan mana-mana struktur perniagaan untuk mengelolakan setiap proses dalam talian penjualan produk, perkhidmatan atau mengakses untuk isi dengan kemudahan maksimum dan selamat.<br>
      </p> <p><strong><font color="#990000">Simpan Kripto-Mata Wang </font></strong><br>
Perfect Money membolehkan pelanggan kami menghantar, menerima dan menyimpan aset Bitcoin dengan selamat. Kami menyediakan platform yang selamat dan boleh dipercayai untuk melaksanakan mana-mana transaksi yang berdenominasikan Bitcoin. Anda tidak perlu untuk memuat turun dan menggunakan dompet Bitcoin yang rumit dan menyusahkan. Depositkan dana ke dalam akan Perfect Money B anda dan sistem akan mengambil alih proses seterusnya.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Keselamatan</b></font><br>
<br>
Sistem keselamatan Perfect Money telah dimajukan oleh kumpulan penyelidikan saintifik pakar-pakar dalam bidang itu maklumat dan membiayai keselamatan. Jurutera PM pernah mengurus bagi mewujudkan satu alat unggul untuk keselamatan pelanggan dengan menggunakannya:
<p>- pengalaman jangka panjang bagi para penganalisis PM aktif telah menjadi besar dalam sfera kewangan; <br>
  - teknologi intelek buatan pengesahan pelanggan; <br>
  - pengawasan dalam talian tahap keselamatan dan perlindungan pelanggan dipersembahkan oleh perkhidmatan keselamatan Perfect Money. <br>
  <br>
  <b>Alat keselamatan PM Pelanggan adalah berikut:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Semakan Identiti</font></b> <br>
Alat adalah diguna untuk pengecaman bagi akaun PM planggan. Alat adalah sejenis mata buatan untuk Perfect Money yang mungkin tidak boleh menunjukkan pelanggan hanya mengenal pasti komputer biasa memasukkan akaun. Sekiranya jika pengesahan pelanggan diusahakan dari jaring itu atau subrangkaian bagi alamat-alamat IP yang tidak berkaitan pada pemilik akaun blok-blok sistem pintu masuk untuk mengakaun dan menghantar satu kod keselamatan tambahan pada e-mel ditentukan sepanjangan merupakan pendaftaran.
        <br>
        <br>
        <b><font color="B01111">Pengesahan SMS</font></b><br>
Sistem adalah diguna untuk penciptaan sambungan logik antara akaun pelanggan dan jumlah sel di mana sistem penghantaran kod pengesahan untuk pengecaman bagi akaun nyata pemilik. Sistem SMS Log masuk adalah sempurna dan kaedah boleh dipercayai bagi perlindungan pelanggan daripada tidak dibenarkan pintu masuk akaun sebagai masa telah membelanjakan pada seluruh operasi pertukaran kod dan ia memasuki kepada pelanggan adalah sangat pendek dan kekurangan untuk dilekangkan operasi.
        <br>
        <br>
        <b><font color="B01111">Perlindungan Kodkad </font></b> <br>
Dalam kaedah itu, pelanggan akan mendapat sekeping kad dengan gambar grafik kod menghantar e-mel kepadanya. Untuk pengesahan transaksi, sistem itu menghantar pelanggan satu siasatan pada penyampaian tertib rawak kod pasti daripada kad. Kodkad adalah satu ukuran perlindungan yang mudah dan boleh dipercayai untuk pengesahan transaksi-transaksi yang telah membuktikan sendiri dalam majoriti institusi kewangan terkemuka di dunia.<br>
    </td>
  </tr>
</table>
<br>
<br>
Pendekatan demokratik bagi sistem pembayaran Perfect Money membolehkan setiap pelanggan bagi menentukan secara bebas bagi seting keselamatan beliau memerlukan mengunakannya untuk akaun ia. Setiap pelanggan PM membuat satu berkompromi dengan dirinya dan memilih tepi sendirinya kemudahan menggunakan dan perlindungan bagi akaun dia daripada tidak dibenarkan pandangan atau menggunakan.
<p><strong>Sistem Kesempurnaan Wang adalah liberal kepada mana-mana Pelanggan. </strong></p>
<p>Kita telah mencipta alat-alat yang berkesan untuk membiayai kawalan dan kita diharapkan memberikan pelanggan satu kawalan bebas dalam membentuk dasar kewangan mereka sendiri. Setiap pelanggan adalah amat mustahak bagi kita dan fakta yang beliau telah memilih dengan tepat Perfect Money kami, dalam pengiktirafan ini, untuk menyediakan pelanggan dengan peluang-peluang maksimum bagi mengawal akaun mereka dengan tiada perlu khuatir ada halangan.
</p>
<p>Tugas bagi sistem keselamatan Perfect Money adalah bagi menggantikan  peluang-peluang maksimum kepada pelanggan untuk pembinaan pelbagai peringkat sistem keselamatan bagi kewangan dia. Sistem keselamatan bersama dengan jabatan penyelidikan saintifik Perfect Money bukan sahaja berterusan membangunkan sistem keselamatan malah juga pelupusannya sekumpulan pakar-pakar untuk peragaan semua cara yang mungkin pemecahan sistem mengunakan maklumat kemudian hari untuk pembinaan benteng-benting digital bagi sistem.</p>
<p>Perfect Money telah mencipta untuk pelanggan-pelanggan di mana sisi skrin satu buah perbadanan kewangan dengan beribu-ribu kemungkinan adlah satu-satunya pintu kecil - log masuk pada halaman utama. Jadi, ia adalah cukup masa untuk membukakan pintu dan bagi mencari alam semesta Perfect Money.<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script>Membuat pembayaran P2P dan B2B dengan Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ms_MY", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Program Gabungan</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Notis sah</font></a>
| <a href="privacy.php"><font color="#b50b0b">Dasar privasi</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Syarat-syarat Penggunaan</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Peta Laman</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>