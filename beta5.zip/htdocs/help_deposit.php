<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<title>Make P2P and B2B payment with Perfect Money</title>
<META NAME="Keywords" CONTENT="features, perfectmoney, perfect money">
<META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="img/geoip/GB.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US" selected>English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Signup</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Exchangers</font></a>

              &nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tour</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Help</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Security Center</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="http://localhost/img/lang/en_US/rand/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/en_US/rand/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Login</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="http://localhost"><span>Home</span></a>
								<a href="about.php" class="selectedd"><span>About Us</span></a>
								<a href="features.php"><span>Features</span></a>
								<a href="fees.php"><span>Fees</span></a>
								<a href="evoucher-info.php"><span>E-Vouchers</span></a>
                <a href="guarantees.php"><span>Guarantees</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contact Us</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Exchange Rates</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61571.32&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57487.72</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.145&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.287</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/31.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Public Poll</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Service Quality & Products<br><br>
<a href="statistics.php">View results in real-time</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Frequently Asked Questions</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">In what currency can I take a loan at the Credit Exchange?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">At the moment only USD loans for U-accounts and Euro loans for E-accounts are offered.<br /><p>

</p></font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">How can I provide an access to my personal data for the Credit Exchange users?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">You need to go to the "Settings" section, and place a check mark against those items that you want to make public. You can share your turnover, transaction history and deals. Save your choices by clicking “Save”. No further action is required.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<div class="info_box" style="width:700px">
<h3>Do you need any help working with Perfect Money?</h3>
<p>In this section you can get detailed information about the Perfect Money system. We will provide a complete and specific description of each system function and compliment it with video instructions. If after reading this document, you still have any problems or questions about the system, please contact our <a href="contact.php">Customer support service</a> »</p>
</div>

<div class="info_box arabic">
<div class="rel">
<div class="left" style="text-align:justify">
						<h3 class="upper">Deposit</h3>
						<p>Perfect Money offers its users a number of ways to load their accounts. Please review all the available methods listed in the “Deposit” section of the main menu in the Member area.</p>
						<p>If you need to load your internal Perfect Money account, you can use one of the following deposit options:</p>
						<p>
							<ul>
								<li>Internal transfer</li>
								<li>Bank wire</li>
								<li>Certified Currency Exchange partners</li>
								<li>E-Voucher</li>
								<li>Bitcoin</li>
								<li>Credit Exchange</li>
							</ul>
						</p>

						<p>This section also lists your deposit history showing the latest ten (10) transactions arranged by their status: Pending, Complete or Canceled. Each transaction displays its status.</p>
						<p><b class="red">Internal transfer</b></p>
						<p>You can make a deposit to your account by receiving an internal transfer from another user. It can be a fee for your service, or any other transfer. To receive an internal transfer, you need to notify the sender of your account number, e-mail address or the mobile phone number linked to your account.</p>

						<p><span class="red">Note:</span> The system charges a fee for processing internal transfers, and thus, the amount deposited will differ from the amount sent. Learn more about fees in the “Fees” section.</p>

						<p><b class="red">Bank wire</b></p>
						<p>Bank wire transactions are available to verified account holders only.</p>

						<p>Deposits via bank wires are easy to do. All you need is to fill out a bank wire order form indicating a bank account to be used for the transfer.</p>

						<p>It is highly recommended to provide the most complete information as it will help you in tracking the status of your bank wire.</p>

						<p>After completing the bank wire order form, please click on the "Preview" button.</p>

						<p>Check all the details, indicate the primary certified exchange service and the secondary certified exchange service from the provided list of partners, and click "Send".</p>

						<p>24 hours after your order is placed, it will be received for review by the primary certified exchange service provider. If the primary exchange service provider cannot process your request for any reason, the application is transferred to the secondary certified exchange service provider. The maximum order processing time by each exchange service is 24 hours.</p>

						<p>If your application is approved, you will receive a message in your e-mail and your internal system mailbox, including the bank details you need to send your money to. These bank details can also be found in your order in the "Deposit" section.</p>

						<p><span class="red">Note:</span> It is mandatory to indicate the invoice number provided by the system in the commentary to your bank wire.</p>

						<p>It may take up to 5 working days to receive your bank wire and to credit it to your Perfect Money account.</p>

						<p><span class="red">Note:</span> In order to carry out this transaction, your account should be verified.  The verification procedure is described in the applicable section.</p>

						<p>The minimum amount to be deposited by a bank wire is 300 USD (or its equivalent in euro and gold).</p>

						<p class="red"><b>Certified Currency Exchange partners</b></p>

						<p>Take advantage of the Perfect Money certified exchange service partners to deposit funds to your Perfect Money account. All the services listed on the certified exchange service partners’ pages were thoroughly checked and tested, therefore successful transactions are guaranteed. Each exchange partner works under its own terms and conditions and offers its own depositing methods. We recommend that you study all the proposals carefully.</p>

						<p>There are some companies among the exchange service partners who provide a wide range of options to buy Perfect Money. For example, you can load your PM account by credit card, international money transfers, cash, etc.</p>

						<p class="red"><b>e-Voucher</b></p>

						<p>e-Voucher is a 16-digit electronic certificate for loading any Perfect Money account instantly (USD, EUR, Bitcoin, and gold accounts). You can also transfer or sell this code to anyone who can use it to deposit funds into his/her Perfect Money account anytime.  You or any other Perfect Money user can instantly create an e-Voucher in the “Withdrawal” or “Statement” sections. The system does not charge a fee for deposits via e-Voucher. This option is of value to those users who do not want to show their account number to recipients.</p>

						<p class="red"><b>Bitcoin</b></p>

						<p>Bitcoin is a world famous cryptocurrency. To deposit it into an account, a user needs to create a deposit order indicating the account number and the amount to be credited with Bitcoin, preview the order and submit.</p>

						<p>After your order is submitted, the system provides the user with a Bitcoin address that the specified amount needs to be transferred to within 24 hours.</p>

						<p>Your deposit is processed when the amount in Bitcoins is received. Each payment requires at least 3 confirmations.</p>

						<p>The amount transferred to a Bitcoin address should be equal to the amount specified in the order. If you decide to make a payment in two or more increments, the total amount should be equal to the deposit amount indicated in the order form.</p>

						<p>If the amount transferred in Bitcoin differs from the one specified in the order form, the money will be credited manually. If the amount has not been credited into your account within 24 hours, please contact the support team. Service fee for deposits via Bitcoin is 0%.</p>

						<p><b class="red">Credit Exchange</b></p>
						<p>The Perfect Money system provides an opportunity to get a loan from other PM users to load an account. To enter the Credit Exchange, you need to log into your Perfect Money account and go to the appropriate section.</p>

						<p>If you need to get a loan, you have to create an application or get acquainted with current loan offers which may be of interest to you. Lenders who offer loans transfer money to a special Credit Exchange account. If a lender's proposal meets the requirements of a borrower, the borrower receives the money to his/her account after the deal is made. Such transactions can be carried out automatically or upon lender’s confirmation. Applications for providing or getting a loan include information about the loan amount, repayment term and interest rate.</p>

						<p>The Credit Exchange does not charge any additional fees. Lenders pay a standard 0.5% commission upon request to transfer money to a borrower. Borrowers also pay a standard 0.5% fee upon request to transfer money to a lender.</p>

						<p>More information is available in the appropriate section.</p>

</div>
<div class="right">
<script src="files/player/mediaelement-and-player.min.js"></script>
<link rel="stylesheet" href="files/player/mediaelementplayer.css" />
<h3 class="red">Video guide</h3>
<div class="video-frame">
<video width="640" height="360" src=files/help/full/5.mp4" type="video/mp4" poster="img/help/video_tmp_poster.jpg" controls="controls" preload="none"></video>
</div><br><br>
<script>
$('video').mediaelementplayer();
</script>

</div>
</div>
</div>
<div class="info_box">
<div class="help_nav">
					<h3 class="upper" style="margin-bottom:30px;">full help instructions</h3>
					<div class="item">
						<a href="help_getting_started.html" class="i1"><span>Introduction</span></a>
					</div>
					<div class="item">
						<a href="help_my_account.html" class="i2"><span>My account</span></a>
					</div>
					<div class="item">
						<a href="help_internal_transfer.html" class="i3"><span>Internal transfer</span></a>
					</div>
					<div class="item">
						<a href="help_exchange.html" class="i4"><span>Exchange</span></a>
					</div>
					<div class="item">
						<a href="help_deposit.html" class="i5"><span>Deposit</span></a>
					</div>
					<div class="item">
						<a href="help_withdrawal.html" class="i6"><span>Withdrawal</span></a>
					</div>
					<div class="item">
						<a href="help_statment.html" class="i7"><span>Statement</span></a>
					</div>
					<div class="item">
						<a href="help_history.html" class="i8"><span>History</span></a>
					</div>
					<div class="item">
						<a href="help_internal_mail.html" class="i9"><span>Internal mail</span></a>
					</div>
					<div class="item">
						<a href="help_analytics.html" class="i10"><span>Analytics</span></a>
					</div>
					<div class="item">
						<a href="help_user_settings.html" class="i11"><span>User settings</span></a>
					</div>
					<div class="item">
						<a href="help_security_settings.html" class="i12"><span>Security settings</span></a>
					</div>
					<div class="item">
						<a href="help_api.html" class="i13"><span>API and payments</span></a>
					</div>
					<div class="item">
						<a href="help_mobile.html" class="i14"><span>Mobile app</span></a>
					</div>
					<div class="item">
						<a href="help_credit_exchange.html" class="i15"><span>Credit Exchange</span></a>
					</div>
				</div>
</div>

          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              Make P2P and B2B payment with Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Legal notice</font></a>
| <a href="privacy.php"><font color="#b50b0b">Privacy policy</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Terms of Use</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>