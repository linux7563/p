
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <title>Make P2P and B2B payment with Perfect Money</title>
    <META NAME="Keywords" CONTENT="features, perfectmoney, perfect money">
    <META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
        <!--
        body { max-width:1650px}
        .top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
        .req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
        td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
        .ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
        h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
        #TJK_ToggleON,#TJK_ToggleOFF {display:none}
        .menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
        .txt {  text-align: justify}
        a {  color: #990000}
        -->
    </style>
    <link rel="StyleSheet" href="css/style_publics.css" type="text/css">
    <link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
    <script type="text/javascript" src="js/jquery.comp.js"></script>
    <script type="text/javascript">
        $j = jQuery.noConflict();
        jQuery(document).ready(function(){
            $j("#memo").addClass("input");
            $j("input").addClass("input");
            $j(":submit").addClass("submit");
        });
    </script>
    <script type="text/javascript" src="js/jquery.1.9.min.js"></script>
    <script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
            $('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
        });
    </script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
                    <td valign="bottom" width="65%">
                        <div align="right">
                            <form method="post" name="f" action="general/lang.php">
                                <table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="img/geoip/GB.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US" selected>English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
                                    <img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
                            <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                <a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Signup</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Exchangers</font></a>

                                &nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tour</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Help</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Security Center</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

                            </font></div>
                    </td>
                </tr>
            </table>
            <br>
        </td>
    </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
                <tr>
                    <td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="http://localhost/img/lang/en_US/rand/top2-70.png"></td>
                    <td height="8" bgcolor="#0A0A0A">
                        <div align="center">
                            <table width="216" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td><img alt="E-Currency Payment System" src="img/lang/en_US/rand/mid3-70.png"></td>
                                </tr>
                                <tr>
                                    <td>&nbsp; </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                    <td height="8" width="1%">
                        <div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <tr>
        <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
                    <td colspan="2" bgcolor="B01111">
                        <table border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Login</font></a>
                                </td>
                                <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
                                <td nowrap>
                                    <div id="menuOver">
                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                            <div  class="menu" style="min-width:780px"> <a href="http://localhost"><span>Home</span></a>
                                                <a href="about.php" class="selectedd"><span>About Us</span></a>
                                                <a href="features.php"><span>Features</span></a>
                                                <a href="fees.php"><span>Fees</span></a>
                                                <a href="evoucher-info.php"><span>E-Vouchers</span></a>
                                                <a href="guarantees.php"><span>Guarantees</span></a>
                                                <a href="faq.php"><span>F.A.Q.</span></a>
                                                <a href="contact.php"><span>Contact Us</span></a>
                                            </div>
                                        </font>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="4%" bgcolor="B01111" valign="middle">
                        <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <tr>
        <td><img src="img/blank.gif" width="820" height="1"></td>
    </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
        <td>

            <table width=100% border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
                        <font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Exchange Rates</b></font><br>
                        <table width="270" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td height="2">
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font></font></font></div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="left">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/21.png" width="265" height="130"><br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
                                        <font color="#999999">BTC:</font><br><br>
                                    </font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Arial, Helvetica, sans-serif" size="1">
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font>
                                                        </font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <font face="Arial, Helvetica, sans-serif" size="1">
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                    </font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
                                                </font>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right">
                                                    <img src="img/right_c.gif" width="8" height="36">
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/71.png" width="265" height="130"><br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
                                        <font color="#999999">GOLD Bid Price /oz:</font><br><br>
                                    </font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Arial, Helvetica, sans-serif" size="1">
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font>
                                                        </font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <font face="Arial, Helvetica, sans-serif" size="1">
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                    </font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
                                                </font>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right">
                                                    <img src="img/right_c.gif" width="8" height="36">
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/31.png" width="265" height="130">
                                </td>
                            </tr>
                        </table>
                        <br>
                        <div style="width:270px">
                            <font face="Arial, Helvetica, sans-serif" size="3"><b>Public Poll</b></font>
                            <font face="Arial, Helvetica, sans-serif" size="2"><br><br>
                                Perfect Money: Service Quality & Products<br><br>
                                <a href="statistics.php">View results in real-time</a> &raquo;</font>
                        </div>
                    </font>
                        <div align="left"><br>
                            <div class="arabic">
                                <div class="a1">
                                    <br>
                                    <font face="Arial, Helvetica, sans-serif" size="3"><b>Frequently Asked Questions</b></font> <br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
                                        <br>
                                    </b></font>
                                    <table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
                                        <tr>
                                            <td>
                                                <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">How can I create a subaccount?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
                                                    <br>
                                                </font>
                                                    <font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Subaccounts are created in the “Settings” section, under “Subaccounts”.</font><br><br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">What is the commission for a funds deposit via bank transfer?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
                                                    <br>
                                                </font>
                                                    <font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Currently we do not charge any commission fee for depositing money into your PM account via bank transfers. Some intermediate banks might charge you for the technical aspect of the transaction. </font><br><br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p><font face="Arial, Helvetica, sans-serif">
                                                    <font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
                                                <br><br>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <br>
                            <br>
                            <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
                            </b><img src="img/blank.gif" width="290" height="26"></font></div>
                    </td>
                    <td valign="top">

                        <p><font face="Arial, Helvetica, sans-serif" size="3"><b><br>
                            <font size="4">Real time poll statistics. <font color="#F01010">Perfect Money</font>: service quality &amp; products</font></b></font></p>
                        What people think about Perfect Money, its products and service quality? It's not a secret anymore.<br>
                        <p>The voting system is  highly transparent and all the voting outcomes are 100 % accessable by users. </p>
                        <br>
                        <hr>
                        <br>
                        <p><b>Usability</b> <br>
                            <br>
                            Usability is the measure of the quality of a user's experience. Perfect Money is designed to meet your needs.<br>
                            <br>
                        </p>
                        <table width="500" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="340"><img src="vote/vote.asp?t=1"></td>
                                <td valign="top">
                                    <div align="right">Average<br>
                                        <font size="4"><b>4.41 </b>/ 5</font></div>
                                </td>
                            </tr>
                        </table>
                        <p> <br>
                            <b>Functional and features</b><br>
                            <br>
                            Our goal is to provide the highest quality internet banking products and services.
                            <br>
                            <br>
                        </p>
                        <table width="500" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="340"><img src="vote/vote.asp?t=2"></td>
                                <td valign="top">
                                    <div align="right">Average<br>
                                        <font size="4"><b>4.37 </b>/ 5</font></div>
                                </td>
                            </tr>
                        </table>
                        <p><b><br>
                            Customer Support</b> <br>
                            <br>
                            The company management monitors all incoming support tickets and phone calls to determine when and where service improvements should be made. <br>
                            <br>
                        </p>
                        <table width="500" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="340"><img src="vote/vote.asp?t=3"></td>
                                <td valign="top">
                                    <div align="right">Average<br>
                                        <font size="4"><b>4.25 </b>/ 5</font></div>
                                </td>
                            </tr>
                        </table>
                        <br>
                        <p><b>Overall rating</b><br>
                            <br>
                            Does Perfect Money provide the quality service and products up to your expectations?
                            <br>
                            <br>
                        </p>
                        <table width="500" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="340"><img src="vote/vote.asp?t=4"></td>
                                <td valign="top">
                                    <div align="right">Average<br>
                                        <font size="4"><b>4.38</b> / 5</font></div>
                                </td>
                            </tr>
                        </table>
                        <br><br><br>
                    </td>
                </tr>
            </table>
        </td>
        <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
    </tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td height="2">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
                    <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
                    <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
                </tr>
            </table>
        </td>
    </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td width="341" bgcolor="#ffffff" valign="middle" height="56">
            <div align="left">&nbsp;&nbsp;
                <!--
                <a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
                <a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
                -->

            </div>
        </td>
        <td bgcolor="#ffffff" valign="top" height="56">
            <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
                <tr>
                    <td>
                        <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            Make P2P and B2B payment with Perfect Money&nbsp;<br>&copy;
                            2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
                            Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
                            <a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
                            | <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
                            Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Legal notice</font></a>
                            | <a href="privacy.php"><font color="#b50b0b">Privacy policy</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            | <a href="tos.html"><font color="#b50b0b">Terms of Use</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            | <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>
                            </small>


                        </div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>