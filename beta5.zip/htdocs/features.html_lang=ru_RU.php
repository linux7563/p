<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><title>Совершайте  P2P и B2B платежи с Perfect Money</title>
<META NAME="Keywords" CONTENT="возможности, perfectmoney, perfect money">
<META name="description" content="Платежная система Perfect Money открывает самый простой и безопасный финансовый сервис для совершения денежных переводов по всему миру.Принимайте электронную валюту, банковские переводы и смс платежи на Вашем вебсайте.Покупайте золото, отправляйте или принимайте деньги с наиболее безопасной платежной системой в Интернете">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/RU.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU" selected>Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Регистрация</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Вход</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Обменные пункты</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Тур</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Помощь</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Центр безопасности</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/ru_RU/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/ru_RU/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Вход</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Главная</span></a>
								<a href="about.php" class="selectedd"><span>О Нас</span></a>
								<a href="features.php"><span>Возможности</span></a>
								<a href="fees.php"><span>Комиссии</span></a>
								<a href="evoucher-info.php"><span>E-Ваучеры</span></a>
                <a href="guarantees.php"><span>Гарантии</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Обратная Связь</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Обменные курсы в <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Опрос</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Качество обслуживания<br><br>
<a href="statistics.php">Просмотр результатов в режиме реального времени</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Часто задаваемые вопросы</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Как система будет выбирать счет, с которого надо отправить деньги?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Система выберет тот, на котором достаточно средств для платежа. В случае если у пользователя несколько счетов с достаточным балансом, система предлагает пользователю выбрать, с какого счета совершить платеж.  </font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Можно ли сделать банковский перевод напрямую  в систему Perfect Money?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Нет, на данном этапе это невозможно. Данный вид операции проводится только через Сертифицированные обменные пункты.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Больше ответов и вопросов</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4">Возможности</font> <font size="4" color="#F01010">Perfect Money</font> </b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Система Perfect Money оперирует набором инструментов, наиболее удобным для проведения расчета между клиентами.
      <p>Показатель оборота средств на балансе и срок давности регистрации в системе не имеет значения при использовании возможностей системы.</p>
      <p>Каждый клиент Perfect Money представляет для нас большую ценность, и мы не делаем различий в обслуживании каждого из Вас.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Индивидуальный статус пользователя</b></font></p>
<p class="txt">В целях удобства совершения операций для обеих сторон в Perfect Money существует градация пользователей в соответствии с тремя статусами, получаемыми клиентами системы по завершении регистрации: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      настоящий статус присваивается всем новым пользователям системы и не накладывает каких-либо ограничений на пользование системой. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      данный тип статуса присваивается пользователю по истечении 1 года или достижении определенного показателя оборачиваемости средств на балансе. Клиент вправе сам подать отдельную заявку на повышение своего статуса. Статус Premium предполагает наличие ряда комиссионных вычетов, меньших, чем у статуса Normal.<br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      данный статус присваивается на основе решения, принимаемого администрацией Perfect Money в одностороннем порядке. Получение данного типа статуса чаще всего осуществляется для оптимизации совершения B2B платежей в отношении компаний, строящих бизнес в Интернете</td>
  </tr>
</table>
<br>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Статус проверки клиента</b></font></p>
<p class="txt">Доступ к полному набору функций счета возможен только при условии прохождения процедуры верификации. Данная процедура включает в себя загрузку документов государственного образца удостоверяющих личность, и подтверждение номера мобильного телефона. Некоторые преимущества доступные только верифицированным пользователям: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Пониженные комиссии<br><br>
     Дополнительные возможности по обеспечению безопасности счета<br><br>
		 Повышенный уровень доверия к вашему счету со стороны других пользователей<br><br>
		 Упрощенное восстановление доступа к счету в случае потери пароля или невозможности получить доступ по любой другой причине
		 </td>
  </tr>
</table>
<br>
<p>Также регистрация в Perfect Money предполагает выбор двух подстатусов. Пользователь, зарегистрированный как частное лицо, выбирает подстатус Personal, бизнес-аккаунту присваивается подстатус Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Удобные и быстрые методы пополнения баланса: </b></font><br>
  <br>
  Используя систему Perfect Money, пользователь обладает удобным и простым в использовании инструментарием для проведения P2P и P2B платежей. Оплата товара или услуги в Интернете превращается для клиента PM в простую операцию, время проведения которой занимает менее 1 секунды. Теперь конвертирование Ваших реальных или виртуальных банкнот в Perfect Money не представляет труда. <br>
  <br>
  <b>Ввод денежных средств в систему осуществляется следующими способами:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Банковский перевод. </font></b> <br>
        Это удобный способ пополнения Вашего баланса. По факту получения перевода зачисление средств на баланс PM пользователя осуществляется в течение 30 секунд.<br>
        <br>
        <b><font color="B01111">Электронные деньги.</font> </b><br>
        Система Perfect Money работает со значительным количеством электронных валют, вследствие чего пополнение счета может происходить посредством таких валют, как, например, webmoney, e-gold, pecunix. Эта операция может быть осуществлена в автоматическом режиме через мерчанты данных электронных платежных систем. <br>
        <br>
        <b><font color="B01111">Обменные пункты-партнеры.</font></b><br>
        Мультивалютность обменных пунктов-партнеров Perfect Money и их надежность, проверенная временем, делает пополнение баланса системы простой и безопасной операцией.
				<br>
        <br>
        <b><font color="B01111">Хранить активы в криптовалюте</font></b><br>
        Счета Perfect Money, номинированные в криптовалюте, являются отличной возможностью для хранения активов. В отличие от кошельков криптовалют, счета Perfect Money B не требуют технических навыков для своей настройки и безопасного использования. Кража компьютера, потеря пароля и системный сбой – это только малая часть неприятностей которые обычно заканчиваются безвозвратной потерей криптовалюты. Хранение активов на счетах Perfect Money позволит вам избежать вышеперечисленных рисков. Команда Perfect Money нивелирует сложности на пути использования криптовалют, оставляя вам возможность наслаждаться их полезными качествами.</p>
    </td>
  </tr>
</table>
<br>
<br>
Для удобства пользователей предоставляется возможность зачисления средств на баланс при использовании любого вида валюты. В этом случае в Perfect Money для Вас проведут мгновенную конвертационную операцию по самому выгодному курсу.
<p>Проявляя заботу о каждом клиенте, система Perfect Money предполагает начисление ежемесячного процента на минимальный остаток на балансе пользователя. <br>
 Ваши деньги работают на Вас, даже когда вы отдыхаете. </p>
<p>В случае если остаток на балансе не потрачен пользователем, возможна операция вывода денег со счета пользователя с помощью инструментов, используемых для ввода средств. </p>
<p>Используя банковский перевод, конвертации в любые типы валют и обменные пункты, клиенты Perfect Money всегда могут получить средства в кратчайшие сроки.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Функциональность</b></font><br>
  <br>
  Для пользователей, чья бизнес-деятельность связана с Интернетом, система Perfect Money предлагает оптимальный пакет бизнес-решений, включающий в себя удобные функциональные инструменты расчетов, специально разработанные финансистами PM для нужд современного IT-бизнеса.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Удобная и максимально детализированная выписка упростит ведение Вашей бухгалтерии</strong></font><br>
        Узнайте о новых финансовых операциях, просмотрите графики в отчете в режиме реального времени</p>
      <p><strong><font color="#990000">Система автоматической оплаты счетов по расписанию</font></strong><br>
       Данный инструмент призван упорядочить ежемесячные траты Вашего бизнеса: он позволяет проводить выплаты в автоматическом режиме.</p>
      <p><strong><font color="#990000">Центр индивидуальной поддержки бизнес-клиентов Perfect Money </font></strong><br>
        Он-лайн поддержка клиентов работает в режиме 24\7\365, и наши специалисты готовы ответить на любой интересующий Вас вопрос. </p>
      <p><strong><font color="#990000">Совершенный API Merchant</font></strong><br>
        Мы предлагаем платежный инструмент, появление аналогов которому среди других электронных платежных систем по критерию функциональности, надежности и безопасности в ближайшие годы маловероятно. Инженеры Perfect Money создали такой инструмент, с помощью которого организовать в реальном времени процесс продажи товаров, услуг или доступа к контенту стало максимально просто и безопасно в любой бизнес-структуре.  <br>
      </p><p><strong><font color="#990000">Хранить криптовалюту</font></strong><br>
        Perfect Money позволяет вам отправлять, получать и безопасно хранить активы в Bitcoin. Мы предоставляем надежную платформу для совершения любых операций, номинированных в Bitcoin. Вам больше не нужно устанавливать сложный и несколько неудобный кошелек Bitcoin. Пополните ваш счет Perfect Money B, и наша система позаботится обо всем остальном.  <br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Безопасность</b></font><br>
<br>
Система безопасности Perfect Money разрабатывалась научной группой специалистов в области информационной и финансовой безопасности. Инженерам PM удалось создать идеальный инструмент защиты пользователя, применяя:
<p>- многолетний опыт работы аналитиков PM с крупными суммами в финансовой сфере; <br>
  - технологии искусственного интеллекта для аутентификации пользователя; <br>
  - мониторинг в реальном времени уровня безопасности и защиты пользователей со стороны службы безопасности Perfect Money. <br>
  <br>
  <b>В инструментарий защиты пользователя PM входят:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Проверка подлинности пользователя</font></b> <br>
        Этот инструмент используется для распознавания реального владельца счета в PM. Он выступает своеобразным искусственным глазом для Perfect Money, который хотя и не позволяет увидеть лицо пользователя вживую, но дает возможность определить компьютер, с которого производится попытка входа в аккаунт.  В случае аутоинтефикации  пользователя из сети или подсети IP адресов, не имеющих отношение к владельцу счета, вход в аккаунт блокируется, и система высылает дополнительный код безопасности на e-mail, указанный при регистрации аккаунта. Смена IP адреса проводится в индивидуальном порядке через центр поддержки Perfect Money
        <br>
        <br>
        <b><font color="B01111">SMS-авторизация</font></b><br>
        Данная система используется в целях создания логической связи между  аккаунтом пользователя и  номером его мобильного телефона, на который для идентификации реального владельца счета высылается код подтверждения. SMS-авторизация представляет собой самый совершенный и надежный способ защиты пользователя от несанкционированного входа в аккаунт, поскольку время, затрачиваемое на всю операцию обмена кодом и ввода его в аккаунт, является критично малым и недостаточным для осуществления операции взлома.
        <br>
        <br>
        <b><font color="B01111">Кодовая карта </font></b> <br>
        Применение данного инструмента основано на обеспечении пользователя картой с графическим изображением кода, высылаемой на адрес электронной почты. Для подтверждения транзакции система высылает запрос пользователю о выдаче в случайном порядке определенного кода с данной карточки. Кодовая карта - удобная и надежная дополнительная мера защиты для подтверждения транзакций, зарекомендовавшая себя в большинстве крупных финансовых систем мира.<br>
    </td>
  </tr>
</table>
<br>
<br>
Демократичный подход платежной системы Perfect Money дает возможность каждому пользователю решать самому, какие настройки безопасности необходимы ему при использовании аккаунта. Каждый клиент PM идет на компромисс с самим собой и выбирает свою грань между удобством пользования и защитой своего аккаунта от несанкционированного просмотра или использования.
<p><strong>Система Perfect Money либерально относится к любому Пользователю.</strong></p>
<p>Мы создали максимально эффективный инструмент для управления финансами и стараемся дать полную свободу пользователю в построении своей денежной политики. Для нас важен любой клиент, и тот факт, что он остановил свой взгляд на Perfect Money, дает нам право в благодарность предоставлять пользователям максимальные возможности управления своими счетами без страха быть заблокированными.
</p>
<p>Задача системы безопасности Perfect Money - предоставить максимум возможностей пользователю для построения многоуровневой системы защиты своих финансов. Служба безопасности совместно с научным департаментом Perfect Money не только постоянно ведет разработки новых систем безопасности, но и располагает группой специалистов для моделирования всех возможных способов взлома системы, в целях применения этой информации в дальнейшем для выстраивания цифровых бастионов системы.</p>
<p>Perfect Money создала для своих клиентов по ту сторону экрана финансовую корпорацию с тысячами возможностей, скрывающихся всего лишь за маленькой дверкой - полем "Вход в Систему" на главной странице. Что ж, пришло время открыть эту дверь, открыть для себя вселенную Perfect Money…<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-rus.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script>Совершайте  P2P и B2B платежи с Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ru_RU", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Партнерская программа</font></a>
| <a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Юридический аспект</font></a>
| <a href="privacy.php"><font color="#b50b0b">Правовое положение</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
 | <a href="tos.html"><font color="#b50b0b">Условия использования</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Карта сайта</font></a></font></font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>