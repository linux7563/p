<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><title>Haga los pagos de P2P y B2B con Perfect Money</title>
<META NAME="Keywords" CONTENT="posibilidades, perfectmoney, perfect money">
<META name="description" content="El sistema de pagos Perfect Money abre el servicio financiero más sencillo y seguro para hacer transferencias de dinero en todo el mundo. Acepte divisa electrónica, transferencias bancarias y pagos de SMS en su sitio web. Compre oro, envíe o reciba dinero con el sistema de pago más seguro en el Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/ES.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES" selected>Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Registro</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Cajas de cambio</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Vuelta</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Ayuda</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centro de Seguridad</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/es_ES/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/es_ES/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Entrada</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Inicio</span></a>
								<a href="about.php" class="selectedd"><span>Principal</span></a>
								<a href="features.php"><span>Posibilidades</span></a>
								<a href="fees.php"><span>Comisión</span></a>
								<a href="evoucher-info.php"><span>Cupones Electrónicos</span></a>
                <a href="guarantees.php"><span>Garantias</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contactos</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Cursos de cambio en <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Encuesta Pública</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Servicio de Calidad y Productos<br><br>
<a href="statistics.php">Ver los resultados en tiempo real</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Preguntas más frecuentes</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">¿Qué número de cuneta debería usar para recibir dinero?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Para transferir fondos tiene que usar su número de cuenta, NO el número de ID, que es su inicio de sesión. Para encontrar su número de cuenta, por favor, inicie sesión en su cuenta. Verá sus números de cuenta en la sección de "Mis cuentas". Debería elegir la cuenta apropiada según la divisa utilizada: "U" para dólares estadounidenses (USD), "E" para euros, "G" para el oro (gold) y "B" para Bitcoin. </font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">¿Puedo combinar filtros?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Sí, sí que puede. Además, el sistema recomienda combinar filtros para optimizar la búsqueda. Por ejemplo, puede elegir su objeto, "Cuenta" y su acción, "Crear" y el sistema mostrará toda la información relacionada con la creación de cualquier cosa en su cuenta, como la creación de facturas, órdenes, etc.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Leer más Preguntas y Respuestas</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> Posibilidades</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top"><p>El sistema Perfect Money se vale de juego de instrumentos, el más conveniente para realizar el cálculo entre los clientes.</p>El exponente de ciclo de los fondos en el balance y el plazo de caducidad de registro en el sistema es indiferente cuando utilice las posibilidades del sistema. <p>Cada cliente de Perfect Money presenta un gran valor para nosotros y no hacemos diferencias en servicio a cada uno de ustedes.</p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>El status individual de usuario</b></font></p>
<p class="txt">Con el objeto de facilitar el cumplimiento de las operaciones de ambas partes en Perfect Money existe la graduación de los usuarios en correspondencia con los tres statuses recibidos por los clientes al cabo de registro: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      el status actual se promueve a todos los nuevos usuarios del sistema y sin imponer algunas restricciónes en el uso del sistema. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      este tipo de status se promueve al usuario al cabo de 1 año u obtención de un cierto exponente de rotación de los fondos en el balance. El Cliente puede presentar una solicitud individual para alzar su status. El status Premium presupone una serie de descuentos a comisión, menor que al status Normal. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      este status se promueve a la base de una decisión adoptada por la administración de Perfect Money de manera unilateral. Obtención de este tipo de status se pasa con más frecuencia a fin de optimización de la realización B2B de los pagos a las empresas que hacen sus negocios en Internet.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Estado de verificación del cliente</b></font></p>
<p class="txt">Recomendamos a nuestros clientes que se sometan a un sencillo proceso de verificación subiendo documentos de identificación emitidos por el Gobierno y facilitando un número de teléfono móvil. Las cuentas verificadas proporcionan acceso a toda la funcionalidad de la cuenta. Algunos beneficios son los siguientes:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Tarifas más reducidas<br><br>
    Opciones de seguridad adicionales<br><br>
		Una mayor confianza en su cuenta por parte de otros clientes<br><br>
		Restauración fácil de la cuenta si pierde su pasaporte o no puede acceder a ella por cualquier motivo
		</td>
  </tr>
</table>
<br>
<p>También el registro en Perfect Money presupone la selección de dos substatuses. El usuario registrado como el particular elige substatus Personal, a la cuenta de negocios investe con el substatus Businesss.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Los métodos comodos y rápidos a completar el balance: </b></font><br>
  <br>
  Usando el sistema Perfect Money, el usuario dispone de un instumental cómodo y fácil de realizar los pagos P2B y P2P. El pago de los productos o servicios en Internet para un cliente de Perfect Money se convierte en una simple operación  que  toma el tiempo menos de 1 segundo. Ahora, la conversión de sus billetes de banco reales o virtuales en Perfect Money no presenta ninguna dificultad. <br>
  <br>
  <b>La introducción de dinero en el sistema se lleva a cabo de las siguientes maneras:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Transferencia bancaria</font></b> <br>
        una manera conveniente para reponer su balance. En cuanto a la recepción de la transferencia, la acreditación en balance de usuario de PM se realiza dentro de los 30 segundos. <br>
        <br>
        <b><font color="B01111">Dinero electrónico</font> </b><br>
        el sistema Perfecto Money funciona con un gran número de divisas electrónicas, por lo tanto, la reposición de la cuenta puede producirse por medio de tales divisas como webmoney, e-gold, pecunix. Tal operación se puede realizarse en orden automático a través de merchant de dadas sistemas de pago electrónico. <br>
        <br>
        <b><font color="B01111">Casas cambiarias-socias</font></b><br>
        la reposición del balance es posible también a través de Casas cambiarias- socias. Las multidivisas de las Casas cambiarias- socias de Perfect Money y su seguridad es probada con tiempo, hace la reposición de  balance del sistema una simple y segura operación. <br>
        <br>
        <b><font color="B01111">Almacene valor de criptomoneda</font></b><br>
        Las cuentas de Perfect Money denominadas en una criptomoneda son una oportunidad excelente de acumular valor. A diferencia de las carteras de criptomoneda, las cuentas de Perfect Money no requieren experiencia técnica para configurarse o mantenerse de forma segura. Almacenar valor en cuentas de Perfect Money asegura que usted evitará los riesgos asociados a la cartera que podrían dar como resultado la pérdida permanente de la criptomoneda, como un fallo/robo del hardware o la pérdida de la contraseña. El equipo de Perfect Money ha eliminado las dificultades de las criptomonedas al mismo tiempo que le permite disfrutar de las ventajas.</p>
    </td>
  </tr>
</table>
<br>
<br>
Para la comodidad de los usuarios se promueve la oportunidad de cargar los fondos en el balance utilizando cualquier tipo de divisa. En este caso, Perfect Money hace para usted la instantánea operación de convertación según el cambio beneficioso.
<p>Mostrando la preocupación por cada cliente, el sistema Perfect Money presume de aumento del por ciento mensual en el saldo mínimo en balance del usuario. <br>
 Su dinero está trabajando para usted, incluso cuando descansa. </p>
<p>En caso de que el saldo en el balance  está gastado por el usuario, es posible la operación de retirada de dinero de la cuenta del usuario con uso de los instrumentos que se utilizan para el ingreso de los activos. Usando la transferencia bancaria la conversión en cualquier tipo de divisas y casas cambiarias, los clientes de Perfect Money siempre pueden obtener activos en el plazo más corto. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Funcionalidad</b></font><br>
  <br>
  Para los usuarios cuyas actividades comerciales están vinculadas a Internet, el sistema Perfect Money ofrece el paquete óptimo de soluciones de business que incluye los instrumentos funcionales de cálculos, elaborados por los financieros de PM especialmente para las necesidades de las modernas IT tecnologías.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>El extracto conveniente  y de máxima aplicación simplificará el mantenimiento de su contabilidad</strong></font><br>
        Más información sobre las nuevas operaciones financieras, ver gráficos en el informe online. </p>
      <p><strong><font color="#990000">El sistema de pago automático de facturas según el horario</font></strong><br>
        Dado instrumento está ivocado a arreglar los gastos mensuales de su empresa: él permite hacer el pago automáticamente. </p>
      <p><strong><font color="#990000">Centro de apoyo individual a los clientes de negocios de Perfect Money </font></strong><br>
        Apoyo en línea para los clientes funciona en régimen de 24\7\365, y nuestros expertos están preparados para responder a todas preguntas que le interesan. </p>
      <p><strong><font color="#990000">El perfecto API Merchant</font></strong><br>
        Ofrecemos un instrumento de pago, la aparición de analogías del que entre otros sistemas de pago electrónico según los criterios de funcionalidad, fiabilidad y seguridad en los próximos años es poco probable. Los ingenieros de Perfect Money han creado tal instrumento con ayuda de que organizar proceso de la venta de bienes online, de servicios o el acceso a los contentes se hizo más fácil y seguro en cualquier estructura de business. <br>
      </p><p><strong><font color="#990000">Almacene criptomoneda</font></strong><br>
        Perfect Money permite a nuestros clientes enviar, recibir y guardar activos de Bitcoin de forma segura. Proporcionamos una plataforma segura y fiable para efectuar cualquier transacción denominada en Bitcoins. No necesita descargar ni utilizar una complicada e incómoda cartera de Bitcoin. Deposite fondos a su cuenta B de Perfect Money y el sistema se ocupará del resto.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>La seguridad</b></font><br>
<br>
El sistema de seguridad de Perfect Money fue elaborada por  un equipo científico de los especalistas en área de la seguridad informativa y financiera. Los ingenieros de PM pudieron crear un instrumento ideal para la protección de los usuarios usando:
<p>- La experiencia de los analistas de PM de muchos años con las cuantías altas en el sector financiero; <br>
  - Las tecnologías de la inteligencia artificial autenticación del usuario; <br>
  - El monitoring online del nivel de seguridad y la protección de los usuarios por los servicios de seguridad de Perfect Money. <br>
  <br>
  <b>El instrumental de la seguridad del usuario de PM incluye:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Autenticación del Usuario</font></b> <br>
        Este instrumento se utiliza para reconocer el verdadero propietario de la cuenta en PM. Es una especie de ojo artificial para Perfect Money, que, a pesar de que no permite ver a la cara los usuarios, pero es  posible determinar el ordenador de cual se realiza la tentativa de acceder a su cuenta. En caso de autenticación del usuario de la red o de subred de direcciones IP no relacionadas con el propietario de la cuenta, la entrada de la cuenta se bloquea, y el sistema envía un código de seguridad adicional al correo electrónico especificado al registro de la cuenta. Cambio de la dirección IP se lleva a cabo de forma individual a través del centro de ayuda de Perfect Money.
        <br>
        <br>
        <b><font color="B01111">SMS autorización</font></b><br>
        Este sistema se utiliza con el fin de crear una relación lógica entre la cuenta del usuario y su número de teléfono móvil en el que para identificar al verdadero propietario de la cuenta se envia el código confirmativo. SMS autorización es un modo perfecto y confiable de proteger al usuario de entrada no autorizada en cuenta, ya que el tiempo empleado en toda operación de cambio de código y su entrada en cuenta, es extremadamente pequeño e insuficiente para llevar a cabo la operación de robo.
        <br>
        <br>
        <b><font color="B01111">La carta de código</font></b> <br>
        La aplicación de este instrumento se basa en suministrar al usuario la tarjeta con un código gráfico enviado en e-mail. Para confirmar la transacción el sistema envía una solicitud al usuario de entrega de forma accidental del código definido de dada tarjeta. La tarjeta de  Código es una medida adicional conveniente y segura de protección para la confirmar las transacciones, se accreditó en la mayoría de los principales sistemas financieros del mundo.<br>
    </td>
  </tr>
</table>
<br>
<br>
El enfoque democrático del sistema de pago Perfect Money permite a cada usuario decidir que ajustes le necesitan en uso de la cuenta. Cada cliente de PM  acepta un compromiso con él y elige su línea entre facilidad de uso y la protección de su cuenta de presentación o el uso no autorizado.
<p><strong>El sistema Perfect Money es liberal a cualquier Usuario. </strong></p>
<p>Hemos creado el instrumento máximamente eficaz para la gestión de las finanzas y tratamos de dar al usuario la libertad completa en la construcción de su política monetaria. Para nosotros, cada cliente es importante, y el hecho de que se detuvo en Perfect Money nos da el derecho de ofrecer en reconocimiento a  los usuarios, las posibilidades máximas en controlar sus cuentas, sin temor de ser bloqueado.
</p>
<p>La meta del sistema de seguridad de Perfect Money es prestar el máximo de oportunidades al usuario para construir el sistema de la protección de muchos niveles de sus finanzas. El Servicio de Seguridad en conjunto con el Departamento de Ciencia de Perfect Money no sólo continuamente lleva confecciónes de nuevos sistemas de seguridad, sino que dispone de un equipo de especialistas en la elaboración de modelos de todas formas posibles de los sistemas de piratería informática, con el fin de aplicar esta información en el futuro digital de los bastiones numéricas del sistema. </p>
<p>Perfect Money ha creado para sus clientes en el otro lado de la pantalla la Corporación Financiera con miles de posibilidades ocultados sólo detras de una pequeña puerta - campo "La entrada al Sistema" en la página principal. Pues bien, ha llegado el momento de abrir la puerta y descubrir para si el universo de Perfect Money.<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-spain.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script>Haga los pagos de P2P y B2B con Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "es_ES", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a> | <a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Aspecto jurídico</font></a> | <a href="privacy.php"><font color="#b50b0b">Reglamentación de derecho</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> | <a href="tos.html"><font color="#b50b0b">Términos de utilización</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"><font color="#b50b0b">Mapa del sitio</font></a></font> </font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>