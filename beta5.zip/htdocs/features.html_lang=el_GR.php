<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><title>Διενεργείτε πληρωμές P2P και B2B με το Perfect Money</title>
<META NAME="Keywords" CONTENT="δυνατότητες, perfectmoney, perfect money">
<META name="description" content="Το σύστημα πληρωμών Perfect Money ανοίγει την πιο απλή και ασφαλή οικονομική υπηρεσία για την αποστολή χρηματικών εμβασμάτων σε όλο τον κόσμο.Λαμβάνετε ηλεκτρονικό νόμισμα, τραπεζικά εμβάσματα και πληρωμές μέσω σύντομων γραπτών μηνυμάτων στον ιστοχώρο σας.Αγοράζετε χρυσό, αποστέλλετε ή λαμβάνετε χρήματα με το πιο ασφαλές σύστημα πληρωμών στο διαδίκτυο">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/GR.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR" selected>Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Εγγραφη</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Εισδος</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Ανταλλακτήρια Συναλλάγματος</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tour</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Bοήθεια</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Κέντρο ασφαλείας</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/el_GR/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/el_GR/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Εγγραφη</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Kεντρική σελίδα</span></a>
								<a href="about.php" class="selectedd"><span>Η Εταιρια</span></a>
								<a href="features.php"><span>Δυνατότητες</span></a>
								<a href="fees.php"><span>Τιμολόγιο</span></a>
								<a href="evoucher-info.php"><span>E-Vouchers</span></a>
                <a href="guarantees.php"><span>Εγγυήση</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Επικοινωνία</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Οι τιμές ανταλλαγών στην  <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/31.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Σφυγμομέτρηση Κοινής Γνώμης</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Ποιότητα Υπηρεσιών & Προϊόντα<br><br>
<a href="statistics.php">Επισκόπηση αποτελεσμάτων σε πραγματικό χρόνο</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Οι πιο συχνές ερωτήσεις</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Γιατί μπορεί να χρειάζεται να κάνω τα προσωπικά μου στοιχεία ορατά στους άλλους χρήστες του Credit Exchange;</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Οι άλλοι χρήστες του Credit Exchange βλέπουν από προεπιλογή, μόνο τον αριθμό του λογαριασμού σας και την αξιολόγηση της πιστοληπτικής σας ικανότητας. Αν κάνετε δημόσια τα προσωπικά σας στοιχεία, η εμπιστοσύνη των χρηστών σε σας θα αυξηθεί σημαντικά, πράγμα που, με τη σειρά του, θα οδηγήσει στην αύξηση του αριθμού των αμοιβαία επωφελών δραστηριοτήτων.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Για ποια CMSs υπάρχουν έτοιμα plugins που προσφέρονται από το Perfect Money;</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Αυτή τη στιγμή προσφέρουμε έτοιμα plug-ins για τα ακόλουθα CMSs:  ZenCart,ShopCMS, osCommerce, ShopScript, Cube Art, VirtueMart, CS Cart, Ubercart, Xcart, PHPShop, Open Cart, Presta Shop, Drupal, WHMCS, Word Press, PHPFox, Magento, Simpla, Amiro.CMS, MODX, EMI.CMS, Moodle, Diafan.CMS, Joomla, SHOPOS, HostCMS, NetCat, Invision.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Διαβαστε περισσοτερα Q & A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4"> Η δινατοτητες της </font><font size="4" color="#F01010">Εταιριας Perfect Money</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Το σύστημα Perfect Money χρησιμοποιεί τη συλλογή εργαλείων που είναι η πιο άνετη για πραγματοποίηση εξοφλήσεων μεταξύ των πελατών. Ο δείκτης της χρηματικής κυκλοφορίας στο ισοζύγιο και το χρονικό διάστημα δεν παίζει ρόλο στην χρησιμοποίηση των δυνατοτήτων του συστήματος.  Ο κάθε πελάτης του Perfect Money έχει για μας μεγάλη σημασία και εμείς δεν κάνουμε διάκριση στην εξυπηρέτηση του καθενός από σας.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Η προσωπική στάση του μεταχειριστή</b></font></p>
<p class="txt">Για την ευκολία πραγματοποίησης πράξεων και για τις δύο πλευρές στο Perfect Money υπάρχει η κλιμάκωση των  μεταχειριστών ανάλογα με τρεις στάσεις που αποκτούν οι  μεταχειριστές του συστήματος μετά την καταχώρηση: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      αυτή η στάση απονέμεται σε όλους τους καινούργιους μεταχειριστές του συστήματος και δεν βάζει περιορισμούς στη χρησιμοποίηση του συστήματος. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      αυτό το είδος της στάσης απονέμεται στον μεταχειριστή μετά τη λήξη ενός χρόνου ή μετά την επίτευξη του ορισμένου δείκτη της χρηματικής κυκλοφορίας στο ισοζύγιο. Ο πελάτης έχει δικαίωμα μόνος του να κάνει αίτηση για βελτίωση της στάσης του. Η στάση  Premium προϋποθέτει μια σειρά λιγότερων μεσιτικών κατακρατήσεων από εκείνων που έχει η στάση Normal. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      αυτή η στάση απονέμεται στη βάση της απόφασης που παίρνεται από τη διοίκηση του  Perfect Money στο μονομερή κανονισμό. Η απόκτηση αυτού του είδους στάσης γίνεται πιο συχνά για βελτίωση  πραγματοποίησης B2B εξοφλήσεων προς τις εταιρείες  που κτίζουν business στο Ιnternet.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Κατάσταση πιστοποίησης πελάτη</b></font></p>
<p class="txt">Ενθαρρύνουμε τους πελάτες μας να περάσουν μια απλή διαδικασία επιβεβαίωσης μεταφορτώνοντας κυβερνητικά έγγραφα ταυτότητας και παρέχοντας έναν αριθμό κινητού τηλεφώνου. Οι επιβεβαιωμένοι λογαριασμοί παρέχουν πλήρη λειτουργικότητα. Μερικά οφέλη περιλαμβάνουν: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Χαμηλότερα τέλη<br><br>
     Χαμηλότερα τέλη<br><br>
		 Πρόσθετες επιλογές ασφαλείας<br><br>
		 Ενισχυμένη εμπιστοσύνη στο λογαριασμό σας από άλλους πελάτες
		 </td>
  </tr>
</table>
<br>
<p>Επίσης η καταχώρηση στο Perfect Money προϋποθέτει επιλογή δύο υποστάσεων. Ο μεταχειριστής που είναι κατοχυρωμένος ως ιδιωτικό πρόσωπο διαλέγει την υποστάση Personal, στον business-account απονέμεται η υποστάση Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Εύκολοι και γρήγοροι τρόποι συμπλήρωσης του ισοζυγιου: </b></font><br>
  <br>
  Χρησιμοποιώντας το σύστημα Perfect Money, ο μεταχειριστής κατέχει την εύκολη και απλή στη χρήση συλλογή εργαλείων για πραγματοποίηση P2P και P2B εξοφλήσεων. Η εξόφληση ενός προϊόντος ή μιας υπηρεσίας στο Internet μεταμορφώνεται για τον πελάτη του PM στην απλή πράξη, ο χρόνος  πραγματοποίησης της οποίας θέλει λιγότερο από 1 δευτερόλεπτο. Τώρα η μετατροπή των πραγματικών ή φανταζόμενων χαρτονόμισμάτων σας στο Perfect Money δεν είναι δύσκολο. <br>
  <br>
  <b>Η εισαγωγή των χρημάτων στο σύστημα πραγματοποιείται με τους ακόλουθους τρόπους:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Με τραπεζικό έμβασμα</font></b> <br>
        εύκολος τρόπος της συμπλήρωσης του ισοζύγιού σας. Μετά την παραλαβή του εμβάσματος, η κατάθεση των χρημάτων στο  ισοζύγιο του PM μεταχειριστή πραγματοποιείται μεσά στα 30 δευτερόλεπτα. <br>
        <br>
        <b><font color="B01111">Με ηλεκτρονικά χρήματα</font> </b><br>
        το σύστημα Perfect Money δουλεύει με μεγάλο αριθμό ηλεκτρονικών συνάλλαγμάτων, γι’ αυτό το λόγο η συμπλήρωση του λογαριασμού μπορεί να γίνει μέσω των  ηλεκτρονικών συνάλλαγμάτων όπως, για παράδειγμα, webmoney, e-gold, pecunix. Η πράξη αυτή μπορεί να γίνει με την αυτόματη διάταξη μέσο των merchants αυτών των ηλεκτρονικών συστημάτων εξοφλήσεων.<br>
        <br>
        <b><font color="B01111">Γραφεία ανταλλαγής – συμπαίκτες</font></b><br>
        η συμπλήρωση του ισοζυγίου είναι δυνατόν επίσης να γίνει μέσω γραφείων ανταλλαγής – συμπαικτών. Η πολυσυναλλαγματικότητα των  γραφείων ανταλλαγής – συμπαικτών του Perfect Money και η σταθερότητά τους που ήταν αποδεικνυομένη με το χρόνο, κάνει τη συμπλήρωση του ισοζίγιου μια απλή και ασφαλή  πράξη.<br>
        <br>
        <b><font color="B01111">Αποθηκεύστε Αξίες Κρυπτο-Νομίσματος</font></b><br>
        Οι λογαριασμοί Perfect Money που εκφράζονται σε ένα συγκεκριμένο κρυπτο-νόμισμα είναι μια εξαιρετική ευκαιρία για την αποθήκευση αξιών. Σε αντίθεση με τα πορτοφόλια κρυπτο-νομίσματος, οι λογαριασμοί Perfect Money δεν απαιτούν τεχνικές γνώσεις για να δημιουργηθούν ή να διατηρηθούν με ασφάλεια. Η αποθήκευση αξιών σε λογαριασμούς Perfect Money εξασφαλίζουν ότι μπορείτε να αποφύγετε κινδύνους που σχετίζονται με το πορτοφόλι και που μπορεί να οδηγήσουν σε μόνιμη απώλεια του κρυπτο-νομίσματος, όπως αστοχία υλικού/κλοπή ή απώλεια του κωδικού πρόσβασης. Η ομάδα του Perfect Money έχει εξαλείψει τις προκλήσεις του κρυπτο-νομίσματος, ενώ σας επιτρέπει να απολαύσετε τα πλεονεκτήματα.</p>
    </td>
  </tr>
</table>
<br>
<br>
Για την ευκολία των μεταχειριστών δίνεται η δυνατότητα της κατάταξης των χρημάτων στο ισοζύγιο χρησιμοποιώντας οποιοδήποτε είδος συναλλάγματος. Σ’αυτή την περίπτωση στο Perfect Money θα κάνουν για σας την αστραπιαία μετατροπική πράξη στην επικερδή τιμή.
<p>Εκδηλώνοντας φροντίδα για τον κάθε πελάτη, το σύστημα Perfect Money προϋποθέτει το πέρασμα του μηνιαίου τόκου στο ελάχιστο υπόλοιπο στο ισοζύγιο του μεταχειριστή. <br>
 Τα χρήματά σας δουλεύουν σ’εσάς, και όταν αναπαύεσται. </p>
<p>Στην περίπτωση, αν το υπόλοιπο δεν ήταν δαπανημένο με το μεταχειριστή, είναι δυνατόν η πράξη αποχώρησης χρημάτων από το λογαριασμό μεταχειριστή με την βοήθεια των εργαλείων που χρησιμοποιούνται για εισαγωγή των χρημάτων. Χρησιμοποιώντας το τραπεζικό έμβασμα, μεταφορές στα άλλα είδη συναλλαγμάτων και γραφεία ανταλλαγής, οι μεταχειριστές του Perfect Money πάντα μπορούν να λάβουν τα χρήματά τους στη συντομότερη προθεσμία.</p>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Η λειτουργικότητα</b></font><br>
  <br>
Για τους μεταχειριστές, business-δραστηριότητα των οποίων αφορά το Internet, το σύστημα Perfect Money προτείνει το βελίτιστο πακέττο των business-αποφάσεων που έχει βολικά λειτουργικά εργαλεία των εξοφλήσεων που ήταν εκπονημένα με τους χρηματιστές του  PM ειδικά για τις ανάγκες του μοντέρνου IT business.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Το βολικό και λεπτομερές στον ανώτατο βαθμό απόσπασμα θα απλοποιήσει τη λογιστική σας</strong></font><br>
        Μάθετε για τις καινούργιες χρηματιστικές πράξεις, εξετάστε  τα διαγράμματα στον απολογισμό στον ρυθμό της τρέχουσας ώρας</p>
      <p><strong><font color="#990000">Το σύστημα του αυτόματης πληρωμής λογαριασμών με το ωράριο</font></strong><br>
        Το εργαλείο αυτό είναι καλυμμένο να τακτοποιήσει τις μηνιαίες δαπάνες του business σας: αφήνει να πραγματοποιήσετε τις εξοφλήσεις στον αυτόματο ρυθμό.</p>
      <p><strong><font color="#990000">Το κέντρο της προσωπικής υποστήριξης των business-πελατών του Perfect Money</font></strong><br>
        Η on-line υποστήριξη των πελατών λειτουργεί με τον ρυθμό 24\7\365, και οι ειδικοί μας είναι έτοιμοι να απαντήσουν σε οποιαδήποτε ενδιαφέρουσα απορία σας.</p>
      <p><strong><font color="#990000">Ο τέλειος API Merchant</font></strong><br>
        Σας προτείνουμε το πληρωνομικό εργαλείο, η εμφάνιση των αναλόγων του οποίου μεταξύ άλλων ηλεκτρονικών πληρωνομικών συστημάτων από το κριτήριο λειτουργικότητας, σταθερότητας και ασφάλειας στα επικείμενα χρόνια είναι μάλλον απίθανη. Οι μηχανικοί του Perfect Money δημιούργησαν εργαλείο, με την βοήθεια του οποίου, μπορείτε να οργανώσετε την τρέχουσα ώρα τη διαδικασία της πώλησης των προϊόντων, των υπηρεσίων ή του πλησιάσματος προς τον content, και γίινεται εύκολα και ασφαλώς για την οποιαδήποτε business δομή. <br>
      </p><p><strong><font color="#990000">Αποθηκεύστε Κρυπτο-Νόμισμα</font></strong><br>
        Το Perfect Money δίνει την ευκαιρία στους πελάτες μας να στείλουν, να λάβουν και να αποθηκεύσουν περιουσιακά στοιχεία σε Bitcoin με ασφάλεια. Παρέχουμε μια ασφαλή και αξιόπιστη πλατφόρμα για να εκτελέσετε οποιεσδήποτε συναλλαγές σε Bitcoins. Δεν χρειάζεται να κατεβάσετε και να χρησιμοποιήσετε έναν περίπλοκο και άβολο πορτοφόλι Bitcoin. Καταθέστε χρήματα στον λογαριασμό σας Perfect Money B και το σύστημα θα φροντίσει για τα υπόλοιπα.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Η ασφάλεια</b></font><br>
<br>
Το σύστημα ασφάλειας του Perfect Money εκπονήθηκε από το επιστημονικό γκρουπ ειδικών στον τομέα πληροφορικής και χρηματιστικής ασφάλειας. Οι μηχανικοι του PM κατόρθωσαν να δημιουργήσουν το ιδανικό εργαλείο ασφάλειας του μεταχειριστή, εφαρμόζοντας:
<p>- τη πολυετή εμπειρία δουλειάς των ερευνητών του PM με τα μεγάλα ποσά στον χρηματιστικό τομέα; <br>
  - τις τεχνολογίες της τεχνητής διάνοιας της αυτοσυνταύτισης του μεταχειριστή; <br>
  - το monitoring του επιπέδου ασφάλειας και υπεράσπισης μεταχειριστών  την τρέχουσα ώρα από την πλευρά της υπηρεσίας ασφάλειας του Perfect Money. <br>
  <br>
  <b>Τα εργαλεία ασφάλειας του μεταχειριστή του PM παρέχουν:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Τον έλεγχο της αυθεντικότητας μεταχειριστή </font></b> <br>
        Το εργαλείο αυτό χρησιμοποιείται για την διάκριση του πραγματικού ιδιοκτήτη του λογαριασμού στο PM. Είναι ένα ιδιόμορφο τεχνητό μάτι για το Perfect Money, το οποίο αν και δεν επιτρέπει να δει κανείς το πρόσωπο του μεταχειριστή πραγματικά, αλλά δίνει ευκαιρία να διακρίσει τον υπολογιστή, από τον οποίο γίνεται δοκιμή εισαγωγής στο account.  Στην περίπτωση αυτοσυνταύτισης του μεταχειριστή από το δίκτυο ή το  υποδίκτυο των IP διευθύνσεων που δεν έχουν σχέση με τον ιδιοκτήτη του λογαριασμού, η εισαγωγή στο account  συνασπίζεται και το σύστημα στέλνει τον επιπρόσθετο κωδικό στο e-mail που δείχθηκε στην καταχώρηση του account. Η αλλαγή της IP διεύθυνσης γίνεται ατομικό μέσο του κέντρου υποστήριξης του Perfect Money.
        <br>
        <br>
        <b><font color="B01111">Η sms αυτοέγκριση</font></b><br>
        Το σύστημα αυτό χρησιμοποιείται με σκοπό δημιούργησης λογικής σχέσης μεταξύ του account του μεταχειριστή και του αριθμού του κινητού του, στον οποίο στέλνεται ο κωδικός της επιβεβαίωσης  για την συνταύτιση του πραγματικού ιδιοκτήτη. Η sms αυτοέγκριση είναι ο πιο τέλειος και ασφαλής τρόπος υπεράσπισης του μεταχειριστή από την παράνομη εισαγωγή στο account, εφόσον η ώρα που χρειάζεται για όλη την πράξη της αλλαγής κωδικού και την εισαγωγή του στο account είναι ελάχιστη και δεν είναι επαρκής για την πραγματοποίηση της πράξης της διάρρηξης.
        <br>
        <br>
        <b><font color="B01111">Η κωδική κάρτα</font></b> <br>
        Η χρήση αυτού του εργαλείου βασίζεται στην επιδότηση του μεταχειριστή με κάρτα με γραφική απεικόνιση του κωδικού που στέλνεται στη διεύθυνση του ηλεκτρονικού ταχυδρομείου. Για επιβεβαίωση του transaction το σύστημα στέλνει την επερώτηση στον μεταχειριστή για έκδοση του ορισμένου κωδικού από την κάρτα αυτή με την τυχαία σειρά. Η κωδική κάρτα – είναι βολικό και ασφαλές πρόσθετο μέσο υπεράσπισης για την επιβεβαίωση των transactions που αποδείχτηκε τις αρετές του στα πολλά μεγάλα χρηματιστικά συστήματα του κόσμου.<br>
    </td>
  </tr>
</table>
<br>
<br>
Η δημοκρατική αντιμετώπιση του πληρωνιμικού συστήματος Perfect Money δίνει την ευκαιρία στον κάθε μεταχειριστή να αποφασίζει μόνος του ποια σημεία ασφάλειας είναι απαραίτητα για τη χρήση του account του.  Ο κάθε πελάτης του  PM έρχεται σε συμβιβασμό με τον εαυτό του και διαλέγει το όριο μεταξύ της βολικής χρήσης και ασφάλειας του account του από την παράνομη εξέταση ή χρήση.
<p><strong>Το σύστημα Perfect Money συμπεριφέρεται φιλελεύθερα στον κάθε Μεταχειριστή. </strong></p>
<p>Εμείς δημιουργήσαμε το μεγιστά αποτελεσματικό εργαλείο για την διοίκηση των χρημάτων και προσπαθούμε να δώσουμε πλήρη ελευθερία στον μεταχειριστή στην κατασκευή της δικής του χρηματιστικής πολιτικής. Για μας έχει την αξία του ο κάθε πελάτης, και το γεγονός, ότι σταμάτησε το βλέμμα του στην Perfect Money, μας δίνει το δικαίωμα να δίνουμε με ευγνωμοσύνη τις μεγιστές δυνατότητες της διοίκησης των λογαριασμών του χωρίς το φόβο να είναι συνασπισμένα.
</p>
<p>Ο σκοπός του συστήματος ασφάλειας της Perfect Money – είναι να δώσει τις μεγιστές δυνατότητες στον μεταχειριστή για την κατασκευή του πολύσταθμου συστήματος της υπεράσπισης των χρημάτων του. Η υπηρεσία ασφάλειας μαζί με το επιστημονικό τμήμα του Perfect Money όχι μόνο εκπονεί συνέχεια τα καινούργια συστήματα ασφάλειας, αλλά και έχει στη διαθεσή του ένα γρουπ ειδικών για την εκπόνηση καλούπιων όλων των δυνατών τρόπων της διάρρηξης του συστήματος με σκοπό χρησιμοποίησης της πληροφορίας αυτής στο μέλλον για την κατασκευή των ψηφιακών φρουρίων του συστήματος. </p>
<p>Η Perfect Money δημιούργησε για τους πελάτες της από την άλλη μεριά της οθόνης το χρηματιστικό σωματείο με χιλιάδες δυνατότητες που κρύβονται μονάχα πίσω από την μικρή πόρτα – πεδίο «είσοδος στο σύστημα»  στην κεντρική σελίδα. Λοιπόν, ήρθε η ώρα να ανοίξετε την πόρτα αυτή, να ανοίξετε για τον εαυτό σας στον κόσμο του Perfect Money… <br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-greece.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script>Διενεργείτε πληρωμές P2P και B2B με το Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "el_GR", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate
              Program</font></a> | <a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Νομική άποψη</font></a>
              | <a href="privacy.php"><font color="#b50b0b">Κατάσταση του δικαίου</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
              | <a href="tos.html"><font color="#b50b0b">Όροι χρήσης</font></a></font>
              | <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"><font color="#b50b0b">Χάρτης Ιστοχώρου</font></a></font>
              </font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>