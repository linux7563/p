<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><title>Niech Państwo dokonują P2P i B2B płacenia razem z  Perfect Money</title>
<META NAME="Keywords" CONTENT="możliwości, perfectmoney, perfect money">
<META name="description" content="System płatniczy Perfect Money otwarza najprostszy i najbezpieczniejszy serwis do dokonywania płaceń na całym świecie. Niech Państwo otrzymują walutę elektroniczną, przekazy bankowe oraz płace przy pomocy SMS na Państwa websaicje. Niech Państwo nabywają złoto, wysyłają lub przyjmują pieniądze razem z najbezpieczniejszym systemem płatniczym w Internecie">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/PL.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL" selected>Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Rejestracja</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Logowanie</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Kantory wymiany</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Demonstracja</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Pomoc</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centrum bezpieczeństwa</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/pl_PL/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/pl_PL/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Logowanie</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Główna</span></a>
								<a href="about.php" class="selectedd"><span>O Nas</span></a>
								<a href="features.php"><span>Możliwości</span></a>
								<a href="fees.php"><span>Prowizje</span></a>
								<a href="evoucher-info.php"><span>E-Kupony</span></a>
                <a href="guarantees.php"><span>Gwarancje</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Kontakty</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Kursy wymiany w <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Ankieta</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Jakość usług i produktów<br><br>
<a href="statistics.php">Zobacz rezultaty w czasie realnym</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Często zadawane pytania</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Do czego służy sekcja „Wyciąg”?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Tutaj możesz znaleźć informacje na temat swojej działalności finansowej. Wszystkie transakcje można śledzić za pomocą numeru transakcji (Batch). Z tej sekcji można również zarządzać e-Voucherami.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Czy za wypłaty na konto Bitcoin jest naliczana opłata?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Tak. System pobiera 0,5% kwoty przekazanej do Bitcoin.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Inne pytania i odpowiedzi</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4"> Możliwości</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">System Perfect Money operuje kompletem narzędzi najwygodniejszym dla przeprowadzenia rozliczenia pomiędzy klientami.
      <p>Wskaźnik obrotu środków bilansowych i przedawnienie rejestracji w systemie nie ma znaczenia przy korzystaniu z możliwości systemu.</p>
      <p>Każdy klient Perfect Money przedstawia dla nas dużą wartość i my nie robimy różnicy w obsłudze każdego z Państwa.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Indywidualny status użytkownika
  </b></font></p>
<p class="txt">W celu wygody realizacji operacji dla obydwóch stron w Perfect Money istnieje gradacja użytkowników zgodnie z trzema statusami, które klienci otrzymują po zakończeniu rejestracji: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      Ten status jest nadawany wszystkim nowym użytkownikom systemu i nie narzuca żadnych ograniczeń na użytkowanie systemu. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      Dany typ statusu jest nadawany użytkownikowi po upływie 1 roku lub po osiągnięciu określonego wskaźnika obrotu środków na rachunku. Klient ma prawo sam złożyć oddzielny wniosek o podwyższenie swojego statusu. Status Premium przewiduje szereg prowizji mniejszych, niż w statusie Normal. <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      Dany status nadawany jest na podstawie decyzji podejmowanej przez administrację Perfect Money w trybie jednostronnym. Nadanie danego statusu najczęściej następuje w celu optymalizacji realizacji B2B płatności w stosunku do kompani budujących biznes w Internecie.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status weryfikacji klienta</b></font></p>
<p class="txt">Zachęcamy naszych klientów do przejścia prostego procesu weryfikacyjnego polegającego na przesłaniu skanów dokumentów tożsamości wydanych przez rządową jurysdykcję klienta oraz numeru telefonu komórkowego. Pozytywna weryfikacja konta umożliwia dostęp do wszelkich funkcjonalności konta. Wśród zalet można wymienić:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Niższe opłaty<br><br>
    Dodatkowe opcje zabezpieczające<br><br>
		Większe zaufanie do Twojego konta ze strony innych użytkowników<br><br>
		Łatwe przywracanie konta w przypadku utraty hasła lub niemożności uzyskania dostępu z dowolnego powodu<br><br>
		</td>
  </tr>
</table>
<br>
<p>Rejestracja w Perfect Money dopuszcza także wybór dwóch podstatusów. Użytkownik zarejestrowany jako osoba prywatna wybiera podstatus Personal, biznes - kontu jest przyswajany podstatus Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Wygodne i szybkie metody uzupełniania rachunku: </b></font><br>
  <br>
Korzystając z systemu Perfect Money, użytkownik posiada wygodne i proste narzędzie dla realizacji P2P и P2B płatności. Opłata za towar lub usługi w Internecie przyjmuje dla klienta PM formę prostej operacji, czas przeprowadzenia której jest krótsza od sekundy. Teraz konwertowanie Państwa realnych czy wirtualnych banknotów w Perfect Money nie przedstawia trudności. <br>
  <br>
  <b>Wprowadzenie środków pieniężnych do systemu jest realizowane w następujący sposób:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Przelew bankowy</font></b> <br>
        To wygodny sposób uzupełnienia Waszego rachunku. Po otrzymaniu przekazu naliczenie środków na rachunek PM użytkownika odbywa się w ciągu  30 sekund. <br>
        <br>
        <b><font color="B01111">Elektroniczne pieniądze</font> </b><br>
        System Perfect Money pracuje ze znaczną ilością walut elektronicznych, w wyniku czego uzupełnienie rachunku może odbywać się przy pomocy takiej waluty jak na przykład, webmoney, e-gold, pecunix. Ta operacja może być zrealizowana trybie automatycznym za pośrednictwem marchandów elektronicznych danych systemów płatniczych.<br>
        <br>
        <b><font color="B01111">Partnerskie punkty wymiany</font></b><br>
        Wielowalutowość wymiennych punktów-parterów Perfect Money i ich niezawodność sprawdzona przez czas sprawia, że uzupełnienie rachunku jest operacją prostą i bezpieczną.<br>
        <br>
        <b><font color="B01111">Możliwość przechowywania kryptowaluty</font></b><br>
        Rachunki pieniężne Perfect Money prowadzone w określonej kryptowalucie idealnie nadają się do przechowywania środków finansowych. W przeciwieństwie do innych portfeli kryptowalutowych, prowadzenie rachunku w Perfect Money nie wymaga specjalistycznej wiedzy technicznej. Dzięki Perfect Money unikniesz niebezpieczeństw jakie zazwyczaj wiążą się z korzystaniem z portfela kryptowalutowego, takich jak awaria sprzętu, jego kradzież lub utrata hasła. Udało nam się wyeliminować niebezpieczeństwa związane z operowaniem kryptowalutą, tak, abyś w pełni mógł wykorzystać jej zalety.</p>
    </td>
  </tr>
</table>
<br>
<br>
W celu wygody dla użytkownika istnieje dana jest możliwość zaliczenia na rachunek środków przy użyciu dowolnej waluty. W tym wypadku w Perfect Money dla Państwa zostanie przeprowadzona momentalna operacja wymiany według najwygodniejszego kursu.
<p>Przejawiając troskę o każdego klienta, system Perfect Money przewiduje naliczanie comiesięcznych procentów na minimalne saldo rachunku użytkownika. Wasze pieniądze pracują na Was nawet wtedy, gdy odpoczywacie.<br></p>
<p>W przypadku, gdy saldo rachunku nie jest wydane przez użytkownika, możliwa jest operacja wybrania pieniędzy z konta użytkownika przy pomocy narzędzi używanych dla wpłaty środków. Wykorzystując przekaz bankowy, wymiany na inne typy walut i punkty wymiany, klienci Perfect Money zawsze mogą otrzymać środki w jak najkrótszym terminie.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Funkcjonalność</b></font><br>
  <br>
Dla użytkowników, których działalność biznesowa związana jest z Internetem, system Perfect Money proponuje optymalny pakiet rozwiązań biznesowych, zawierający wygodne, funkcjonalne narzędzia rozliczeń, specjalnie opracowane przez finansistów PM dla potrzeb nowoczesnego IT-biznesu.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Wygodny i maksymalnie dokładny wyciąg uprości prowadzenie Waszej księgowości</strong></font><br>
Dowiedzcie się Państwo o nowych operacjach finansowych, przeglądnijcie wykresy w sprawozdaniu w trybie realnego czasu.  </p>
      <p><strong><font color="#990000">System automatycznej opłaty rachunków zgodnie z planem</font></strong><br>
Dane narzędzie ma za zadanie uporządkować comiesięczne koszty Państwa biznesu: pozwala na przeprowadzenie wypłat w trybie automatycznym.</p>
      <p><strong><font color="#990000">Centrum indywidualnych konsultacji biznes-klientów Perfect Money </font></strong><br>
Konsultowanie on-line klientów pracuje w trybie 24\7\365, i nasi specjaliści są gotowi na każde interesujące Państwa pytanie. </p>
      <p><strong><font color="#990000">Doskonały API Merchant </font></strong><br>
Proponujemy narzędzie płatnicze, pojawienie się analogów którego wśród innych elektronicznych systemów płatniczych, ze względu na takie kryteria jak: funkcjonalność, niezawodność i bezpieczeństwo, w najbliższym czasie jest mało prawdopodobne. Inżynierowie Perfect Money stworzyli takie narzędzie, przy pomocy którego organizacja w realnym czasie procesu sprzedaży towarów, usług lub dostępu do kontenty zrobiła się maksymalnie prosta i bezpieczna w jakiejkolwiek strukturze biznesowej.<br>
      </p><p><strong><font color="#990000">Przechowuj kryptowalutę</font></strong><br>
Perfect Money umożliwia swoim klientom bezpieczne wysyłanie, odbieranie i przechowywanie aktywów Bitcoin. Zapewniamy bezpieczną i niezawodną platformę do przeprowadzania transakcji denominowanych w kryptowalucie Bitcoin. Nie musisz instalować i używać skomplikowanego i niewygodnego portfela Bitcoin. Po prostu dokonaj wpłaty środków na rachunek B w Perfect Money, a my zajmiemy się resztą.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Bezpieczeństwo</b></font><br>
<br>
System bezpieczeństwa Perfect Money opracowany został przez grupę naukową specjalistów w sferze bezpieczeństwa informacyjnego i finansowego. Inżynierom PM udało się stworzyć idealne narzędzie ochrony użytkownika,  korzystając z:
<p>- wieloletniego doświadczenia pracy analityków PM z dużymi sumami w sferze finansowej; <br>
  - technologii sztucznego intelektu dla uwierzytelnienia użytkownika; <br>
  - monitoring, w realnym czasie, poziomu bezpieczeństwa i ochrony użytkowników przez służbę bezpieczeństwa Perfect Money. <br>
  <br>
  <b>Do zbioru narzędzi ochrony użytkownika PM należą:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Sprawdzenie tożsamości użytkownika</font></b> <br>
        Narzędzie to jest wykorzystywane dla rozpoznania realnego właściciela rachunku w PM. Występuje ono w roli swoistego oka Perfect Money, które chociaż nie pozwala na zobaczenie twarzy użytkownika na żywo, ale daje możliwość określić komputer, z którego jest robiona próba wejścia w konto. W przypadku uwierzytelnienia użytkownika z sieci lub podsieci IP adresów, nie mających nic wspólnego z właścicielem rachunku, wejście w konto zostaje zablokowane, i system wysyła dodatkowy kod bezpieczeństwa na e-mail, podany przy rejestracji konto. Zmiana IP adresu jest przeprowadzana w indywidualnym trybie za pośrednictwem centrum konsultacyjnego Perfect Money.
        <br>
        <br>
        <b><font color="B01111">SMS - autoryzacja</font></b><br>
Dany system wykorzystywany jest w celach stworzenia logicznej łączności pomiędzy kontem użytkownika i numerem jego telefonu komórkowego, na który w celu identyfikacji realnego właściciela rachunku jest wysyłany kod potwierdzenia. SMS - autoryzacja jest najdoskonalszym i najbardziej niezawodnym sposobem ochrony użytkownika przed nie sankcjonowanym wejściem do konta, ponieważ czas potrzebny na przeprowadzenie całej operacji wymiany informacji o kodzie i wprowadzenie go do konta jest krytycznie krótki i nie pozwala na przeprowadzenie operacji włamania.
        <br>
        <br>
        <b><font color="B01111">Karta kodów</font></b> <br>
Użycie danego narzędzia oparte jest na zaopatrzeniu użytkownika w kartę z graficznym przedstawieniem kodu, wysyłaną na adres poczty elektronicznej. W celu potwierdzenia transakcji system wysyła zapytanie do użytkownika o wydanie w trybie wypadkowym określonego kodu z danej karty. Karta kodów - wygodny i niezawodny dodatkowy środek ochrony dla potwierdzenia transakcji, zarekomendowała się w większości poważnych systemów finansowych w świecie. <br>
    </td>
  </tr>
</table>
<br>
<br>
Demokratyczne podejście systemu płatności Perfect Money daje możliwość każdemu użytkownikowi decydować osobiście, jakie ustawienia bezpieczeństwa są mu potrzebne podczas korzystania z konta. Każdy klient PM idzie na kompromis z samym sobą i wybiera swoją granicę pomiędzy wygodą użytkowania i ochroną swojego konta przed nie sankcjonowanym przeglądaniem lub wykorzystaniem.
<p><strong>System Perfect Money ma liberalny stosunek do każdego użytkownika.</strong></p>
<p>Stworzyliśmy maksymalnie efektywne narzędzie dla zarządzania finansami i staramy się dać pełną swobodę użytkownikowi budowaniu swojej polityki finansowej. Dla nas ważny jest każdy klient, i ten fakt, że on zatrzymał swój wzrok na Perfect Money, daje nam prawo na znak podziękowania dawać użytkownikom maksymalne możliwości w zarządzaniu swoimi rachunkami bez strachu przed zablokowaniem.
</p>
<p>Zadanie systemu bezpieczeństwa Perfect Money – dać maksimum możliwości użytkownikowi dla zbudowania wielopoziomowego systemu ochrony swoich finansów. Służba bezpieczeństwa razem z Departamentem Naukowym Perfect Money nie tylko wciąż prowadzi prace nad nowymi systemami bezpieczeństwa, ale także dysponuje grupą specjalistów od modelowania wszystkich możliwych sposobów włamania się do systemu, w celu wykorzystania tej informacji w przyszłości, dla budowy twierdz cyfrowych systemu. </p>
<p>Perfect Money stworzyła dla swoich klientów, z drugiej strony ekranu, korporację finansową z tysiącem możliwości, ukrytych tylko za małymi drzwiczkami – polem „Wejście do systemu” na stronie głównej. No cóż, przyszedł czas na otwarcie tych drzwiczek, na otwarcie dla siebie wszechświata Perfect Money…<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script>Niech Państwo dokonują P2P i B2B płacenia razem z  Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pl_PL", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Aspekt prawny</font></a>
| <a href="privacy.php"><font color="#b50b0b">Przepis prawny</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Warunki wykorzystania</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Karta Strony Internetowej</font></a></font></font></small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>