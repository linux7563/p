<?php

include "../library.php";


if(isset($_SERVER['HTTP_REFERER']) && isset($_COOKIE['lang'])) {
    $previousPage = get_my_name($_SERVER['HTTP_REFERER'].".html");
    setcookie('lang', $_POST['lang'], 0, "/");
    if($previousPage == "" or $previousPage == null){$previousPage = "index.php";}
    header("location:../$previousPage");
}
else {
    header("location:../index.php");
    exit();
}



