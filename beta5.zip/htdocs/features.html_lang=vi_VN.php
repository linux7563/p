<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><title>Make P2P and B2B payment with Perfect Money</title>
<META NAME="Keywords" CONTENT="features, perfectmoney, perfect money">
<META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/VN.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN" selected>Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><a href="http://localhost/signup.html"><font color="#000000">Đăng ký </font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Đăng nhập</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Công ty hối đoái</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Khám phá</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Trợ giúp</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Trung tâm Bảo mật</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/vi_VN/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/vi_VN/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Đăng nhập</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Trang chủ</span></a>
								<a href="about.php" class="selectedd"><span>Giới thiệu</span></a>
								<a href="features.php"><span>Tính năng</span></a>
								<a href="fees.php"><span>Phí</span></a>
								<a href="evoucher-info.php"><span>Phiếu điện tử</span></a>
                <a href="guarantees.php"><span>Đảm bảo</span></a>
                <a href="faq.php"><span>Câu hỏi thường gặp</span></a>
                <a href="contact.php"><span>Liên hệ</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Tỷ giá Hối đoái</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61647.7&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57557.27</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2279.94&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.324</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Thăm dò ý kiến Công khai</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Chất lượng Dịch vụ & Sản phẩm<br><br>
<a href="statistics.php">Xem kết quả theo thời gian thực</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Câu hỏi thường gặp</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Hệ thống chọn tài khoản để gửi tiền từ đó bằng cách nào?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Hệ thống chọn tài khoản có đủ tiền. Nếu người dùng có vài tài khoản với số dư có đủ tiền, hệ thống sẽ yêu cầu người dùng thực hiện lựa chọn. </font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Tôi có thể rút tiền trực tiếp sang Bitcoin không?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Có, bạn có thể. Hệ thống Perfect Money cung cấp các giao dịch rút tiền trực tiếp từ tài khoản PMB của bạn sang tài khoản Bitcoin.<br>Để rút tiền từ tài khoản PMB của bạn sang tài khoản Bitcoin, bạn cần tạo một lệnh rút tiền bằng cách đi đến phần "Rút tiền" và nhấn vào nút "Bitcoin". Tiếp theo, hãy nhấn vào "Tạo đơn rút tiền mới". Trên trang mở ra, bạn sẽ nhập số tài khoản mà bạn muốn sử dụng để rút tiền, địa chỉ Bitcoin mà bạn muốn chuyển tiền đến đó và số tiền sẽ chuyển. Nhấn vào "Xem trước" để kiểm tra chắc chắn mọi thứ đã chính xác và nhấn xác nhận thanh toán.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4">Các tính năng của <font size="4" color="#F01010">Perfect Money</font></font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Hệ thống Perfect Moeny hoạt động với một loạt các công cụ thuận tiện nhất cho các khoản thanh toán giữa những khách hàng.
      <p>Giá trị của doanh thu cân đối cũng như thời gian đăng ký không ảnh hưởng đến các đặc quyền sử dụng các cơ hội của hệ thống.</p>
      <p>Mọi Khách hàng của Perfect Money đều rất quan trọng và chúng tôi không phân biệt khi phục vụ bạn.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Trạng thái cá nhân của khách hàng
  </b></font></p>
<p class="txt">Để giúp thực hiện giao dịch dễ dàng hơn cho cả hai bên, Perfect Money phân chia người dùng của mình theo ba trạng thái do hệ thống thu được từ người dùng khi hoàn thành đăng ký:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Bình thường</font></b> <br>
      Được chỉ định cho mọi Khách hàng mới đăng ký mà không áp dụng bất kỳ giới hạn sử dụng hệ thống nào.<br>
      <br>
      <b><font color="B01111">Cao cấp</font></b><br>
      Được chỉ định cho Khách hàng đã hoạt động trên 1 năm hoặc với một giá trị doanh thu cân đối nhất định. Để nâng cấp tài khoản Bình thường, Khách hàng phải gửi yêu cầu riêng đến bộ phận Dịch vụ Khách hàng. Trạng thái Cao cấp giả định rằng một số phí hoa hồng thấp hơn các khách hàng có trạng thái Bình thường thường phải trả.<br>
      <br>
      <b><font color="B01111">Đối tác</font></b> <br>
      Được chỉ định theo quyết định riêng của Ban quản trị của Perfect Money cho các đối tác để tối ưu hóa các khoản thanh toán B2B của các công ty vận hành kinh doanh qua Internet.</td>
  </tr>
</table>
<br>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Trạng thái xác minh của khách hàng
  </b></font></p>
<p class="txt">Chúng tôi khuyến khích khách hàng đáp ứng quy trình xác minh đơn giản bằng cách tải lên giấy tờ tùy thân và cung cấp số điện thoại di động. Tài khoản đã được xác minh cung cấp cho bạn quyền truy cập đến toàn bộ các chức năng của tài khoản. Một số lợi ích bao gồm:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>
      Phí thấp hơn<br><br>
      Các tùy chọn bảo mật bổ sung<br><br>
      Tăng cường tin cậy cho tài khoản của bạn thay mặt khách hàng khác.<br><br>
      Dễ dàng khôi phục tài khoản nếu bạn mất mật khẩu hoặc không thể truy cập tài khoản vì bất kỳ lý do gì</td>
  </tr>
</table>
<br>
<p>Bạn có thể chọn nhóm con của tài khoản tùy vào mục đích và doanh thu dự toán: Cá nhân, để sử dụng cá nhân, hoặc Doanh nghiệp.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Các phương pháp thuận tiện và dễ dàng nạp tiền vào tài khoản:</b></font><br>
  <br>Khi sử dụng hệ thống Perfect Money, Khách hàng có một công cụ thuận tiện và dễ sử dụng để thực hiện các thanh toán P2P và P2B. Đối với khách hàng Perfect Money, các khoản thanh toán cho sản phẩm hoặc dịch vụ trên Internet trở thành một thao tác cực kỳ đơn giản vì thời gian thực hiện thao tác này hiếm khi vượt quá 1 giây. Giờ đây, việc trao đổi tiền thật và tiền ảo trong Perfect Money không còn là một vấn đề.<br>
  <br>
  <b>Nạp tiền vào hệ thống có thể được thực hiện thông qua các cách sau:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Chuyển khoản ngân hàng</font></b> <br>
        Là cách tiện lợi để nạp tiền vào tài khoản của bạn. Sau khi nhận được biên nhận chuyển khoản, việc ghi có số tiền chuyển vào tài khoản Perfect Money của bạn sẽ được thực hiện trong vòng 30 giây.<br>
        <br>
        <b><font color="B01111">Tiền điện tử</font> </b><br>
        Hệ thống Perfect Money hoạt động với một số đáng kể các loại tiền điện tử và nhờ có điều này, việc nạp tiền vào tài khoản có thể được thực hiện bằng các phương tiện của tiền điện tử. Những giao dịch này có thể được thực hiện tự động qua các đại lý của những hệ thống thanh toán này.<br>
        <br>
        <b><font color="B01111">Đối tác Hối đoái</font></b><br>
Là một cách khác để nạp tiền vào tài khoản của bạn. Các đối tác hối đoái đa tiền tệ của Perfect Money và độ tin cậy đã được chứng minh theo thời gian của họ giúp việc nạp tiền vào tài khoản hệ thống trở thành một thao tác đơn giản và an toàn.<br>
<br>
        <b><font color="B01111">Giá trị Lưu trữ Tiền tệ Kỹ thuật số</font></b><br>
Các tài khoản Perfect Money được mệnh giá theo một loại tiền tệ kỹ thuật số cụ thể là cách tuyệt vời để lưu trữ giá trị. Ngược lại với ví tiền tệ kỹ thuật số, các tài khoản Perfect Money không yêu cầu chuyên môn kỹ thuật để thiết lập và duy trì bảo mật. Giá trị lưu trữ tại các tài khoản Perfect Money đảm bảo rằng bạn tránh được các rủi ro liên quan đến ví mà dẫn đến mất vĩnh viễn tiền tệ điện tử, chẳng hạn như lỗi phần cứng/trộm cắp và mất mật khẩu. Nhóm Perfect Money loạt bỏ các thách thức của tiền tệ kỹ thuật số trong khi cho phép bạn tận hưởng toàn bộ các lợi thế của tính năng này.
			</p>
    </td>
  </tr>
</table>
<br>
<br>
Để Khách hàng của tiện sử dụng, Perfect Money cung cấp khả năng nạp tiền bằng tài khoản bằng bất kỳ loại tiền điện tử nào. Trong trường hợp này, Perfect Moeny sẽ ngay lập tức triển khai giao dịch ở tỷ giá có lợi nhất.
<p>Quan tâm đến từng khách hàng, hệ thống Perfect Money cộng lãi suất hàng tháng vào số dư tài khoản tối thiểu của khách hàng.
Tiền của bạn sẽ sinh lời cho bạn ngay cả khi bạn nghỉ ngơi.</p>
<p>Nếu số dư tài khoản không được Khách hàng chi tiêu, khách hàng có thể rút tiền khỏi tài khoản của Khách hàng bằng các phương pháp được sử dụng khi nạp tiền.</p>
<p>Bằng cách sử dụng chuyển khoản ngân hàng, chuyển đổi sang bất kỳ loại tiền tệ và hệ thống chuyển đổi nào, khách hàng của Perfect Money luôn có thể nhận được tiền của mình trong thời gian ngắn nhất có thể.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Chức năng</b></font><br>
  <br>
Đối với các Khách hàng mà hoạt động kinh doanh có liên kết với Internet, hệ thống Perfect Money cung cấp một gói giải pháp doanh nghiệp tối ưu ba bao gồm các công cụ thanh toán chức năng thuận tiện do các chuyên gia tài chính của Pefect Money phát triển trong khi cân nhắc nhu cầu của doanh nghiệp IT hiện đại.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Các báo cáo thuận tiện và chi tiết sẽ đơn giản hóa hệ thống kế toán của bạn</strong></font><br>
        Nhận thông báo về các hoạt động tài chính mới, xem biểu đồ và sao kê theo thời gian thực. </p>
      <p><strong><font color="#990000">Thiết lập hệ thống tự động thanh toán định kỳ tự</font></strong><br>
        Công cụ này được thiết kế để sắp xếp các chi phí hàng tháng của doanh nghiệp của bạn; cho phép thực hiện thanh toán ở chế độ tự động.</p>
      <p><strong><font color="#990000">Trung tâm của Hỗ trợ của từng khách hàng doanh nghiệp của Perfect Money</font></strong><br>
        Hỗ trợ khách hàng trực tuyến hoạt động 24\7\365. Các chuyên gia của chúng tôi sẵn sàng giải đáp mọi câu hỏi mà bạn quan tâm.</p>
      <p><strong><font color="#990000">API Người bán hoàn hảo</font></strong><br>
        Dựa trên ý kiến của chúng tôi về tiêu chí của chức năng, độ tin cậy và sự an toàn, chúng tôi không kỳ vọng sẽ có bất kỳ một Perfect Money nào tương tự xuất hiện trong vài năm tới. Các kỹ sư của Perfect Money đã tạo ra một bộ công cụ như vậy cho phép bất kỳ cấu trúc doanh nghiệp nào tổ chức bất kỳ quy trình bán sản phẩm, dịch vụ trực tuyến nào hoặc truy cập vào nội dung với sự dễ dàng và mức độ an toàn ở mức tối đa.<br>
      </p><p><strong><font color="#990000">Lưu trữ Tiền tệ Kỹ thuật số</font></strong><br>
       Perfect Money cho phép các khách hàng của chúng tôi gửi, nhận và lưu trữ tài sản Bitcoint một cách an toàn. Chúng tôi cung cấp nền tảng tin cậy và an toàn để thực hiện bất kỳ dao dịch nào được mệnh giá bằng Bitcoins. Bạn không cần tải xuống và sử dụng ví Bitcoin phức tạp và không thuận tiện. Nạp tiền vào tài khoản Perfect Money B của bạn và hệ thống sẽ đảm nhận phần còn lại.<br>
      </p></td>
  </tr>
</table>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Bảo mật</b></font><br>
<br>
Hệ thống bảo mật của Perfect Money đã được phát triển bởi một nhóm các chuyên gia nghiên cứu khoa học trong lĩnh vực bảo mật thông tin và tài chính. Các kỹ sư của Perfect Money đã thành công trong việc tạo ra một công cụ lý tưởng cho bảo mật của Khách hàng bằng việc sử dụng:
<p>- kinh nghiệm lâu năm trong việc phân tích hoạt động của Perfect Money với các công cụ tài chính ở quy mô lớn; <br>
  - công nghệ trí tuệ nhân tạo trong việc xác thực Khách hàng; <br>
  - giám sát trực tuyến cấp bảo mật và bảo vệ Khách hàng được thực hiện bởi dịch vụ bảo mật của Perfect Money. <br>
  <br>
  <b>Hộp công cụ bảo mật của Khách hàng Perfect Money bao gồm các phần sau:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Kiểm tra Danh tính</font></b> <br>
        Công cụ này được sử dụng để xác định danh tính của Khách hàng có tài khoản Perfect Money. Công cụ này là đôi mắt nhân tạo cho Perfect Money mà không nhất thiết nhận dạng ai đó qua khuôn mặt của họ nhưng cung cấp khả năng nhận dạng máy tính được sử dụng để truy cập tài khoản. Trong trường hợp nếu xác thực Khách hàng được thực hiện từ mạng hoặc mạng con của các địa chỉ IP không có liên quan đến chủ sở hữu tài khoản, hệ thống sẽ chặn truy cập vào tài khoản và gửi một mã an toàn bổ sung đến địa chỉ email được xác định trong quá trình đăng ký tài khoản. Việc thay đổi một địa chỉ IP được thực hiện riêng lẻ với sự trợ giúp của Trung tâm Hỗ trợ của Perfect Money.
        <br>
        <br>
        <b><font color="B01111">Xác thực qua tin nhắn SMS</font></b><br>
        Hệ thống này được sử dụng để tạo một kết nối logic giữa tài khoản Khách hàng và số điện thoại di động của họ theo đó Hệ thống gửi một mã xác nhận để xác nhận dạng của chủ tài khoản thực sự. Hệ thống Đăng nhập bằng SMS là phương pháp tin cậy và hoàn hảo nhất trong việc bảo vệ Khách hàng khỏi bị truy cập trái phép vì thời gian dành cho toàn bộ thao tác gửi mã và truy cập vào tài khoản cực kỳ ngắn và không đủ để cho kẻ khác bắt chước thao tác hoặc tìm cách đăng nhập trái phép.
        <br>
        <br>
        <b><font color="B01111">Bảo vệ bằng CodeCard (Thẻ mã)</font></b> <br>
        Khách hàng nhận được một thẻ vớ một hình đồ họa có chứa mã được gửi đến địa chỉ email của họ. Để xác nhận giao dịch, hệ thống gửi cho Khách hàng một truy vấn khi gửi mã xác định theo thứ tự ngẫu nhiên từ thẻ đó. CodeCard là biện pháp bảo vệ tin cậy và thuận tiện để xác nhận giao dịch. Phương pháp này tự nó đã chứng minh tính hiệu quả trong phần lớn các tổ chức tài chính nổi tiếng trên thế giới. <br>
    </td>
  </tr>
</table>
<br>
<br>
Phương pháp tiếp cận bình đẳng của hệ thống thanh toán Perfect Money cho phép mọi Khách hàng tự quyết định cài đặt bảo mật nào mà họ cần sử dụng cho tài khoản của mình. Mọi khách hàng của Perfect Money đều tự dàn xếp với chính mình và chọn biện pháp thuận tiện cho chính mình để sử dụng và bảo vệ tài khoản khỏi bị xem hoặc sử dụng trái phép.
<p><strong>Hệ thống Perfect Money tự do và bình đẳng cho mọi Khách hàng.</strong></p>
<p>Chúng tôi đã tạo những công cụ hiệu quả nhất để bạn kiểm soát tài chính của mình và chúng tôi hy vọng cung cấp cho Khách hàng của mình một cách tiếp cận tự do trong việc hình thành chính sách tiền tệ của chính họ. Mọi Khách hàng đều rất quan trọng đối với chúng tôi và việc bạn đã chọn Perfect Money cho phép chúng tôi cung cấp cho Khách hàng các cơ hội tối đa để kiểm soát tài khoản của họ mà không sợ bị chặn.
</p>
<p>Nhiệm vụ của hệ thống bảo mật của Perfect Money là cung cấp các cơ hội tối đa đến Khách hàng để xây dựng hệ thống bảo mật nhiều tầng cho các khoản mục tài chính của họ. Hệ thống bảo mật này cùng với phòng nghiên cứu khoa học của Perfect Money không chỉ liên tục phát triển các hệ thống bảo mật mới mà còn có một nhóm các chuyên gia sẵn sàng làm mẫu mọi biện pháp xâm nhập hệ thống có thể để sử dụng thông tin này trong tương lai nhằm xây dựng các pháo đài kỹ thuật số xung quanh hệ thống. </p>
<p>Đối với các Khách hàng ở phía bên kia của màn hình máy tính, Perfect Money đã tạo ra một doanh nghiệp tài chính với hàng ngàn khả năng ẩn sau cánh cửa nhỏ xíu duy nhất - mục đăng nhập trên trang chính. Như vậy, đã đến lúc mở cánh cửa này và khám phá vũ trụ của Perfect Money!<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Hãy đăng ký Perfect Money - hệ thống thanh toán của Tương lai!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script>Make P2P and B2B payment with Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "vi_VN", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Chương trình Liên kết</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">API Perfect Money</font></a> | <a href="legal.php"><font color="#b50b0b">Thông báo pháp lý</font></a>
| <a href="privacy.php"><font color="#b50b0b">Chính sách bảo mật</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Điều khoản Sử dụng</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Sơ đồ trang</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>