<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><title>نفذوا دفعنات P2P و B2B مع Perfect Money</title>
<META NAME="Keywords" CONTENT="امكانيات، PerfectMoney، Perfect Money">
<META name="description" content="نظام الدفع Perfect Money يفتح اسهل الخخدمة المالية و أكثر الأمن لتنفيذ التحويلات المالية عبر العالم كله. خذوا العملة الإيليكترونية، التحويلت البنكية و دفعات SMS في موقعتكم الإيليكترونية.اشترو الذهب، أرسلوا أو تقبلوا النقود مع النظام الدفعي أكثر الأمن في الإينتيرنيت">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/AE.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE" selected>العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">التسجيل</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">الدخول</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">محولي البنوك الإلكترونية</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">جولة سريعة </font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">مركز المساعدة</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">المركز الأمني</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/ar_AE/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/ar_AE/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">الدخول</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>الرئيسية</span></a>
								<a href="about.php" class="selectedd"><span>معلومات عنا</span></a>
								<a href="features.php"><span>المميزات</span></a>
								<a href="fees.php"><span>الرسوم</span></a>
								<a href="evoucher-info.php"><span>e-Voucher</span></a>
                <a href="guarantees.php"><span>الضمانات</span></a>
                <a href="faq.php"><span>الأسئلة الشائعة</span></a>
                <a href="contact.php"><span>اتصل بنا</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> الأسعار العملة الصرافية في </b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/31.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>إستطلاعات الآراء العامة</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
جودة خدمات ومنتجات Perfect Money<br><br>
<a href="statistics.php">اضطلع على النتائج في وقت صدورها</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>الاسئلة التي تسأل كثيرا </b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">ما هو القرض الشخصي؟</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">يمكن للمقرض وضع عرض قرض شخصي لوكيل معين، عادة يتم تحديده من قائمة الوكلاء الموثوقين. علما بأن عملية إصدار القروض الشخصية مشابهة لإصدار القروض العادية. كل ما تحتاجه هو اختيار “شخصي” من خيارات “معالجة الصفقة”. وفي خانة النافذة المنبثقة، سوف تحتاج إلى تحديد اسم الوكيل الذي تريد إصدار القرض الشخصي له. أما بالنسبة للإجراءات المتبقية فتبقى هي نفسها.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">هل يمكنني تحويل الأموال بشكل مجزأ على عدة معاملات مالية؟</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2"> لا يمكنك. سوف تكون بحاجة إلى تحويل المبلغ المحدد بالضبط في الطلب الذي وضعته. خلاف ذلك، قد تحدث هناك مشاكل في تحديد الإيداع الخاص بك. </font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">أسئلة و أجوبة أخرى</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4">خصائص بيرفكت موني</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
     <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
    <td width="300" valign="top">يتم تشغيل نظام بيرفكت موني بواسطة باقة من الأدوات التي توصف بأنها الأكثر مناسبة للتعامل بين العملاء .

إن قيمة توازن الإجراءات إلى جانب مدة التسجيل لا تؤثر على صلاحيات اقتناص الفرص في هذا النظام .

كل عميل في بيرفكت موني هو ذو أهمية خاصة , ونحن لا نقوم بأي تمييز عندما نخدمك .
<br>
      </p>
      </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>حالة العميل الفردية
  </b></font></p>
<p class="txt">لكي تكون المعاملات أسهل لكلا الطرفين فإن بيرفكت موني تقسم عملاءها بالتبعية إلا ثلاث حالات نعرفها من عملاء النظام خلال مرحلة التسجيل :<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td><b><font color="B01111">العادي</font></b> <br>
     تمنح لكل عملاء النظام الجدد بدون أي قيود على استعمال الخدمة<br>
      <br>
      <b><font color="B01111">المميز</font></b><br>
      وتمنح للعملاء النشطين لمدة تزيد عن عام أو من خلال عدد معين من العمليات التي قاموا بها. ولكي تقوم بالترقية من النظام العادي على العميل أن يرسل رسالة خاصة إلى خدمة العملاء. الحالة المميزة تعطي ميزة أن عدد العمولات التي نأخذها تكون اقل من المستخدم ذو الحالة العادية.<br>
      <br>
      <b><font color="B01111">شريك</font></b> <br>
وتعني الحرية الفردية لنظام بيرفكت موني الإداري لكي يقوم بتحسين التعامل مع شركاؤه كنظام شريك لشريك مع شركات تدير أعمالها عبر الإنترنت .</td>
     <td width="20" background="img/bgt.gif">&nbsp;</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>وضعية تأكيد الصفقة
  </b></font></p>
<p class="txt">نشجع عملائنا على القيام بعملية تحقق بسيطة من خلال تحميل وثائق هوية حكومية وتقديم رقم هاتف محمول .الحسابات المدققة يمكن لأصحابها الإستفادة من الوظائف الكاملة في الحساب، وبعض المزايا تشمل<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td>رسوم أقل<br><br>
		خيارات تأمين إضافية<br><br>
		ثقة معززة من العملاء الأخرين في حسابك<br><br>
		إستعادة أسهل للحساب إذا فقدت كلمة المرور أو لا يمكن الدخول على حسابك لأي سبب من الأسباب
		</td>
     <td width="20" background="img/bgt.gif">&nbsp;</td>
  </tr>
</table>
<br>
<p>بإمكانك اختيار تصنيف حسابك اعتمادا على الأغراض وعلى عدد العمليات المتوقع : شخصي – لاستعمال الأفراد – أو الأعمال <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>اطريقة مناسبة وسهلة لتمويل حسابك: </b></font><br>
  <br>
عند استخدام نظام بيرفكت موني فان العميل يتمتع بطريقة مناسبة وسهلة الاستعمال لكي يقوم بتعاملات النظير لنظير أو الشريك لعميل . فلقد تحولت تعاملات مستخدم بيرفكت موني المالية للمنتجات والخدمات على الإنترنت إلى عملية غاية في السهولة , وذلك لأن الوقت المستهلك في هذه العملية نادرا ما يتجاوز الثانية الواحدة . الآن أصبح تحويل أموالك النقدية إلى أموال الكترونية لا يمثل أي مشكلة في بيرفكت موني .<br>
  <br>
  <b>إيداع الأموال إلى النظام يمكن أن يتم كالأتي:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td> <p class="txt"> <b><font color="B01111">التحويل البنكي</font></b> <br>
هو وسيلة مناسبة لتمويل حسابك. فبعد استلام التحويل يتم شحن رصيدك في بيرفكت موني في خلال 30 ثانية .<br>
        <br>
        <b><font color="B01111">النقود الإلكترونية</font> </b><br>
        إن نظام بيرفكت موني يعمل مع عدد كبير من النقود الإلكترونية و لهذا السبب فان عملية شحن الحساب تتم باستخدام النقود الإلكترونية بسهولة . هذه المعاملات يمكن أن تتم أوتوماتيكيا من خلال مزودي أنظمة الدفع هذه .<br>
        <br>
        <b><font color="B01111">وكلاء التبادل</font></b><br>
يمثل استخدام وسطاء التبادل طريقة مناسبة لشحن حسابك. فعن طريق إتاحتهم التعامل بالعديد من العملات مع بيرفكت موني والى جانب التزامهم بالمواعيد قاموا بتحويل عملية الشحن إلى عملية سهلة وآمنة .<br>
        <br>
        <b><font color="B01111">تخزين القيمة لعملات Crypto-Currency</font></b><br>
فرصة ثمينة لتخزين القيمة ، وعلى العكس من crypto-currency المقومة بنوع محدد من عملات Perfect Money تعتبر حسابات
  لخبرة فنية لإنشاءها أو الإحتفاظ بها. ويضمن تخزين القيمة في حسابات Perfect Money لا تحتاج حسابات crypto-currency محافظ
  مثل تعطل الأجهزة أوcrypto-currency تجنب المخاطر المرتبطة بمحافظ الأموال التي قد تؤدي لخسارة جميع اموالك من Perfect Money
  مع الإبقاء على مزاياهاcrypto-currenciesفي التغلب على تحديات Perfect Money سرقة أو فقدان كلمة المرور ، وقد نجح فريق
</p>
    </td>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<p>وللمزيد من الفاعلية للعملاء تقدم بيرفكت موني إمكانية شحن الحساب باستخدام أي نقود الكترونية كانت . وفي هذه الحالة ستقوم بيرفكت موني بعمل التحويل بأكثر طريقة ربحية للعميل .<br></p>
<p>وللعناية بكل عميل لدينا تقدم بيرفكت موني فائدة شهرية لأقل رصيد تواجد خلال الشهر .
وبهذا فإن أموالك تعمل لك حتى وأنت في وقت الراحة.
</p>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>الفعالية</b></font><br>
  <br>
للعملاء الذين ترتبط أعمالهم بالإنترنت تقدم بيرفكت موني باقة مثالية لحلول الأعمال التي تتضمن أدوات مناسبة وفعالة للمعاملات صممت خصيصا بواسطة اختصاصي الأموال في بيرفكت موني اخذين في الاعتبار حاجات مستخدمينا وفن الحصول على رضاهم عن الخدمة .<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td> <p class="txt"> <font color="#990000"><strong>اتقارير مناسبة ومفصلة تسهل عليك حساباتك</strong></font><br>
       سنقوم بإخبارك بكل العمليات المالية الجديدة, ويمكنك مشاهدة الرسوم البيانية التي توضح ذلك لحظة بلحظة.</p>
      <p><strong><font color="#990000">نظام للدفع التلقائي الدوري</font></strong><br>
       هذه الأداة مصممة لكي ترتب دفع أموال شهرية بالمواصفات التي تحددها. يمكنك أن تضبط الدفعات لتكون بشكل تلقائي.</p>
      <p><strong><font color="#990000">مركز الدعم الشخصي لعملاء بيرفكت موني </font></strong><br>
إن مركز الدعم للعملاء على الإنترنت يعمل 24/7/365 . ومخصصينا جاهزين للرد على أي سؤال قد يخطر ببالك .</p>
      <p><strong><font color="#990000">خدمة متعهد مثالية</font></strong><br>
نظرا لاهتمامنا الشديد بمسألة الفعالية , الاعتمادية و الأمان , لا نتوقع ظهور أي نظير لنظام بيرفكت موني خلال السنين القليلة القادمة . مهندسي بيرفكت موني قاموا بصنع هذه الأداة لتمكين أي بنية أعمال من تنظيم أي تعاملات مالية على الإنترنت خاصة بالسلع أو الخدمات مع توافر سهولة الوصول بأعلى قدر من السهولة والأمان .<br>
      </p><p><strong><font color="#990000">تخزين عملات crypto-currencies</font></strong><br>
بصورة مأمونة. ونتيح لكم منصة أمنة وموثوقة لتنفيذ Bitcoin العملاء على إرسال وتلقي وتخزين أصول Perfect Moneyتساعد
 المعقدة وغير المناسبة . قم بإيداع الأموال في حسابBitcoin .لا تحتاج لتنزيل واستخدام محفظة Bitcoin أية صفقات مقومة بعملات
    وسيتولى النظام الباقي.Perfect MoneyB<br>
      </p></td>
      <td width="20" background="img/bgt.gif">&nbsp;</td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>النظام الأمني</b></font><br>
<br>
إن نظام بيرفكت موني الأمني تم تطويره بواسطة مجموعة من متخصصين باحثين علماء في مجال المعلومات والأمن المالي . مهندسي بيرفكت موني قاموا بإنشاء أداة مثالية لأمان العملاء عن طريق :
<p>- الخبرة بعيدة المدى لمحللي بيرفكت موني في التعامل بالأدوات المالية على نطاق واسع ؛; <br>
  -	المراقبة الحية على الإنترنت لمستوى الأمان وحماية عملاءنا بواسطة قسم الأمن في بيرفكت موني; <br>
  -	تكنولوجيات الذكاء الاصطناعي في التعرف على العملاء. <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="3" cellpadding="0">
  <tr>
    <td> <p class="txt"> <b><font color="B01111">التحقق من الشخصية</font></b> <br>
تستخدم هذه الطريقة في التعرف على عميل لحساب بيرفكت موني . هذه الأداة هي عبارة عن نوع من العين الاصطناعية لنظام بيرفكت موني والذي ليس من الضروري له أن يتعرف على الشخص باستخدام الوجه ولكن يكفيه أن يقوم بالتعرف على الحاسوب المستخدم في الدخول على الحساب .في حالة تم اكتشاف أن الوصول تم بواسطة أي بي لا يخص صاحب الحساب, يقوم النظام بحجب الوصول إلى الحساب ويرسل كود أمان إضافي إلى البريد الإلكتروني الذي تم تحديده أثناء التسجيل بواسطة المستخدم. وعملية تغيير الأي بي تتم شخصيا بواسطة أفراد قسم الدعم في بيرفكت
        <br>
        <br>
        <b><font color="B01111">التعرف بواسطة الرسائل القصيرة</font></b><br>
يستخدم هذا النظام لخلق اتصال منطقي بين حساب العميل وبين هاتفه الجوال الذي يقوم النظام بإرسال كود تأكيدي لكي يتأكد من المالك الحقيقي للحساب. نظام الدخول بواسطة الرسائل القصيرة هو أقوى نظام والأكثر فاعلية من ضمن طرق حماية العميل من الدخول من قبل أشخاص غير مخولين بالدخول للحساب وذلك لأن الوقت المستهلك في عملية إرسال الكود والدخول باستخدامه هي مدة قصيرة للغاية وليست مناسبة لعملية كسر الكود .
        <br>
        <br>
        <b><font color="B01111">الحماية بواسطة كود البطاقة</font></b> <br>
يحصل العميل على بطاقة بها صورة رسومية من الكود وترسل على بريد العميل الإلكتروني . ولكي يتم تأكيد العمليات يقوم النظام بإرسال استعلام للعميل بشكل عشوائي ويتم الإجابة عن طريق كود محدد في هذه البطاقة. كود البطاقة هي وسيلة مناسبة ويعتمد عليها لتأكيد العمليات. لقد أثبتت جدارتها في الغالبية العظمى من المراكز المالية الكبرى في العالم .<br>
    </td>
     <td width="20" background="img/bgt.gif">&nbsp;</td>
  </tr>
</table>
<br>
<br>
الأسلوب الديمقراطي الذي تنتهجه بيرفكت موني في التعامل مع العميل يتيح لكل عميل أن يقرر بشكل مستقل أي نظام امني يحتاجه بالفعل لحماية حسابه . فكل عميل في بيرفكت موني له حرية التصرف ويحدد ما يمكن أن يناسبه لكي يستخدمه في حماية حسابه من الدخول غير المسموح به سواء للمشاهدة أو إجراء العمليات .
<p><strong>انظام بيرفكت موني هو نظام ليبرالي تحرري لأي مستخدم . </strong></p>
<p>لقد قمنا بعمل أكثر الطرق فاعلية وتأثيرا للتحكم في حسابك ونحن نأمل بان نكون أعطينا لعملائنا مطلق الحرية في تشكيل سياساتهم المالية . كل عميل هو عميل مهم بالنسبة لنا , وكونك اخترت التعامل مع بيرفكت موني يعني إننا سنقدم لك الإمكانيات القصوى للتحكم في حسابك بدون الخوف من حجب الوصول .
</p>
<p>إن مهمة نظام بيرفكت موني الأمني هو تقديم الفرص القصوى لعملائنا لكي يقوموا بإنشاء نظام امني متعدد المستويات لتعاملاتهم المالية .النظام الأمني جنبا إلى جنب مع اقسم البحث العلمي في بيرفكت موني لا يقوم فقط بتطوير نظم أمنية جديدة ولكن أيضا يحمل في جعبته مجموعة من المتخصصين في تطويع كل الطرق الممكنة في اختراق النظم لكي يكون بمقدورهم استخدام هذه النظم في المستقبل من اجل إنشاء نظام رقمي رقابي قوي داخل هذا النظام .</p>
<p>من أجل عميلنا الجالس خلف الناحية الأخرى من شاشة الحاسوب قامت بيرفكت موني باختراع هذا النظام للتعاون المالي معزز بآلاف من الإمكانيات المختبئة خلف هذا الباب الضئيل – خانة الدخول في الصفحة الرئيسية . ولذلك فهذا هو الوقت الذي يتوجب عليك فيه فتح هذا الباب الصغير والدخول إلى عالم بيرفكت موني الممتع !<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br><br>
</div>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script>نفذوا دفعنات P2P و B2B مع Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ar_AE", getExpDate(30, 0, 0), "/");

          </script><style type="text/css">
.arabic{
  direction:rtl;
}
.atable{
text-align:right;
}
.a1{
  	padding-right:30px;
  	margin-right:30px;
}
</style>
<a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">المظهر القانوني</font></a>
| <a href="privacy.php"><font color="#b50b0b">الحالة الحقوقية</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">شروط الإستخدام</font></a></font></small>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1">| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"> <font color="#b50b0b">خارطة الموقع </font></a></font></font></small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>