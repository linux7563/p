<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <title>Perfect Money - new generation of Internet payment system. Payment processor for money transfer.</title>
    <META NAME="Keywords" CONTENT="buy,sell,exchange,on-line,ecurrency,e-currency,payment system, payment processor,payment gateway,api,merchant,merchant payment,solution,online banking,money,transfer,finance service,payment service,swiss,safety store funds">
    <META name="description" content="Perfect Money payment system discovers the safest and easiest financial service to make money transfers worldwide.Accept e-currency, bank wire and SMS payments on you e-commerce website.Buy gold, send or receive money with the most secure payment processor on the Internet.">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style type="text/css">
        <!--
        body { max-width:1650px}
        .top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
        .req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
        td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
        .ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
        h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
        #TJK_ToggleON,#TJK_ToggleOFF {display:none}
        .menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
        .txt {  text-align: justify}
        a {  color: #990000}
        -->
    </style>
    <link rel="StyleSheet" href="css/style_publics.css" type="text/css">
    <link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
    <script type="text/javascript" src="js/jquery.comp.js"></script>
    <script type="text/javascript">
        $j = jQuery.noConflict();
        jQuery(document).ready(function(){
            $j("#memo").addClass("input");
            $j("input").addClass("input");
            $j(":submit").addClass("submit");
        });
    </script>
    <script type="text/javascript" src="js/jquery.1.9.min.js"></script>
    <script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
            $('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
        });
    </script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
                    <td valign="bottom" width="65%">
                        <div align="right">
                            <form method="post" name="f" action=<?php  ?>>
                                <table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="img/geoip/GB.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US" selected>English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
                                    <img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
                            <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                <a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Signup</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Exchangers</font></a>

                                &nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                <font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tour</font></a>&nbsp;&nbsp;&nbsp;
                                <font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Help</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Security Center</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

                            </font></div>
                    </td>
                </tr>
            </table>
            <br>
        </td>
    </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
                <tr>
                    <td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/en_US/rand/confidentiality.jpg"></td>
                    <td height="8" bgcolor="#0A0A0A">
                        <div align="center">
                            <table width="216" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td><img alt="E-Currency Payment System" src="img/lang/en_US/rand/text-for-confidentiality.png"></td>
                                </tr>
                                <tr>
                                    <td>&nbsp; </td>
                                </tr>
                            </table>
                        </div>
                    </td>
                    <td height="8" width="1%">
                        <div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <tr>
        <td>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
                    <td colspan="2" bgcolor="B01111">
                        <table border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Login</font></a>
                                </td>
                                <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
                                <td nowrap>
                                    <div id="menuOver">
                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
                                            <div  class="menu" style="min-width:780px"> <a href="http://localhost"><span>Home</span></a>
                                                <a href="about.php" class="selectedd"><span>About Us</span></a>
                                                <a href="features.php"><span>Features</span></a>
                                                <a href="fees.php"><span>Fees</span></a>
                                                <a href="evoucher-info.php"><span>E-Vouchers</span></a>
                                                <a href="guarantees.php"><span>Guarantees</span></a>
                                                <a href="faq.php"><span>F.A.Q.</span></a>
                                                <a href="contact.php"><span>Contact Us</span></a>
                                            </div>
                                        </font>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td width="4%" bgcolor="B01111" valign="middle">
                        <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
                    </td>
                </tr>
            </table>

        </td>
    </tr>
    <tr>
        <td><img src="img/blank.gif" width="820" height="1"></td>
    </tr>
</table>
<meta name="apple-itunes-app" content="app-id=id653398845">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
        <td>

            <table border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
                        <font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Exchange Rates</b></font><br>
                        <table width="270" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td height="2">
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font></font></font></div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="left">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/21.png" width="265" height="130"><br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
                                        <font color="#999999">BTC:</font><br><br>
                                    </font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Arial, Helvetica, sans-serif" size="1">
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1">61608.77&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font>
                                                        </font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <font face="Arial, Helvetica, sans-serif" size="1">
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                    </font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1">57511.31</font>
                                                </font>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right">
                                                    <img src="img/right_c.gif" width="8" height="36">
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/71.png" width="265" height="130"><br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
                                        <font color="#999999">GOLD Bid Price /oz:</font><br><br>
                                    </font>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <div align="right">
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Arial, Helvetica, sans-serif" size="1">
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
                                                            <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                        </font>
                                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1">2279.915&nbsp;&nbsp;
                                                            <font color="#CC0000">|</font>
                                                        </font>
                                                    </font>
                                                </div>
                                            </td>
                                            <td bgcolor="E8E8E8" width="50%">
                                                <font face="Arial, Helvetica, sans-serif" size="1">
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
                                                    <font face="Arial, Helvetica, sans-serif" size="1">
                                                        <font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
                                                    </font>
                                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.301</font>
                                                </font>
                                            </td>
                                            <td width="8" valign="middle">
                                                <div align="right">
                                                    <img src="img/right_c.gif" width="8" height="36">
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                    <br><img src="img/rates/31.png" width="265" height="130">
                                </td>
                            </tr>
                        </table>
                        <br>
                        <div style="width:270px">
                            <font face="Arial, Helvetica, sans-serif" size="3"><b>Public Poll</b></font>
                            <font face="Arial, Helvetica, sans-serif" size="2"><br><br>
                                Perfect Money: Service Quality & Products<br><br>
                                <a href="statistics.php">View results in real-time</a> &raquo;</font>
                        </div>
                    </font>
                        <div align="left"><br>
                            <div class="arabic">
                                <div class="a1">
                                    <br>
                                    <font face="Arial, Helvetica, sans-serif" size="3"><b>Frequently Asked Questions</b></font> <br>
                                    <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
                                        <br>
                                    </b></font>
                                    <table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
                                        <tr>
                                            <td>
                                                <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">What is the minimum and maximum loan term?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
                                                    <br>
                                                </font>
                                                    <font color="#000000" face="Arial, Helvetica, sans-serif" size="2">The minimum loan term is 1 day. The maximum loan term is 365 days.<br /><p>

                                                    </p></font><br><br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">How can I provide an access to my personal data for the Credit Exchange users?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
                                                    <br>
                                                </font>
                                                    <font color="#000000" face="Arial, Helvetica, sans-serif" size="2">You need to go to the "Settings" section, and place a check mark against those items that you want to make public. You can share your turnover, transaction history and deals. Save your choices by clicking “Save”. No further action is required.</font><br><br>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <p><font face="Arial, Helvetica, sans-serif">
                                                    <font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
                                                <br><br>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <br>
                            <br>
                            <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
                            </b><img src="img/blank.gif" width="307" height="26"></font></div>
                    </td>
                    <td valign="top" align="left">
                        <p><font face="Arial, Helvetica, sans-serif" size="3"><b><br>
                            <font size="4">Welcome to a new generation of Internet Payment System!</font></b></font></p>
                        <p class="txt"><font face="Arial, Helvetica, sans-serif" size="2"> Perfect Money is a leading financial service allowing the users to make instant payments and to make money transfers securely throughout the Internet opening unique opportunities to Internet users and owners of the Internet businesses. <br>Perfect Money targets to bring the transactions on the Internet to the ideal level!</font></p>
                        <br>
                        <table border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" id="promo_nav1" class="nav">
                                        <tr>
                                            <td class="ina_left" width="14" height="30"><img src="img/spacer.gif"></td>
                                            <td onClick="showPromo('#promo1','#promo_nav1')" class="ina_center"><a href="javascript:;">About System</a></td>
                                            <td class="ina_right" width="12" height="30"><img src="img/spacer.gif"></td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" id="promo_nav2" class="nav">
                                        <tr>
                                            <td class="ina_left" width="14" height="30"><img src="img/spacer.gif"></td>
                                            <td class="ina_center" onClick="showPromo('#promo2','#promo_nav2')"><a href="javascript:;">How to Deposit</a></td>
                                            <td class="ina_right" width="12" height="30"><img src="img/spacer.gif"></td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" id="promo_nav3" class="nav">
                                        <tr>
                                            <td class="ina_left" width="14" height="30"><img src="img/spacer.gif"></td>
                                            <td class="ina_center" onClick="showPromo('#promo3','#promo_nav3')"><a href="javascript:;">How to Withdraw</a></td>
                                            <td class="ina_right" width="12" height="30"><img src="img/spacer.gif"></td>
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <table border="0" cellspacing="0" cellpadding="0" id="promo_nav4" class="nav">
                                        <tr>
                                            <td class="ina_left" width="14" height="30"><img src="img/spacer.gif"></td>
                                            <td class="ina_center" onClick="showPromo('#promo4','#promo_nav4')"><a href="javascript:;">e-Voucher</a></td>
                                            <td class="ina_right" width="12" height="30"><img src="img/spacer.gif"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <table border="0" cellspacing="0" cellpadding="0" width="700" bgcolor="#D6D6D6">
                            <tr>
                                <td width="10"><img src="img/blank.gif" width="1" height="1"></td>
                            </tr>
                        </table>
                        <table border="0" cellspacing="0" cellpadding="15" width="700" bgcolor="#F7F7F7" id="promo1" class="promo">
                            <tr>
                                <td><font color="#990000"><b><font size="3">Perfect Money presents unique
                                    features for Business and Personal accounts.</font></b></font><br>
                                    <br>
                                    <h1 class="home">While using Perfect Money payment system one can do the following:</h1>
                                    <br>
                                    <table border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td width="10">&nbsp;</td>
                                            <td>
                                                <table width="600" border="0" cellspacing="0" cellpadding="3">
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Perform money transfers between members </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Receive payments in various business projects in Internet </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Make regular payments in Internet</font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Safely store money funds on electronic account and get monthly
                                                            interests </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Make payment for goods and services in Internet shops </font></td>
                                                    </tr>
                                                    <tr>
                                                        <td><font face="Arial, Helvetica, sans-serif" size="2" color="#000000"><img src="img/arrow.gif">
                                                            Buy Bitcoin, Gold Metal, USD and EUR currency online </font></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>

                        <table border="0" cellspacing="0" cellpadding="15" width="700" bgcolor="#F7F7F7" id="promo2" class="promo">
                            <tr>
                                <td class=txt><b><font color="#990000" size="3">Deposit has never been so
                                    easy - 7 unique ways with Perfect Money</font></b><br>
                                    <br>
                                    To make payments on the Internet with Perfect Money currency you need firstly
                                    to load the account. This can be made by various methods enabling you to
                                    turn your real wallet into a virtual one. <br>
                                    <br>
                                    <font size="2"><b><img src="img/arrow.gif"> Bank Wire</b></font><br>
                                    <br>
                                    <div style="margin-left: 9px;">To deposit account you can send Bank Wire (SWIFT / IBAN) from your online
                                        banking account or accept Bank Wire from the third party, for example from
                                        your business partner. Giving your partners Perfect Money account details
                                        you have an opportunity to accept Bank Wire even if you don't have a bank
                                        account. Find out <a href="easy_way_deposit.html">how easy</a> &raquo;
                                        it is to fund your Perfect Money account using a bank wire.</div>
                                    <br>
                                    <b><font size="2"> <b><img src="img/arrow.gif"></b> Instant Bank Transfer</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">A convenient way to make a deposit from the comfort of your home. By using
                                        this method you are instructing your bank to make a transfer to us without
                                        visiting your local branch. The transfers are instant. Available to bank
                                        account holders at Germany, Austria, Switzerland and Belgium.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Certified Exchange Partners</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">Perfect Money e-currency can be purchased with other e-currency, Western
                                        Union, Money Gram or just for cash. Deposit funds via <a href="business-partners.php">Certified
                                            Exchange Partners</a> &raquo;.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Cash Terminals</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">Fast cash based method to make a deposit to your account at Perfect Money.
                                        Create a order at &quot;Deposit&quot; section of your account, make a deposit
                                        at the payment terminal near you. The funds are immediately credited to
                                        your account. 150,000 payment terminals available across Russian Federation
                                        and Ukraine.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Bitcoin</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">Make a deposit using a Bitcoin crypto-currency. Instantly deposit funds to your Perfect Money B account after 3 network confirmations.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Perfect Money Prepaid
                                        Card / e-Voucher</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">This is an option when you buy an e-Voucher on the Internet with an Activation code or a Prepaid Card locally and credit your account after entering the code to the special form. For example you can buy the e-Voucher for e-currency or Western Union with a variety of online exchange services or auctions.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> E-currency</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">Deposit funds via e-currency transfer from the accounts in electronic payment
                                        systems. All the e-currency deposit transactions are instant.</div></td>
                            </tr>
                        </table>

                        <table border="0" cellspacing="0" cellpadding="15" width="700" bgcolor="#F7F7F7" id="promo3" class="promo">
                            <tr>
                                <td class=txt> <font color="#990000" size="3"><b>Withdraw money with Perfect
                                    Money</b></font><br>
                                    <br>
                                    It is easy to convert Perfect Money electronic currency to real money or
                                    other payment tools. Money withdrawals can be performed as follows: <br>
                                    <br>
                                    <font size="2"><b><font size="2"><b><img src="img/arrow.gif"></b> </font>Bank
                                        Wire</b></font><br>
                                    <br>
                                    <div style="margin-left: 9px;">You can withdraw Perfect Money currency via Bank Wire transfer to your online
                                        banking account or to the third party. If your business partners or some
                                        service accept only Bank Wires you can also withdraw Perfect Money currency
                                        via Bank Wire as a payment for services or goods.</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Perfect Money Prepaid
                                        Card / e-Voucher</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">Create your own Perfect Money e-Voucher certificate. It's a great idea to
                                        give it to friends, family or reward. Also you can sell e-Voucher or exchange
                                        it for cash or e-currency</div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> E-currency</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">You have an opportunity to withdraw funds from your account in Perfect Money
                                        to the account in other electronic payment system. </div>
                                    <br>
                                    <b><font size="2"><b><img src="img/arrow.gif"></b> Prepaid Visa / Master
                                        Card gift cards</font></b><br>
                                    <br>
                                    <div style="margin-left: 9px;">We give our customers an opportunity to buy prepaid cards online within
                                        a Perfect Money account. For example, you can purchase &quot;Prepaid Visa
                                        Card&quot; for safe and secure shopping everywhere on the Internet.</div><Br>
                                    <b><font size="2"><b><font size="2"><b><img src="img/arrow.gif"></b>
                                        Certified Exchange Partners</font></b><br>
                                        <br>
                                    </font></b>
                                    <div style="margin-left: 9px;">Perfect Money e-currency is available for
                                        sale with Western Union&reg;, Money Gram&reg;. Also you can exchange Perfect
                                        Money to other electronic currency or cash it in your city. Withdraw funds
                                        via <a href="business-partners.php">Certified Exchange Partners</a>
                                        &raquo;.</div><Br>
                                    <b><font size="2"><b><font size="2"><b><img src="img/arrow.gif"></b>
                                        Bitcoin</font></b><br>
                                        <br>
                                    </font></b>
                                    <div style="margin-left: 9px;">Withdraw funds directly to your Bitcoin wallet. Perfect Money lets customers withdraw funds from Perfect Money B accounts to the Bitcoin wallet of your choice. All transactions are processed automatically.</div>
                                </td>
                            </tr>
                        </table>

                        <table border="0" cellspacing="0" cellpadding="15" width="700" bgcolor="#F7F7F7" id="promo4" class="promo">
                            <tr>
                                <td class=txt><font color="#990000" size="3"><b>Have you ever thought of making your
                                    own virtual prepaid card? </b></font><br>
                                    <br>
                                    Have you ever thought that you can buy Perfect Money virtual prepaid card
                                    for your e-currency on the Internet and then convert it to Perfect Money
                                    currency? Perfect Money payment system gives you such an opportunity and
                                    makes it real!
                                    <p>A virtual Perfect Money prepaid card with Activation code called e-Voucher
                                        is always available to be created by any Perfect Money user.</p>
                                    <p>e-Voucher is a special code which you can use to deposit any account
                                        in Perfect Money payment system. Also you can give this code to anybody
                                        and they can fund their accounts in Perfect Money payment system anytime.</p>
                                    <p>You can send the code of e-Voucher to any e-mail or mobile phone number.</p>
                                    <p>If you want to create an e-Voucher you should access your Perfect Money
                                        account, click on &quot;Withdraw&quot; and click on &quot;e-Voucher&quot;.
                                        Then please write value of the e-Voucher and create it. Please note that
                                        all the created e-Vouchers are available in e-Voucher Depository which
                                        can be found in a &quot;Statement&quot; section. </p>
                                    <p>If you want to deposit your Perfect Money account you can buy the e-Voucher
                                        on the Internet. Next you should access your Perfect Money account, click
                                        on &quot;Deposit&quot; and choose &quot;e- Voucher&quot; as a payment
                                        option.</p>
                                    <p>e-Voucher is a convenient way to pay for goods and/or services even if
                                        your client does not have a Perfect Money account.</p>
                                </td>
                            </tr>
                        </table>

                        <table border="0" cellspacing="0" cellpadding="0" width="700" bgcolor="#D6D6D6">
                            <tr>
                                <td width="10"><img src="img/blank.gif" width="1" height="1"></td>
                            </tr>
                        </table>
                        <script type="text/javascript">
                            function showPromo(id, elem)
                            {
                                $('table.promo').hide();
                                $(id).show();

                                if (elem)
                                {
                                    $("table.nav td").each(
                                        function()
                                        {
                                            switch (this.className) {
                                                case 'act_left' : case 'ina_left': classname = 'ina_left'; break;
                                                case 'act_center' : case 'ina_center': classname = 'ina_center'; break;
                                                case 'act_right' : case 'ina_right' : classname = 'ina_right'; break;
                                            }

                                            this.className = classname;
                                        }
                                    );

                                    var current = $(elem+' td');

                                    current.get(0).className = 'act_left';
                                    current.get(1).className = 'act_center';
                                    current.get(2).className = 'act_right';
                                }
                            }

                            showPromo('#promo1','#promo_nav1');
                        </script>
                        <br>
                        <p class="txt"><font face="Arial, Helvetica, sans-serif" size="2">In every operation
                            performed in Perfect Money payment system we aspire to offer our customers perfect
                            service.<br>We know that future has Perfect Money, and you have an opportunity to
                            become our customer! </font></p>
                        <p class="txt"><font face="Arial, Helvetica, sans-serif" size="2">New to Perfect Money? </font><font face="Arial, Helvetica, sans-serif"><font size="2"><a href="tour.php">Take a tour</a> &raquo;</font></font> </p>
                        <div align="right">
                            <p align="left"><img alt="No fees payment system" src="img/nofees.gif"></p>
                        </div>

                        <table width="95%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td class=txt><div class="arabic">
                                    <p class="faq">
                                        <font face="Arial, Helvetica, sans-serif" size="3"><b>Merry Christmas and a Happy New Year!</b></font>
                                        <br>
                                        <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#666666">22.12.23</font>
                                        <BR><BR>
                                        <font face="Arial, Helvetica, sans-serif" size="2">Dear Customers and Partners,<br />
                                            Merry Christmas and a Happy New Year!<br />
                                            <br />
                                            Year 2023 is coming to an end. Soon, we will celebrate Christmas and welcome the new year 2024. It's time for family gatherings and gifts.<br />
                                            <br />
                                            Our staff at Perfect Money is not planning to leave you empty-handed either, and we are presenting you the most valuable item that we have - our product. Throughout the past year, we have been working hard to enhance our components, from security, privacy to the interface while boosting a number of payment options. For 16 years, we have tirelessly worked with our valued 400 exchange partners who above all appreciate us for our reliability and stability. Thanks to them we have continued to grow at astonishing rate. Perfect Money's active user base having grown by a record 6 million, for a total of around 20 million worldwide. Our brand recognition has increased on all continents, with payment operations now offered in over 200 countries. Pay using your preferred financial tools - from cash to cryptocurrencies - and conduct banking operations in more than 50 fiat currencies. With rare exceptions, our geographical service domain essentially covers the entire planet. We are trusted by tens of thousands of companies around the world, the number that steadily grows each day. Perfect Money's portfolio of merchants continues to expand as well, with new companies from emerging online business sectors joining every year.</font><p><a href="newsview.html?id=380">Read more</a> &raquo;</p>
                                    </font>
                                    <p><br><font face="Arial, Helvetica, sans-serif"><b><font size="2"> More news:<br></font></b><br>
                                        <div class="newstitle"><a href="newsview.html?id=376">Perfect Money payment system wishes you a Merry Christmas and a Happy New Year!</a> &raquo; <span class="date">23.12.22</span></div><img src="img/blank.gif" width="10" height="5"><br>
                                        <div class="newstitle"><a href="newsview.html?id=375">Pay with popular cryptocurrencies and accept them at your websites</a> &raquo; <span class="date">11.02.22</span></div><img src="img/blank.gif" width="10" height="5"><br>
                                        <div class="newstitle"><a href="newsview.html?id=373">Perfect Money wishes all our customers and partners Merry Christmas and Happy New Year!</a> &raquo; <span class="date">22.12.21</span></div><img src="img/blank.gif" width="10" height="5"><br>
                                        <div class="newstitle"><a href="newsview.html?id=372">We&rsquo;ve turned 14!</a> &raquo; <span class="date">05.10.21</span></div><img src="img/blank.gif" width="10" height="5"><br>
                                        <br><a href="news_archive.php"><font size="2">News archive</font></a> &raquo;</font></p><br>
                                </div>
                                </td>
                            </tr>
                        </table>
                        <br>
                        <br>
                    </td>
                    <td valign="top" background="img/left36.gif" id="promo" width="200">
                        <div style="padding-left: 40px;padding-top:18px;" class="txt arabic">
                            <font face="Arial, Helvetica, sans-serif" size="2">
                                <font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> E-Vouchers</b></font> <br><br>
                                <a href="evoucher-info.php"><img src="img/help/e-voucher.png"></a><br><br>
                                <font face="Arial, Helvetica, sans-serif" size="3"><font face="Arial, Helvetica, sans-serif" size="2" class=""><b>It seems like virtual<br>But it works like <font color='#F01010'>real money</font></b></font></font>
                                <ul style="padding:0px;padding-left:10px;">
                                    <li>Create e-voucher for any amount.</li><br>
                                    <li>Transfer money to any receiver around the world (the recipient will receive  e-voucher number and activation code by SMS, even if he/she has no PM account).</li><br>
                                    <li>Pay online for goods and services securely and confidentially.</li><br>
                                    <li>Easily exchange e-voucher to any other e-currency or cash through online exchange service.</li>
                                </ul>
                                <a href="evoucher-info.php">Read more &raquo;</a><br><br><br>
                                <font face="Arial, Helvetica, sans-serif" size="3"> <font face="Arial, Helvetica, sans-serif" size="3"><b>Accept Perfect Money - ensure profit growth!</b></font></font><br>
                                <br>
                                <a href="sciv2.html"><img src="img/pm_accepted_index.jpg" width="248" height="153"></a><br><br>
                                Dramatically increase your sales by adding Perfect Money as a payment method on your website.<br><br>
                                Quick steps to set-up SCI, integration with dozens of CMS, over 10,000,000 Perfect Money account holders.<br><br>
                                <a href="sciv2.html">Add Perfect Money Shopping Cart to your website and introduce your services to millions of Perfect Money customers &raquo;</a> <br><br><br>
                                <font face="Arial, Helvetica, sans-serif" size="3"> <font face="Arial, Helvetica, sans-serif" size="3"><b>Easy integration into Shopping Cart software</b></font></font><br><br>

                                <img src="img/total4_mini.gif" width="320" height="57"><br><br>
                                Our tech team developed plugins for the most popular shopping cart scripts. Now you can add Perfect Money to the list of payment options on your website just downloading the necessary plug in for your existing shopping cart. Payment by SMS, Bank Wire Transfer, Perfect Money e-Vouchers, PM Prepaid Cards are going to be available on your existing shopping cart!<br><br>
                                <a href="sample-api.php">Detailed information about Perfect Money API & Plugins &raquo;</a><br><br><br><br>
                            </font>
                        </div>

                    </td>
                </tr>
            </table>
        </td>
        <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
    </tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td height="2">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
                    <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
                    <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
                </tr>
            </table>
        </td>
    </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
        <td width="341" bgcolor="#ffffff" valign="middle" height="56">
            <div align="left">&nbsp;&nbsp;
                <!--
                <a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
                <a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
                -->

            </div>
        </td>
        <td bgcolor="#ffffff" valign="top" height="56">
            <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
                <tr>
                    <td>
                        <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            Perfect Money - new generation of Internet payment system. Payment processor for money transfer.&nbsp;<br>&copy;
                            2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
                            Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
                            <a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
                            | <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
                            Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Legal notice</font></a>
                            | <a href="privacy.php"><font color="#b50b0b">Privacy policy</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            | <a href="tos.html"><font color="#b50b0b">Terms of Use</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
                            | <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small><br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>
                            </small>


                        </div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>