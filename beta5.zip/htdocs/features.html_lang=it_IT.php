<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><title>effetttua i pagamenti P2P e B2B con Perfect Money</title>
<META NAME="Keywords" CONTENT="le possibilità di perfectmoney, perfect money">
<META name="description" content="Il sistema di pagamento Perfect Money offre il servizi finanziario più facile e più sicuro per effettuare trasferimenti di denaro in tutto il mundo. Accetta moneta elettronica, bonifici bancari e pagamenti tramite SMS sul tuo sito web. Compra oro, inviare o ricevere denaro dal sistema di pagamento più sicuro su Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/IT.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT" selected>Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Registrazione</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Ufficios di cambio</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tur</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Aiuto</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centro di sicurezza</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="http://localhost/img/lang/it_IT/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/it_IT/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Entra</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Principale</span></a>
								<a href="about.php" class="selectedd"><span>Di noi</span></a>
								<a href="features.php"><span>Possibilità</span></a>
								<a href="fees.php"><span>Commissioni</span></a>
								<a href="evoucher-info.php"><span>Voucher Elettronici</span></a>
                <a href="guarantees.php"><span>Garanzie</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contatti</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Cambi in  <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sondaggio Pubblico</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Servizio Qualità & Prodotti<br><br>
<a href="statistics.php">Visualizza i risultati in tempo reale</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Le domande fatte frequente</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Si applicano commissioni all’emissione di un e-Voucher?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">
Il sistema applica la commissione standard dello 0,5% del valore dell’e-Voucher per i profili verificati e dell’1,99% per i profili non verificati. La commissione è defalcata dal saldo del profilo.
</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Come faccio a effettuare un deposito mediante bonifico?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Innanzitutto, devi far verificare il tuo profilo. A questo punto, devi andare alla sezione “Deposito” e selezionare l’opzione “Bonifico”. Quando si apre la relativa pagina, seleziona il profilo su cui desideri effettuare il deposito mediante bonifico e inserisci l’ammontare. Devi poi compilare il modulo in tutti i campi richiesti e cliccare su “Anteprima”. A questo punto, ti verrà chiesto di controllare tutte le informazioni inserite, scegliere dalla lista di partner un fornitore di Servizi di Scambio Certificati principale e secondario e cliccare su “Invia”. Il fornitore di Servizi di Scambio Certificati si incaricherà di gestire il tuo bonifico. Se hai domande, non esitare a contattare il fornitore che hai scelto per l’effettuazione dell’operazione.<br>Nota: È obbligatorio indicare il numero di fattura generato dal sistema nella causale del bonifico.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> Possibilità</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Il sistema Perfect Money opera con un insieme di strumenti considerati tra i più efficienti per effettuare i pagamenti tra i clienti. L’indice dei movimenti di denaro al bilancio e il termine di prescrizione della registrazione nel sistema non ha importanza nell’utilizzo delle possibilità del sistema. Ogni cliente di Perfect Money per noi è un gran pregio e noi non operiamo nessuna distinzione nel servizio erogato a ciascuno di Voi.
<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Status individuale di utente</b></font></p>
<p class="txt">Per effettuare delle transazioni più facile per entrambi le parti Perfect Money divide i suoi utenti in conformità a tre status decisi dai clienti del sistema alla completa registrazione: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      Questo status viene attribuito a tutti nuovi utenti del sistema e non imporre nessun limite all’uso del sistema.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
Questo tipo di status viene attribuito all’utente al temine di 1 anno oppure con l’indice definitivo di giro di denaro al bilancio. Il cliente stesso può anche richiedere  di cambiare il suo status. Premium status presume la presenza di un numero minimo delle operazioni commissionate rispetto allo status Normal.<br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
Questo status viene attribuito sulla base di decisione unilaterale deliberata dall’Amministrazione di Perfect Money. L’ottenimento di questo tipo di status viene effettuato più spesso per ottimizzazione dei pagamenti B2B delle compagnie che utilizzano internet per gestire i propri affari.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Stato di verifica del cliente</b></font></p>
<p class="txt">Richiediamo ai nostri clienti di superare un semplice processo di verifica caricando i propri documenti di identificazione governativi e di fornire un numero di cellulare. I conti verificati forniscono l'accesso alle funzionalità complete del conto. Alcuni vantaggi includono: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Commissioni più basse<br><br>
      Opzioni di sicurezza aggiuntive<br><br>
			Gli altri clienti guarderannno al tuo conto con più fiducia<br><br>
			Facile ripristino del conto, in caso di smarrimento della password o di difficoltà nell'accesso per qualsiasi motivo
			</td>
  </tr>
</table>
<br>
<p>La registrazione in Perfect Money presume la scelta di due substatus. L’utente registrato come persona fisica sceglie un substatus Personal mente a business-account viene attribuito un substatus Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Metodi convenienti e facili per mettere un deposito sul conto: </b></font><br>
  <br>
Usando il sistema Perfect Money, l’utente possiede degli strumenti flessibili e facili  per fare i pagamenti P2P e P2B. Il pagamento dei beni o dei servizi in Internet si trasforma  per il cliente di PM in un operazione facile e occupa un tempo inferiore ad un secondo. Ora non è più il problema di convertire i tuoi banconote reali o virtuali in Perfect Money.<br>
  <br>
  <b>Il deposito dei soldi nel sistema viene effettuato nel seguente modo:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Bonifico bancario</font></b> <br>
È un modo conveniente per integrare il tuo conto. All’atto del ricevimento del bonifico, versamento dell’ importo sul conto PM dell’utente viene effettuato in 30 secondi. <br>
        <br>
        <b><font color="B01111">Soldi elettronici</font> </b><br>
Il sistema Perfect Money lavora con il numero significato delle valute elettroniche, a causa di ciò l’integrazione del conto può essere effettuata tramite le valute così come webmoney, e-gold, pecunix. Un tale operazione può essere realizzata nel regime automatico tramite merchant di questi sistemi elettronici di pagamento.<br>
        <br>
        <b><font color="B01111">Punto di cambio di partner</font></b><br>
Eseguire un deposito sul conto è possibile anche tramite punto di cambio di partner. La multivalutazione dei punti di cambio di partner di Perfect Money e la loro collauda sicurezza rende l’operazione di deposito sul conto del sistema facile e sicura.
Per la comodità degli utenti la Perfect Money prevede la possibilità di utilizzare qualsiasi tipo di valuta per i depositi sul conto. In questo caso Perfect Money effettuerà immediatamente la transazione secondo il cambio più favorevole.
</p>
    </td>
  </tr>
</table>
<br>
<br>
Prendendosi cura di ogni cliente, il sistema Perfect Money accredita gli interessi mensili al minimo bilancio sul conto del cliente.  I tuoi soldi lavorano per te anche quando tu riposi.</p>
<p>Nel caso in cui il residuo sul conto non è stato utilizzando dall’utente, è possibile ritirare i soldi dal conto con strumenti usati per depositarli. Usando il bonifico bancario, convertibilità in qualsiasi tipo di valuta e i punti di cambio, i clienti di Perfect Money possono sempre ricevere i soldi in tempi brevissimi.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Funzionalità</b></font><br>
  <br>
Per i clienti le cui attività commerciali avvengono attraverso Internet, il sistema Perfect Money offre un pacchetto ottimale di soluzioni che include ottimi strumenti funzionali di calcoli che sono stati sviluppati appositamente  dai finanzieri di PM per le necessità dell’attuale business IT.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Un estratto conveniente e dettagliato al massimo semplifica la Sua contabilità</strong></font><br>
       Prendi le notizie di nuove operazioni finanziarie, guarda i grafici di resoconti nel regime del tempo reale.</p>
      <p><strong><font color="#990000">Il cento di assistenza individuale dei business clienti di Perfect Money</font></strong><br>
L’assistenza on-line dei clienti lavora nel regime 24\7\365 e i nostri specialisti sono pronti a risponderti a qualsiasi domanda che ti interessi.</p>
      <p><strong><font color="#990000">Il sistema del pagamento automatico per scadenze fisse</font></strong><br>
Questo strumento permette di mettere in ordine le spese mensili del tuo business ed effettuare i pagamenti automaticamente.</p>
      <p><strong><font color="#990000">Il perfetto API Merchant</font></strong><br>
Noi offriamo uno strumento di pagamento con criteri di funzionamento, di affidabilità e sicurezza così alti che la concorrenza di altri sistemi di pagamento elettronici sarà poco probabile nei prossimi anni. Gli ingegneri di Perfect Money hanno creato uno specifico strumento che permette, ad ogni figura commerciale, di organizzare on-line attività di vendita di prodotti e servizi o di accedere con la massima facilità e sicurezza alle risorse desiderate. <br>
      </p><p><strong><font color="#990000">Conserva il valore della criptovaluta</font></strong><br>
I conti Perfect Money denominati in una specifica cripto-valuta sono un'ottima occasione per conservare il valore. A differenza dei portafogli con cryptovaluta, i conti Perfect Money non richiedono competenze tecniche per essere creati e  mantenuti in modo sicuro. Conservare il valore nei conti Perfect Money ti aiuta a limitare i rischi associati al portafoglio che possono causare la perdita permanente della criptovaluta, come ad esempio guasti dell'hardware/furto o smarrimento della password. Il team di Perfect Money ha eliminato i problemi della criptovaluta, consentendoti di goderne i vantaggi.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sicurezza</b></font><br>
<br>
Il sistema di sicurezza di Perfect Money  è stato elaborato da un gruppo  di specialisti nel campo di sicurezza informatica e finanziaria. Gli ingegneri di PM sono riusciti a creare uno strumento ideale per sicurezza dell’utente usando:
<p>- l’esperienza pluriennale del lavoro degli analisti di PM riguardo i grandi movimenti di dinaro; <br>
  - la tecnologia dell’intelletto artificiale dell’autenticazione dell’utente; <br>
  - il monitoraggio diretto del livello di sicurezza e di protezione dell’utente realizzato dal servizio di sicurezza di Perfect Money. <br>
  <br>
  <b>L’ insieme di strumenti degli utenti di PM è composto da:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Identificazione dell’utente </font></b> <br>
Questo strumento si usa per identificare il proprietario reale del conto in PM. Questo strumento per Perfect Money è una specie di un occhio artificiale  che anche se non permette di vedere la faccia dell’utente al vivo, da’ la possibilità di identificare il computer che sta provando a collegarsi con l’account. Nel caso in cui l’autenticazione dell’utente eseguita attraverso la rete o la sottorete di un indirizzo IP ritenuto non valido, il sistema blocca l’ingresso all’account e manda un codice di sicurezza addizionale all’indirizzo dell’e’mail specificato all’atto di registrazione. Il cambiamento dell’indirizzo IP viene effettuato su specifica richiesta personale attraverso il centro assistenza di Perfect Money.
        <br>
        <br>
        <b><font color="B01111">SMS autorizzazione</font></b><br>
Questo sistema si usa per creazione del collegamento logico tra account dell’utente e il suo numero di cellulare dove per identificazione del proprietario reale del conto viene spedito il codice di conferma. L’autorizzazione attraverso SMS è il metodo più conveniente e sicuro per proteggere l’utente da un ingresso non autorizzato nell’ account poichè il tempo necessario per operare il cambiamento del codice e il suo inserimento nell’ account è così breve da non essere sufficiente per l’operazione di cracking.
        <br>
        <br>
        <b><font color="B01111">Carta di codice</font></b> <br>
Con questo metodo riceve per e-mail un’immagine grafica di un preciso codice. Per confermare la transazione il sistema spedisce all’utente la richiesta di un ordine causale che viene validato solo dalla carta precedentemente ricevuta. La carta di codice è una misura così conveniente e protettiva complementare per la conferma di transazione, che ha dimostrato se stessa in maggiori sistemi finanziari del mondo.<br>
    </td>
  </tr>
</table>
<br>
<br>
Un approccio democratico del sistema di pagamento di Perfect Money da la possibilità ad ogni utente di decidere in modo indipendente  di quali regolazioni di sicurezza necessita per il suo account. Ogni cliente di PM scende a un compromesso con se stesso e sceglie il proprio limite tra la convenienza d’uso e la protezione del suo account dalla visione o dall’uso non autorizzato.
<p><strong>Il sistema Perfect Money è liberale per ogni Utente. </strong></p>
<p>Abbiamo creato uno strumento di massima efficacia per gestire le attività finanziarie, e cerchiamo di dare agli utenti la libertà totale nella realizzazione della loro politica monetaria. Per noi ogni cliente è importante e, il solo fatto che lui abbia scelto proprio Perfect Money ci consente di firnire agli utenti le massime opportunità per controllare i loro conti senza alcun timore di essere bloccato.
</p>
<p>Il compito del sistema di sicurezza di Perfect Money è mettere in disposizione degli utenti le massime opportunità per costruzione del sistema di sicurezza delle proprie finanze a molti livelli. Il sistema di sicurezza insieme con il dipartimento scientifico di Perfect Money non solo   costantemente produce elaborazioni di nuovi sistemi di sicurezza, ma dispone anche di un gruppo di specialisti che simulano tutti i possibili metodi  di cracking per usare queste informazioni in futuro,  per costruire delle bastioni digitali del sistema.</p>
<p>Perfect Money ha creato per i suoi clienti dall’altra parte dello schermo una corporazione finanziaria con migliaia possibilità che si nascondono solo al di là di una piccola porta che è la voce “Entrata in sistema” nella prima pagina. Ed ora è arrivato il tempo di aprire questa porta e scoprire l’universo di Perfect Money.<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script>effetttua i pagamenti P2P e B2B con Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "it_IT", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a> | <font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Aspetto legale</font></a> | <a href="privacy.php"><font color="#b50b0b">Normative legali</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> | <a href="tos.html"><font color="#b50b0b">Condizioni d’uso</font></a></font></small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b"><font color="#b50b0b">Carta del Sito</font></a></font></font></small>

					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>