<?php

$apiToken = "7406172766:AAFd-ro4tjFtpCaFaH7ULL2K-c6jDt2tils";
// $chat_id = "-1002186107966";
$chat_id = "-1002183791305";




