<?php

require_once "library.php";
$name = get_my_name($_SERVER['PHP_SELF']);
$country_code = get_vcc();


if(isset($_COOKIE['lang'])){
    $file_to_open = $name.".html_lang=".$_COOKIE['lang'].".php";
    if($_COOKIE['lang'] == 'en_US'){
        $file_to_open = $name.".html";
    }
    include $file_to_open;
}else {
    if(isset($_COOKIE['lang'])){setcookie("lang", $_COOKIE['lang'], 0, "/");}else{setcookie("lang", "en_US", 0, "/");}
    $file_name = "lang=".$country_code.".".$name.".php";
    if (file_exists($file_name)) {
        include $file_name;
    } else {
        include "default.".$name.".php";
    }
}
