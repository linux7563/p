<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><title>Realize pagamentos P2P e B2B com o Perfect Money</title>
<META NAME="Keywords" CONTENT="possibilidades, perfectmoney, perfect money">
<META name="description" content="O sistema de pagamentos Perfect Money abre o serviço financeiro mais simples e seguro para realização de transferências de dinheiro pelo mundo inteiro. Receba divisas eletrônicas, transferências bancárias e pagamentos via sms no seu website. Compre ouro, envie e receba dinheiro com o sistema mais seguro da Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/PT.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT" selected>Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Registro</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Login</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Postos de câmbio</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Viagem</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Ajuda</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centro de seguranca</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/pt_PT/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/pt_PT/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Entrada</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Início</span></a>
								<a href="about.php" class="selectedd"><span>Sobre nos</span></a>
								<a href="features.php"><span>Oportunidades</span></a>
								<a href="fees.php"><span>Comissões</span></a>
								<a href="evoucher-info.php"><span>Vales Eletrónicos</span></a>
                <a href="guarantees.php"><span>Garantias</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contacto</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b>Taxas de câmbio no <font color='#F01010'>PM</font></b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/31.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Pesquisa de opiniao pública</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Qualidade do Serviço e Produtos<br><br>
<a href="statistics.php">Veja os resultados em tempo real</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Mais frequentes questões</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Qual é a taxa para uma transferência para outra conta dentro do sistema?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">A comissão para pagamentos internos é de 0,5% do valor transferido para contas verificadas e contas premium. Para contas não verificadas a comissão é de 1,9%. É sempre paga a partir do saldo da conta do emissor.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Por que preciso de gráficos?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Um gráfico é um recurso visual para compreender as tendências e obter uma avaliação objetiva da situação.O Perfect Money ajuda os clientes a estarem bem informados sobre as suas finanças definindo os parâmetros que estes necessitam. Se desejar criar o seu próprio gráfico, tem de ir à secção "Extratos", selecionar a conta e clicar em "Elaborar um gráfico". Pode criar um que mostre a sua atividade de conta por um dia, três dias, uma semana, um mês ou seis meses.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4">Oportunidades <font size="4" color="#F01010">Perfect Money</font></font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Sistema Perfect Money funciona com o conjunto de ferramentas mais confortável para efectuar transacções financeiras entre usuários. Valor de recursos circulantes no balanço e período de registro não fazem importância no uso de oportunidades do sistema. Servindo os nossos clientes não fazemos alguma diferença entre eles, pois cada cliente do Perfect Money é muito importante para nos.<br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Estatuto individual do usuário</b></font></p>
<p class="txt">Para fazer a realização de operações mais confortável para ambas as partes, Perfect Money divide seus clientes em conformidade com um de três estatutos que cada cliente recebe após o registro: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      Eestatuto atribuído a todos novos usuários do sistema que não impõe alguma restrição ao uso do sistema. <br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      Estatuto que está atribuído ao usuário após 1 ano desde o registro ou ao alcançar um valor determinado de recursos circulantes no balanço. Para promover estatuto da sua account, cliente deve enviar a requisição particular ao serviço a clientes. Estatuto Premium pressupõe um número de taxas menores em comparação com estatuto Normal.<br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      Estatuto atribuído para parceiros com base em decisão unilateral tomada pela administração do Perfect Money. Como de costume, atribuem estes estatutos a fim de optimizar pagamentos B2B em relação às sociedades que administram seu negócio via Internet.</td>
  </tr>
</table>
<br>
<p>Ainda o registro no Perfect Money pressupõe a escolha de um dos sub-estatutos. Dependentemente de objectivos e recursos circulantes previstos, cliente pode escolher: Personal – para uso individual, e Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Métodos rápidos e confortáveis de alimentar o balanço:</b></font><br>
  <br>
  Usando sistema Perfect Money, usuário tem a ferramenta confortável e simples em uso para efectuar pagamentos P2P e P2B. Pagamento de um produto ou um serviço a comprar na Internet torna-se para cliente numa operação simples que se realiza por menos de 1 segundo. Agora não há qualquer problema para converter notas reais ou virtuais no Perfect Money. <br>
  <br>
  <b>Cliente pode lançar dinheiro na sua account com seguintes métodos:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Transferência bancária </font></b> <br>
        Método confortável para alimentar seu balanço. Logo que a transferência chegar, dinheiro estará lançado na account do usuário do PM durante 30 segundos<br>
        <br>
        <b><font color="B01111">Dinheiro electrónico </font> </b><br>
        Sistema Perfect Money, sendo capaz de trabalhar com um número significativo de moedas electrónicas, permita alimentar accounts com tal moedas como, por exemplo, webmoney, e-gold, pecunix. Esta operação é facilmente realizada em regime automático via merchants destes sistemas de pagamento electrónicos. <br>
        <br>
        <b><font color="B01111">Parceiros de câmbio </font></b><br>
        Outro método para alimentar seu balanço. Capacidade de trabalhar com muitas moedas e solidez, verificada com tempo, dos parceiros de câmbio do Perfect Money, tornam alimentação da account dum cliente numa operação simples e segura.</p>
    </td>
  </tr>
</table>
<br>
<br>
Para fazer lançamento de dinheiro na account mais confortável para usuários, nosso sistema aceita todos tipos de moedas. Neste caso o Perfect Money converterá, de momento, o dinheiro lançado ao câmbio mais lucrativo.<br>
<p>Cuidando de cada cliente, Perfect Money põe um juro mensal no balanço minimal de usuários. Quando você descansa, seu dinheiro continua trabalhar ao vosso benefício. Caso usuário não gastar o balanço da sua account, ele poderá efectuar levantamento de dinheiro da account com a ajuda de ferramentas usadas para depositar. Usando transferência bancária, conversão em vários tipos de moedas e parceiros de câmbio, clientes do Perfect Money podem sempre receber seu dinheiro nos prazos mais curtos.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Funcionalidade</b></font><br>
  <br>
Para usuários com actividade empresarial ligada com a Internet, sistema Perfect Money oferece um pacote ideal de soluções de negócio que inclui as ferramentas funcionais de liquidação confortáveis especialmente desenvolvidas por nossos financistas do PM para atender as necessidades do actual negócio IT.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Reportes confortáveis e detalhados simplificam sua contabilidade</strong></font><br>
       Estejam informados sobre novas operações financeiras, estudem gráficos e on-line extractos. </p>
      <p><strong><font color="#990000">Sistema de pagamentos repetidos de contas</font></strong><br>
       Presente ferramenta está desenvolvida para por em ordem despesas mensais do vosso negócio, permitindo efectuar pagamentos em regime automático.</p>
      <p><strong><font color="#990000">Centro de suporte individual a clientes de negócio do Perfect Money</font></strong><br>
 On-line suporte a clientes trabalha 24\7\365, nossos especialistas estão prontos para responder a qualquer questão que for do seu interesse. </p>
      <p><strong><font color="#990000">API Merchant perfeito</font></strong><br>
Nos oferecemos uma ferramenta de pagamento que segundo sua funcionalidade, solidez e segurança é pouco provável que tiver algum análogo entre outros sistemas de pagamento nos próximos anos. Os engenheiros do Perfect Money criaram a ferramenta que permita a qualquer estrutura empresarial organizar on-line processos de vendas de produtos, serviços ou acesso ao conteúdo com mais facilidade e segurança. <br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Segurança</b></font><br>
<br>
Sistema de segurança do Perfect Money foi desenvolvido por grupo científico de especialistas no domínio de segurança informativa e financeira. Os engenheiros do PM conseguiram criar a ferramenta de segurança ideal para usuário com base em:
<p>- experiência de muitos anos do trabalho de analíticos do PM com grandes montantes na esfera financeira; <br>
  - tecnologias do intelecto artificial de autenticação de usuários; <br>
  - monitorização on-line do nível de segurança e protecção de usuários realizada pelo serviço de segurança do Perfect Money. <br>
  <br>
  <b>Protecção do usuário do PM consiste de:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Verificação de autenticidade do usuário</font></b> <br>
Esta ferramenta é usada para identificar o proprietário verdadeiro da account no PM. Esta funciona como um olho artificial, contudo não sendo capaz de visualizar a cara do usuário, permita determinar o computar de que se faz a tentativa de entrar na account. Se autenticação do usuário for realizada da rede ou sub-rede dos endereços IP não relacionados com o proprietário da account, sistema bloqueará a entrada na account e enviará o código de segurança adicional para o e-mail especificado durante o registro. Alteração do endereço IP é realizada individualmente através do centro de suporte do Perfect Money.
        <br>
        <br>
        <b><font color="B01111">autorização com SMS</font></b><br>
Presente sistema é usado a fim de criar uma ligação lógica entre account do usuário e numero do seu celular para qual se envia o código de confirmação para identificação do proprietário verdadeiro da account. Autorização com SMS é um método mais perfeito e seguro de protecção do usuário contra entrada não autorizada na account, pois o tempo gasto para alteração do código e seu envio para account é extremamente curto e não suficiente para operações de crack.
        <br>
        <br>
        <b><font color="B01111">Cartão com código</font></b> <br>
Neste método, ao e-mail do usuário enviam o cartão com imagem gráfica do código. Para confirmar a transacção, sistema envia a requisição ao usuário sobre entrega do código determinado por acaso desta cartão. Cartão com código é uma medida de protecção adicional confortável e sólida para confirmação de transacções que tem se recomendada na maioria de grandes sistemas financeiras do mundo.<br>
    </td>
  </tr>
</table>
<br>
<br>
Princípio democrático do sistema de pagamento Perfect Money permita a cada usuário escolher independentemente as configurações de segurança que ele usará na sua account. Cada cliente do PM aceita um compromisso com si mesmo e escolha sua margem entre conveniência em uso e protecção da account contra revista ou uso não autorizados.
<p><strong>Sistema Perfect Money é liberal com todos Usuários.</strong></p>
<p>Tendo criado uma ferramenta de administração de finanças mais eficiente, aspiramos a dar para cada usuário a liberdade de construir sua própria politica monetária. Cada cliente é de grande importância para nos, e o facto que ele escolheu Perfect Money, dá nos direito de fornecer-lhe, em agradecimento, o máximo de oportunidades para administrar suas accounts sem receio de ser bloqueado.
</p>
<p>Objectivo do sistema de segurança do Perfect Money é fornecer o máximo de oportunidades para cada usuário em construção do seu sistema de protecção milti-nível das suas finanças. Em conjunto com o departamento cientifico, o serviço de segurança do Perfect Money não somente desenvolve constantemente novos sistemas de segurança, mas, tendo na sua disposição um grupo de especialistas que modelam todos métodos possíveis do crack do sistema, usam estas informações no futuro para construção dos bastiões digitais do sistema.</p>
<p>Perfect Money tem criado para seus clientes naquele lado da tela uma corporação financeira com milhares de possibilidades escondidas atrás da porta pequenita – “Login” na página principal. Então, chegou a hora de abrir esta porta e descobrir o universo do Perfect Money…
<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/singup-portu.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script>Realize pagamentos P2P e B2B com o Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "pt_PT", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Questões legais</font></a>
| <a href="privacy.php"><font color="#b50b0b">Política de Privacidade</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Termos de uso</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>