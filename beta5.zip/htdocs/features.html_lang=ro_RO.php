<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><title>Efectueaza plati P2P si B2B cu Perfect Money</title>
<META NAME="Keywords" CONTENT="caracteristici, baniideali, bani ideali">
<META name="description" content="Sistemul de plata Perfect Money descopera cele mai sigure si simple servicii financiare pentru transferuri de bani oriunde. Accepta e-valuta, transfer bancar si plata prin SMS pe situl dvs e-comert. Cumpara aur, trimite sau primeste bani cu cel mai sigur sistem de plata de pe Internet">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/RO.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR">Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO" selected>Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Inregistreaza</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Autentificare</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Parteneri de schimb</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tur</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Ajutor</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Centru de securitate</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/ro_RO/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/ro_RO/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Autentificare</font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Acasa</span></a>
								<a href="about.php" class="selectedd"><span>Despre noi</span></a>
								<a href="features.php"><span>Сaracteristici</span></a>
								<a href="fees.php"><span>Comisioane</span></a>
								<a href="evoucher-info.php"><span>E-Vouchere</span></a>
                <a href="guarantees.php"><span>Garantii</span></a>
                <a href="faq.php"><span>F.A.Q.</span></a>
                <a href="contact.php"><span>Contactati-ne</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Exchange Rates</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61647.7&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57557.27</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2279.94&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.324</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sondaj public</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Calitatea serviciilor şi produse<br><br>
<a href="statistics.php">Vizualizare rezulate în timp real</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Întrebări frecvente</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Pot retrage fonduri din contul meu PMB către contul Bitcoin aparținând unei alte persoane?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Da, puteți. Un astfel de transfer este posibil.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Cum pot retrage bani via Credit Exchange?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">De fapt, împrumutarea banilor prin Credit Exchange nu este considerată o retragere. Pur și simplu transferați banii dvs. către împrumutați, iar ulterior îi primiți înapoi cu dobândă. <br>Dacă doriți să deveniți împrumutător, trebuie să creați o ofertă de împrumut. Pentru a începe o propunere de împrumut, trebuie să accesați Credit Exchange și să apăsați pe „Acordă un împrumut”.<br>Pe pagina care se deschide, completați oferta dvs. de împrumut specificând contul pe care doriți să-l utilizați, suma propusă pentru împrumut, rata dobânzii, termenul împrumutului, o modalitate pentru procesarea împrumutului, scopul împrumutului și un comentariu. După ce ați făcut acest lucru, apăsați pe butonul de Previzualizare și verificați toate informațiile introduse. Dacă sunteți sigur că totul este corect, apăsați pe „Creare propunere nouă de împrumut” pentru a confirma sau pe butonul „Înapoi” pentru a efectua orice modificări.<br>Propunerea dvs. de împrumut va fi adăugată la lista de propuneri existente -  "https://perfectmoney.is/credits/deals_give.html</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">Read more Q &amp; A</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br><font size="4">Caracteristicile</font> <font size="4" color="#F01010">Perfect Money</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top">Sistemul Perfect Money operează cu un set de instrumente care sunt extreme de conveniente pentru utilizatorii noștri.
      <p>Valoarea balanței conturilor, la fel și cifra de afaceri nu afectează nicicum privilegiile utilizării acestui sistem.</p>
      <p>Fiecare client Perfect Money este foarte important și noi nu facem nicio distincție în timp ce vă servim interesele. <br>
      </p>
      </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Statutul individual al clientului
  </b></font></p>
<p class="txt">Pentru a face tranzacțiile mai ușoare pentru ambele părți, Perfect Money își împarte utilizatorii în trei statuturi obținute chiar de utilizatori la înregistrare: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
     Desemnat tuturor Clienților fără nicio limitare și fără nicio funcție special.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
     Desemnat Clientului care a fost active de cel puțin 1 an și care are o valoare definită a balanței. Pentru a ajunge la acest nivel, Clientul trebuie să trimită o cerere separată la Asistență Clienți. Statutul de Premium asigură comisioane mai mici decât cel Normal.  <br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
    Desemnat doar la discreția administrației Perfect Money Administration celor care vor să facă B2B pentru companiile pe care le conduc pe Internet.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Stare verificare client
  </b></font></p>
<p class="txt">Îi încurajăm pe clienții noștri să accepte un proces simplu de verificare, încărcând documente de identificare emise de guvern și furnizând un număr de telefon mobil. Conturile verificate permit accesul la funcționalitatea completă a contului. Unele avantaje includ:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Comisioane mai mici<br><br>
     Opțiuni de securitate suplimentare<br><br>
		 Încredere mărită în contul dvs. din partea altor clienți<br><br>
		 Refacere ușoară a contului, în cazul pierderii parolei sau imposibilității de a accesa contul din orice motiv.<br><br>
		 </td>
  </tr>
</table>
<br>
<p>Puteți alege de asemenea un subgrup pentru contul dvs: Personal, pentru folosință individual, sau Business.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Metode conveniente și ușoare pentru a depozita:</b></font><br>
  <br>
Prin folosirea Perfect Money, Clientul are un instrument convenabil pentru a face plăți P2P și P2B. Pentru un client PM, plățile pentru produse sau servicii pe Internet se transformă într-o simplă operație, deoarece timpul petrecut de abia atinge 1 secundă. Nu este problem de asemenea schimbul banilor dvs reali în Perfect Money.  <br>
  <br>
  <b>Depozitare banilor poate fi făcută prin:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Transfer Bancar</font></b> <br>
        E o metodă convenientă pentru a-ți alimenta contul. După primirea banilor, suma va putea fi utilizată în 30 de secunde.<br>
        <br>
        <b><font color="B01111">E-valută</font> </b><br>
        Sistemul Perfect Money lucrează cu un număr semnificativ de e-valute și, datorită acestui lucru, depozitarea poate fi făcută prin mai multe metode. Asemenea tranzacții pot fi operate automat sau prin comercianți ai sistemului.<br>
        <br>
        <b><font color="B01111">Parteneri de schimb</font></b><br>
Reprezintă o altă posibilitate de a-ți alimenta contul. Mulitudinea acestora și posibilitățile lor demonstrate în timp au făcut Perfect Money să le acorde încrederea necesară derulării activității lor.<br>
        <br>
        <b><font color="B01111">Stocare valoare criptomonedă</font></b><br>
Conturile Perfect Money denominate într-o criptomonedă anume constituie un mod excelent de a stoca valoare. Spre deosebire de portofelele electronice în criptomonede, conturile Perfect Money nu necesită experiență tehnică pentru a le seta sau a le menține în siguranță. Stocarea valorii în conturile Perfect Money vă permite evitarea riscurilor asociate cu portofelele electronice, care pot avea ca rezultat pierderea definitivă a criptomonedei, prin defectarea/furtul hardware-ului sau pierderea parolei. Echipa Perfect Money a eliminat provocările legate de criptomonede, permițându-vă în același timp să vă bucurați de avantajele oferite de acestea.</p>
    </td>
  </tr>
</table>
<br>
<br>
Pentru conveniența clienților, Perfect Money oferă o posibilitate de alimentare a contului în interiorul oricărei e-valute. În acest caz, Perfect Money va efectua tranzacția imediat și la cel mai convenabil curs de schimb.
<p>În fiecare lună, sistemul Perfect Money adaugă o dobândă la suma pe care o deține fiecare client în cont. Banii lucrează pentru tine chiar și atunci când te odihnești. <br>
Dacă balanța nu este consumată de Client, acesta poate opta pentru retragerea sumei prin aceleași metode folosite si la depozitare.</p>
<p>Prin folosirea unui transfer bancar, conversia oricărei e-valute si cu ajutorul partenerilor de schimb, clientii Perfect Money îsi primesc banii în cel mai scurt timp posibil.<br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Functionalitate</b></font><br>
  <br>
Pentru clientii a căror activitate afacerială este conectată la Internet, Perfect Money oferă conditii optime care include instrumente functionale conveniente pentru dezvoltarea nevoile personale, deoarece echipa IT a Perfect Money ti-a demonstrate pasiunea pentru acest business.<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <font color="#990000"><strong>Rapoarte detaliate face accesul dvs la cont mult mai simplu </strong></font><br>
        Află noile operatii finaciare, vezi grafice si rapoarte în timp real.</p>
      <p><strong><font color="#990000">Sistem automat de plăti programate </font></strong><br>
        Acest instrument este desemnat pentru a organiza cheltuielile lunare ale firme dvs; permite plata în orice mod automat.</p>
      <p><strong><font color="#990000">Centru pentru suport individual business al Perfect Money </font></strong><br>
       Asistenta pentru clienti lucrează online 24\7\365. Specialistii sunt gata să răspundă la orice întrebare vă interesează pe dvs.</p>
      <p><strong><font color="#990000">Comerciantul Perfect API </font></strong><br>
       Bazându-ne principiile pe criteriul functionalitătii, sigurantei si încrederii, suntem sigur că nu va mai apărea nimic asemănător cu Perfect Money. Inginerii Perfect Money au creat un asemenea instrument care permite oricărui business să-si organizeze vânzările online, iar accesul la serviciile lor este simplificat până la o usurintă incredibilă.<br>
      </p><p><strong><font color="#990000">Stocare criptomonedă</font></strong><br>
       Perfect Money permite clienților săi să trimită, să primească și să stocheze active bitcoin, în mod securizat. Oferim o platformă sigură și demnă de încredere pentru efectuarea oricăror tranzacții denominate în bitcoin-uri. Nu trebuie să descărcați și să utilizați un portofel electronic pentru bitcoin, complicat și neconvenabil. Depuneți fonduri în contul dvs. Perfect Money B, iar sistemul se va ocupa de rest.<br>
      </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Securitate</b></font><br>
<br>
Sistemul de securitate Perfect Money a fost dezvoltat în urma unui studiu stiintific al unui grup de specialisti în domeniu informational si al securitătii finantelor. Inginerii PM au reusit să creeze instrumentul ideal pentru securitatea Clientului folosind:
<p>- Experienta de terment lung a analizării PM pentru operarea cu instrumente finaniare la o scară largă; <br>
  -	Tehnologii de inteligentă artificială pentru autentificarea Clientului; <br>
  -	Monitorizare online a  nivelului de securitate si a protectiei clientului, performate de serviciul de securitate al Perfect Money. <br>
  <br>
  <b>Cutia de securitate a PM include următoarele:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Verificarea Identității</font></b> <br>
       Prin folosirea acestui instrument de fiecare dată când veti logat de pe un alt calculator sau web browser, un email va fi trimis către adresa dvs pentru a vă verifica identitatea. Acest email ca contine un cod de confirmare, care va trebui introdus.
        <br>
        <br>
        <b><font color="B01111">Autentificarea prin SMS</font></b><br>
        Activând instrumentul de securitate autentificarea prin SMS vă va permite să primiți mesaje scurte pe telefonul mobil, care vor contine codul de securitate pentru a accesa Zona Membrilor când utilizatorul se autentifică.
        <br>
        <br>
        <b><font color="B01111">Cardul cu coduri</font></b> <br>
       Sistemul vă va oferi un card cu coduri grafic care va contine numere secrete. Vei fi nevoit să introduce numărul secret de fiecare dată când vei încerca să faci ceva important, de exemplu transfer de bani sau modificarea securitătii. Cardul cu coduri este o imagine care poate fi salvată sau imprimată.<br>
    </td>
  </tr>
</table>
<br>
<br>
Conceptul democratic al Perfect Money lasă posibilitatea fiecărui Client de a decide în mod independent ce măsuri de securitate trebuie să îsi assume pentru contul său. Fiecare client Perfect Money face un compromise cu sine pentru a găsi echilibrul convenientei si pentru a îsi poteja contul de un hacker sau un vizualizator neautorizat
<p><strong>Sistemul Perfect Money este liberal pentru orice Client. </strong></p>
<p>Am creat cele mai eficiente instrumente pentru controlul financiar si sperăm să dăm clientilor nostri o mână de ajutor în formare unei proprii politici monetare. Fiecare client este foarte important pentru noi si faptul că ati ales Perfect Money  ne îndeamnă să vă oferim cele mai mari oportunităti pentru a va controla conturile dvs fără frică sau fără a fi blocate.
</p>
<p>Scopul sistemului de securitate Perfect Money este să ofere oportunităti maxime pentru clientii nostri care vor să dezvolte o multisecuritate pentru sistemul lor financiar. Împreună cu departamentul de cercetări stiintifice al Perfect Money , sistemul de securitate nu doar că dezvoltă noi metode de securitate, dar are de asemenea un grup de specialisti pentru a modela orice formă de spargere a sistemului pentru a folosi această informatie ca jandarm digital pentru protectia Perfect Money.</p>
<p>Pentru Clientii nostri de cealaltă parte a computerelor, Perfect Money a creat o cooperare financiară cu mii de posibilită si ascunse în spatele unei usi foarte mici – autentificarea pe pagina principal. Asadar, este timpul să o deschideti si să descoperiti universal Perfect Money!<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script>Efectueaza plati P2P si B2B cu Perfect Money&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "ro_RO", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Program de afiliere</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Notita legala</font></a>
| <a href="privacy.php"><font color="#b50b0b">Politica de
confidentialitate</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Termeni si conditii</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Harta sitului</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>