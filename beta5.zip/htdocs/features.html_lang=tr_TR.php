<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
    <link rel="manifest" href="img/favicon/site.webmanifest">
    <link rel="mask-icon" href="img/favicon/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><title>Perfect Money ile P2P ve B2B ödemelerini yapın</title>
<META NAME="Keywords" CONTENT="оlanaklar, perfectmoney, perfect money">
<META name="description" content="Perfect Money ödeme sistemi dünya çapında para havalelerini yapmaya mahsus en basit ve güvenli mali servisi sunmaktadır. Elektronik döviz, banka havaleleri ve sms ödemelerini kendi web sitenizde teslim alın. İnternetteki daha güvenli ödeme sistemi ile altın satın alın, para havalesi gönderin veya teslim alın">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
body { max-width:1650px}
.top {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 8pt}
.req {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 9pt; color: #FF0000}
td {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 13px; color: #333333}
.ag {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; color: #333333}
h2 {  font-family: Arial, Helvetica, sans-serif; font-size: 15pt; color: #333333}
#TJK_ToggleON,#TJK_ToggleOFF {display:none}
.menu {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10pt}
.txt {  text-align: justify}
a {  color: #990000}
-->
</style>
<link rel="StyleSheet" href="css/style_publics.css" type="text/css">
<link rel="StyleSheet" href="css/colorbox_publics.css" type="text/css">
<script type="text/javascript" src="js/jquery.comp.js"></script>
<script type="text/javascript">
$j = jQuery.noConflict();	
jQuery(document).ready(function(){  
	$j("#memo").addClass("input");
	$j("input").addClass("input");
	$j(":submit").addClass("submit");
});
</script>
<script type="text/javascript" src="js/jquery.1.9.min.js"></script>
<script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript">
$(document).ready(function(){  
	$('a[href="tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
	$('a[href="/tour.php"]').colorbox({href:"/tour.php",scrolling:false,initialWidth:1000,initialHeight:590,innerWidth:977,width:1000,height:590,fixed:true,top:60,left:350});
});
</script>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="general">
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="43"><br><img alt="Payment System Gold USD EUR" src="img/blank.gif" width="950" height="5">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="35%"><img alt="E-Currency Payment System" src="img/blank.gif" width="14" height="26"><a href="index.php"><img alt="Perfect Money Payment System" src="img/logo3.png" border=0></a></td>
          <td valign="bottom" width="65%">           
            <div align="right">
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><form method="post" name="f" action="general/lang.php">
<table cellpadding="0" cellspacing="0"><tr><td valign="middle"><img src="http://localhost/img/geoip/TR.GIF">&nbsp;<br><br></td><td><select name="lang" onChange="if (this.value != '') document.f.submit()">&nbsp;&nbsp<option value=""> --- --- </option><option value="en_US">English</option><option value="de_DE">Deutsch</option><option value="el_GR">Ελληνικά</option><option value="zh_CN">中文</option><option value="ja_JP">日本語</option><option value="ko_KR">한국어</option><option value="es_ES">Español</option><option value="fr_FR">Français</option><option value="ru_RU">Русский</option><option value="uk_UA">Українська</option><option value="it_IT">Italiano</option><option value="pt_PT">Português</option><option value="ar_AE">العربية</option><option value="th_TH">ไทย</option><option value="id_ID">Indonesia</option><option value="ms_MY">Malaysian</option><option value="tr_TR" selected>Türkçe</option><option value="pl_PL">Polski</option><option value="ro_RO">Român</option><option value="hi_IN">Hindi</option><option value="ur_IN">Urdu</option><option value="vi_VN">Vietnam</option>&nbsp;&nbsp;</select><img alt="Switzerland E-Currency" src="img/blank.gif" width="42" height="5"><br>
<img alt="Switzerland E-Currency" src="img/blank.gif" width="1" height="15"></td></tr></table></form>
            <font face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><a href="https://www.perfectmoney.com/signup.html"><font color="#000000">Kayıt ol</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="login.php"><font color="#000000">Giriş Yap</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="business-partners.php"><font color="#000000">Kur Değiştirme</font></a>

              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script>&nbsp;&nbsp;&nbsp;<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="tour.php"><font color="#000000">Tur</font></a>&nbsp;&nbsp;&nbsp;
<font color="#999999"></font></font><font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="help.php"><font color="#000000">Yardım</font></a>&nbsp;&nbsp;&nbsp;<font color="#999999">|</font>&nbsp;&nbsp;&nbsp;<a href="security_center.php"><font color="#000000">Güvenlik Merkezi</font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

              </font></div>
          </td>
        </tr>
      </table>
      <br>
    </td>
  </tr>
</table>
<div id="season" style="position:absolute; width:1px; height:1px; z-index:-1; left: 356px; top: 5px"><img alt="Summer" src="img/summer4.gif"></div>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td>
     <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" bgcolor="0B0A0C">
<tr>
	<td height="8" width="2%"><img alt="Buy Gold Metal, Buy USD EURO currency online, Payment System" src="img/lang/tr_TR/top2-70.png"></td>
   	<td height="8" bgcolor="#0A0A0A">
	<div align="center">
    <table width="216" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td><img alt="E-Currency Payment System" src="img/lang/tr_TR/mid3-70.png"></td>
	</tr>
    <tr>
    	<td>&nbsp; </td>
	</tr>
	</table>
	</div>
	</td>
	<td height="8" width="1%">
		<div align="right"><img alt="fast,easy,comfortable - way to develop your money" src="img/right2-70.png" width="18" height="167"></div>
	</td>
</tr>
</table>

    </td>
  </tr>
  <tr>
<td>
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="36"><img src="img/left-70.gif" width="36" height="26"></td>
    <td colspan="2" bgcolor="B01111">
      <table border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="100">&nbsp;<a class=no href="login.php"><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#FFFFFF">Giriş Yap </font></a>
          </td>
          <td width="150"><img src="img/blank.gif" width="150" height="10"></td>
          <td nowrap>
            <div id="menuOver">
			  <font face="Verdana, Arial, Helvetica, sans-serif" size="2">
              <div  class="menu" style="min-width:780px"> <a href="index.php"><span>Anasayfa</span></a>
								<a href="about.php" class="selectedd"><span>Hakkında</span></a>
								<a href="features.php"><span>Özellikler</span></a>
								<a href="fees.php"><span>Ücretler </span></a>
								<a href="evoucher-info.php"><span>E-Fişleri</span></a>
                <a href="guarantees.php"><span>Garantiler</span></a>
                <a href="faq.php"><span>S.S.S.</span></a>
                <a href="contact.php"><span>Bize Ulaşın</span></a>
							</div>
				</font>
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="4%" bgcolor="B01111" valign="middle">
      <div align="right"><img src="img/right-70.gif" width="24" height="26"></div>
    </td>
  </tr>
</table>

</td>
</tr>                                                                               
<tr>
    <td><img src="img/blank.gif" width="820" height="1"></td>
  </tr>
</table>
<table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="23"><img src="img/blank.gif" width="23" height="26"></td>
          <td> 
            
      <table width=100% border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="310" valign="top" background="img/left33.gif"><font face="Arial, Helvetica, sans-serif" size="3"><br>
            <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><font face="Arial, Helvetica, sans-serif" size="3"><b><font color='#F01010'>PM</font> Kur-Değiştirme Oranları</b></font><br>
<table width="270" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td height="2">
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#999999">USD, EUR:</font>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br><br></font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
				<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
				<font face="Verdana, Arial, Helvetica, sans-serif"> / <b>EUR</b>&nbsp;&nbsp;0.914&nbsp;&nbsp;
				<font color="#CC0000">|</font></font></font></div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="left">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;<b>EUR</b>
						<font face="Verdana, Arial, Helvetica, sans-serif"> / </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b>&nbsp;&nbsp;1.049</font>
				</font>
			</div>
			</td>
			<td width="8" valign="middle">
				<div align="right"><img src="img/right_c.gif" width="8" height="36"></div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">BTC:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">61610.73&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">57528.99</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/71.png" width="265" height="130"><br>
		<font face="Verdana, Arial, Helvetica, sans-serif" size="1"><br>
			<font color="#999999">GOLD Bid Price /oz:</font><br><br>
		</font>
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="8"><img src="img/left_c.gif" width="8" height="36"></td>
			<td bgcolor="E8E8E8" width="50%">
			<div align="right">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"><b>USD</b></font>
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2280.136&nbsp;&nbsp;
						<font color="#CC0000">|</font>
					</font>
				</font>
			</div>
			</td>
			<td bgcolor="E8E8E8" width="50%">
				<font face="Arial, Helvetica, sans-serif" size="1">
					<font face="Verdana, Arial, Helvetica, sans-serif" color="#CC0000">|</font>
					<font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;<b>EUR</b></font>
					<font face="Arial, Helvetica, sans-serif" size="1">
						<font face="Verdana, Arial, Helvetica, sans-serif"> &gt;&gt; </font>
					</font>
					<font face="Verdana, Arial, Helvetica, sans-serif" size="1">2128.507</font>
				</font>
			</td>
			<td width="8" valign="middle">
			<div align="right">
				<img src="img/right_c.gif" width="8" height="36">
			</div>
			</td>
		</tr>
		</table>
		<br><img src="img/rates/21.png" width="265" height="130">
	</td>
</tr>
</table>
<br>
<div style="width:270px">
<font face="Arial, Helvetica, sans-serif" size="3"><b>Genel Anket</b></font>
<font face="Arial, Helvetica, sans-serif" size="2"><br><br>
Perfect Money: Hizmet Kalitesi ve Ürünler<br><br>
<a href="statistics.php">Sonuçları gerçek-zamanda görüntüle</a> &raquo;</font>
</div>
</font> 
            <div align="left"><br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><div class="arabic">
<div class="a1">
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Sık Sorulan Sorular</b></font> <br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b>
<br>
</b></font>
<table width="265" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Kur değiştirme servisiyoluyla para çekmenin ücreti nedir?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">Her kur değiştirme servissağlayıcısı kendi ücretini belirler. Bireysel web sitelerinde onlar hakkında daha fazla bilgi sahibi olabilirsiniz.</font><br><br>
    </td>
</tr>
<tr>
	<td>
    <p class="txt"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><font face="Arial, Helvetica, sans-serif" size="2" color="B01111">Krediler için en düşük ve en yüksek faiz oranları nelerdir?</font><font face="Arial, Helvetica, sans-serif" size="2"><br>
    <br>
    </font>
	<font color="#000000" face="Arial, Helvetica, sans-serif" size="2">En düşük faiz oranı %0.5’tir. En yüksek faiz oranı %200’dür. Ancak unutmamalısınız ki faiz oranınız ne kadar düşük olursa kullanıcıları cezbetme şansınız ve iyi geri bildirim alma şansınız o kadar yüksek olur.</font><br><br>
    </td>
</tr>
<tr>
  <td>
  <p><font face="Arial, Helvetica, sans-serif">
<font size="2"><a href="faq.php">SSS detayı</a> &raquo;</font></font></p>
<br><br>
  </td>
</tr>
</table>
</div>
</div>
<br>
<br>
<font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FF0000"><b> 
              </b><img src="img/blank.gif" width="290" height="26"></font></div>
          </td>
          <td valign="top">
 
<script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><p><font face="Arial, Helvetica, sans-serif" size="3"><b><br> <font size="4" color="#F01010">Perfect Money</font><font size="4"> Özellikleri</font></b></font></p>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="300" valign="top"><p>Perfect Money sistem araçlarının en müşterileri arasında yerleşim için    uygun bir araçlar paketi ile çalışır. </p>
      <p>Iş hacmi birikiminin fiat değeri, kayıt dönemi ile birlikte sistemin fırsatları    arasında bir nesne olarak kullanılmaz.</p>
      <p>Perfect Money’in her müşterisi çok önemlidir ve hizmet verirken herhangi    bir ayrım yapmazlar. <br>
      </p>
    </td>
    <td valign="top">
      <div align="center"><img src="http://localhost/img/features.jpg"> </div>
    </td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Müşteri kişisel durumu</b></font></p>
<p class="txt">Perfect Money işlemleri kolaylaştırmak için  kullanıcılarını kayıt bitiminde sistem tarafından üç farklı grupa ayırır: <br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td><b><font color="B01111">Normal</font></b> <br>
      Tüm yeni kayıtlı müşteriler sistem kullanımına ilişkin herhangi bir sınırlama    olmadan sistemi kullanırlar.<br>
      <br>
      <b><font color="B01111">Premium</font></b><br>
      Müşteri 1 yıldan fazla aktif olmalıdır veya iş hacmi bakiyesi ile belirgin    olması gerekir. Müşteri hizmetleri servisine normal hesaptan Primli hesaba    yükseltmek için başvuruda bulunmalıdır. Primli hesap müşterisi normal hesap    müşterilerinden daha az komisyon ücreti ödemek hakkını elde eder.<br>
      <br>
      <b><font color="B01111">Partner</font></b> <br>
      Perfect Money yönetimi ortakları(partnerleri) kendileri atarlar. İnternet    üzerinden B2B ile işletme ödemelerini en iyi hale getirmektedir.</td>
  </tr>
</table>
<p><font face="Arial, Helvetica, sans-serif" size="3"><b>Müşteri doğrulama durumu</b></font></p>
<p class="txt">Müşterilerimizi resmi bir kimlik dokümanı yükleyerek ve bir cep telefonu vererek basit bir doğrulama yapmaları için teşvik ediyoruz. Onaylanmış hesaplar tam işlevselliğe sahip olurlar. Bunun faydalarından bazıları:<br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td>Daha düşük kesintiler<br><br>
		İlave güvenlik seçenekleri<br><br>
		Diğer müşteriler tarafından daha yüksek bir güven<br><br>
		Eğer şifrenizi unutursanız veya herhangi bir sebeple ulaşamıyorsanız, kolay hesap geri yüklemesi<br><br>
      </td>
  </tr>
</table>
<br>
<p>Hesabınızın alt-gruplarını amaç ve öngörülen ciroya göre seçebilirsiniz:  Kişisel, bireysel kullanım veya İş için. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Hesap  birikimleri için rahat ve kolay yöntemler: </b></font><br>
  <br>
  Perfect Money sistemi kullanımında, müşteriler, ödemelerinde uygun ve kullanımı  kolay P2P ve P2B araçlarına sahiptir. Internette Ürün ve hizmetler için Ödeme  PM müşterileri için basit bir işlem haline döner ki zar zor 1 saniyeyi aşar  Şimdi Perfect Money için gerçek veya sanal banknot değişimi bir sorun değildir.<br>
  <br>
  <b>Sistemde para transferi işlemleri aşağıdaki gibidir:</b><br>
  <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Banka yolu ile gönderme</font></b> <br>
      Hesabınıza para göndermek için en elverişli yoldur. PM hesabında bu işlemin    hazırlanması 30 saniye de gerçekleşir.<br>
        <br>
        <b><font color="B01111">Elektronik kur</font> </b><br>
        Perfect Money sistemi önemli sayıda e-para ve bu hesabın fonu sayesinde    yapılabilir, WebMoney e-altın, pecunix gibi e-para ile çalışır. Bu tür    işlemler otomatik olarak bu ödeme sistemlerinin tüccarları ile    gerçekleştirilebilir.<br>
        <br>
        <b><font color="B01111">Ortak(Partner) Değiştiricileri </font></b><br>
        Hesabınıza para göndermek için başka bir yol gösterir. Perfect Money’in para    değiştirici ortaklarının(partnerleri)ortak para birimleri ispatlanmış güvenli    bir çalışma içinde para alışverişini sağlar.<br>
        <br>
        <b><font color="B01111">Kripto Para Birimi Depolama</font></b><br>
        Belirli kripto para birimlerindeki Perfect Money hesapları bir varlığı saklamak için mükemmel bir imkandır. Kripto para cüzdanlarının aksine, Perfect Money hesapları kurmak için veya güvenliğini sağlamak için teknik uzmanlık gerektirmez. Perfect Money hesaplarında bir varlığı saklamak kripto paranın kalıcı olarak kaybedilmesine sonuç verecek örneğin şifre kaybetme/hırsızlık gibi cüzdan ile ilgili risklerden kurtulmanızı sağlar. Perfect Money B hesabınıza parayı yatırın gerisini sistem halledecektir.</p>
    </td>
  </tr>
</table>
<br>
<br>
<p>Perfect Money müşterilerine kolaylık için her tür-döviz hesabı finansman imkanı  sağlar. Bu durumda, Perfect Money en karlı oranda işlemleri ivedilikle  yönetecektir. </p>
<p>Perfect Money sisteminin her müşteri minimum hesap bakiyesi için hesabına  aylık faiz ekler. <br />
  Siz uyurken bile paranız çalışıyor. </p>
<p>Müşteri hesap bakiyesini harcamamış ise olası parasını bu araçları  kullanarak hesabından çekebilir veya yatırabilir.</p>
<p>Perfect Money müşterileri banka transferi kullanarak veya kur  değiştiricileri ile herhangi bir para biriminde paralarını kısa zaman içinde  daima alabilir. <br>
  <br>
  <font face="Arial, Helvetica, sans-serif" size="3"><b>Fonksiyonellik</b></font><br>
  <br>
 Müşteriler için olan ticari faaliyetleri İnternet bağlantısı ile Perfect Money  sistemi ile bağlı yerleşim yerleri uygun işlevsel araçların, özel bir devletin  ihtiyaçlarını gözönüne alarak, PM finansör ile modern IT işletme tarafından  geliştirilen iş çözümleri de dahil olmak üzere iyi bir paket sunar. <br>
</p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"><strong><font color="#990000">Hesabınız için raporları rahat ve    detaylı basitleştirmek</font></strong><br>
        Yeni mali operasyonları görüntülemek grafikler ve gerçek zamanlı beyan hakkında bilgi alın. </p>
      <p><strong><font color="#990000">Sistem otomatik tekrarlı ödeme kurar</font></strong><br>
      Bu araç, kuruluşun, düzenli aylık giderleri için tasarlanmıştır ve otomatik    modda ödeme sağlar. </p>
      <p><strong><font color="#990000">Perfect Money tüzel müşterilerinin bireysel Destek Merkezi</font></strong><br>
      Müşteri online destek merkezimiz uzmanları 24\7\365 modunda hazır ve sizin    ilginç sorularınız için cevap vermeye çalışacaklar. </p>
      <p><strong><font color="#990000">Mükemmel API tüccarı</font></strong><br>
        Analogların meydana çıkması diğer ödeme sistemleri arasında işlevsellik,    güvenilirlik ve güvenlik kriterleri üzerinde önümüzdeki birkaç yıl içinde    mümkün olası değildir. Perfect Money mühendisleri böylesi araçları, online    ürün, hizmet veya satış işlemi düzenlemek için maksimum kolaylık, güvenlik ve    içerik erişimi veya ürün satış projeleri yaratmıştır.<br>
    </p> <p><strong><font color="#990000">Kripto Para Depolama</font></strong><br>
        Perfect Money müşterilerimize güvenli bir Bitcoin varlıklarını gönderme, alma ve depolama imkanı sağlar. Bitcoin işlemlerini gerçekleştirmek için güvenli ve güvenilir bir platform sunuyoruz. Herhangi bir karmaşık ya da uygunsuz Bitcoin cüzdanı indirmenize gerek yoktur.<br>
    </p></td>
  </tr>
</table>
<br>
<br>
<font face="Arial, Helvetica, sans-serif" size="3"><b>Güvenlik</b></font><br>
<br>
<p>Perfect Money güvenlik sistemi uzmanları bilimsel araştırma grubu tarafından  bilgi ve finans güvenlik alanında geliştirilmiştir. PM mühendisleri  müşterilerinin güvenli kullanımları için ideal bir araç yaratmayı başarmıştır: </p>
<p>- Perfect Money analistlerinin mali alanda büyük miktarda uzun vadeli  deneyimleri;<br />
  - Müşterinin kimlik doğrulamasının yapay aklın teknolojileri; <br />
  - Güvenlik düzeyini online izleme ve Müşteri koruması Perfect Money güvenlik  servisi tarafından gerçekleştirilir.<br>
  <br>
  <b><strong>PM Müşteri Güvenlik araçları, aşağıdakileri kapsar</strong>:</b></p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="20" background="img/bgt.gif">&nbsp;</td>
    <td> <p class="txt"> <b><font color="B01111">Kimlik Kontrol</font></b> <br>
      Bu araç PM hesabında müşteri belirlenmesi için kullanılır. Bu araç Perfect    Money için müşteriyi,canlı olarak karşısında göstermeyebilir, ama olası    bilgisayar hesabı girmek için kullanılan tanıtımı sağlayan yapay olarak göz    önünde tutan bir türdür. Bu durumda Müşterinin IP adresiyle ağdan veya alt    ağlardan kimlik doğrulama yapmak, hesap sahibinin sistemi ile ilgili olmayan    IP adresine sahipse engellemek, bunu anlamk için kayıt sırasında e-postasına    ek bir güvenlik kodu göndererek gerçekleştirilir Değiştir IP bireysel Perfect    Money Destek Merkezi aracılığıyla IP değişikliği yapılır. <br>
        <br>
        <b><font color="B01111">KMS Doğrulama</font></b><br>
        Bu sistem müşteri hesabı ile müşterinin cep telefonu numarası arasında    mantıksal bir bağlantı için kullanılır. Sistem, gerçek hesap sahibinin cep    numarasına doğrulama kodu gönderir. KMS sistemi çok mükemmel ve gövenilir bir    kullanıcı koruma yöntemidir. Hangi sistem gerçek hesap sahibinin belirlenmesi    için onay kodunu gönderir, hesaba izinsiz girişte harcanan zaman tüm kod    değişimlerinde ve böylece hesabına girişte son derece kısa ve işlem kırma    için yetersizdir. <br>
        <br>
        <b><font color="B01111">KodKart Koruma</font></b> <br>
        Bu yöntemde, müşteri bir kart ile grafik resimli kod e-posta adresinize    gönderilir. Sistem işlem doğrulaması için rastgele bir araştırma amaçlı    kartan belirli bir kod müşteriye gönderir. KodKart, dünyanın tanınmış mali    kurumlarının büyük çoğunluğunda, işlemlerde onay için uygun ve güvenilir    koruma ölçüsü olduğunu göstermiştir. <br>
    </td>
  </tr>
</table>
<br>
<br>
Perfect Money ödeme sisteminin demokratik yaklaşımı her müşteri kendi hesabı  için hangi güvenlik ayarlarını kullanmak isterse, bağımsız karar vererek  kullanmasını sağlar. PM’in her müşterisi, kendisi için uygun olarak seçeceği  hesap koruma yöntemlerini ve elverişli kullanımı tercih edebilir.
<p><strong>Herhangi bir Müşteri için Perfect Money sistemi, liberaldir</strong></p>
<p>Biz maliye kontrolü için en etkili araçlar oluşturduk ve müşterilerin,  kendi para politikalarını bağımsız oluşturmalarını umuyoruz. Her müşteri bizim  için çok önemlidir ve aslında o kesin olarak Perfect Money’yi seçmiştir ve bize  yetki vermiştir, onay olarak, maksimum fırsatları hiçbir korku olmadan bloke  etmek ve hesaplarının kontrolü için bizi tercih etmiştir. </p>
<p>Perfect Money güvenlik sisteminin görevi,müşteri maliyesinin yüksek  seviyede güvenlik sisteminin yapılanması için maksimum fırsatları sağlamaktır.  Perfect Money bilimsel araştırma departmanı ile güvenlik sistemi birlikte,  sadece sürekli yeni güvenlik sistemleri geliştirmektedir, aynı zamanda sistemin  sayısal yapılandırması için gelecekte bu bilgilenme, olası tüm sistem kırma  yöntemleri için uzmanlaşmış grup yönetimine sahiptir.</p>
<p>Perfect Money kendi müşterileri için imkanları oluşturmuştur sadece küçük  bir kapı etrafında gizli binlerce finansal kurum ekranın bu tarafında,  müşterileri için oluşturmuştur. Yani, uzun süre bu kapının açık kalması için  Perfect Money evrenini keşfetmek gerekir.<br>
</p>
<p align="center"><a href="https://www.perfectmoney.com/signup.html"><img src="http://localhost/img/b1.gif" alt="Sign up to Perfect Money - payment system of the Future!" border="0"></a></p>
<br>
<br><br>
 
          </td>
        </tr>
      </table>
          </td>
          <td width="44" valign="middle"><img src="img/blank.gif" width="44" height="26"></td>
        </tr>
      </table> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td height="2"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="1%"><img src="img/left2.gif" width="19" height="6"></td>
          <td width="98%" bgcolor="C61313"><img src="img/blank.gif" width="1" height="1"></td>
          <td width="1%" bgcolor="B01111" valign="middle"><img src="img/right2.gif" width="19" height="6"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="341" bgcolor="#ffffff" valign="middle" height="56"> 
      <div align="left">&nbsp;&nbsp;
<!--
<a href="https://itunes.apple.com/gb/app/perfect-money/id653398845?mt=8" target="_blank"><img src="mobile/ios_app_store.png" width="155" height="54"></a>
<a href="https://play.google.com/store/apps/details?id=com.touchin.perfectmoney&hl=en" target="_blank"><img src="mobile/googleplayicon.png" width="155" height="54"></a>
-->

</div>
    </td>
    <td bgcolor="#ffffff" valign="top" height="56">
      <table width="100%" border="0" cellspacing="5" cellpadding="5" align="right">
        <tr>
          <td> 
            <div align="right"><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script>Perfect Money ile P2P ve B2B ödemelerini yapın&nbsp;<br>&copy;
              2007-2024 Startup Smart Development. All rights reserved.&nbsp;<br>
							Licensed payment service provider authorized by The Autonomous Island of Anjouan with registration number 15559. Financial license L 15559 / SSD.<br>
              <script type="text/javascript">

            function getExpDate(days, hours, minutes) {
            var expDate = new Date();
            if (typeof days == "number" && typeof hours == "number" && typeof hours == "number") {
              expDate.setDate(expDate.getDate() + parseInt(days));
              expDate.setHours(expDate.getHours() + parseInt(hours));
              expDate.setMinutes(expDate.getMinutes() + parseInt(minutes));
              return expDate.toGMTString();
            }
          }

          function setCookie(name, value, expires, path, domain, secure) {
            document.cookie = name + "=" + escape (value) +
              ((expires) ? "; expires=" + expires : "") +
              ((path) ? "; path=" + path : "") +
              ((domain) ? "; domain=" + domain : "") +
              ((secure) ? "; secure" : "");
          }
  
					setCookie("lang", "tr_TR", getExpDate(30, 0, 0), "/");

          </script><a href="promotion_materials.php"><font color="#b50b0b">Affiliate Program</font></a>
| <a href="legal.php"><font color="#b50b0b"></font></a><a href="sample-api.php"><font color="#b50b0b">Perfect
Money API</font></a> | <a href="legal.php"><font color="#b50b0b">Yasal not</font></a>
| <a href="privacy.php"><font color="#b50b0b">Gizlilik politikası</font></a><small><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="tos.html"><font color="#b50b0b">Kullanım koşulları</font></a></font></small> <font face="Verdana, Arial, Helvetica, sans-serif" size="1">
| <a href="aml.html"><font color="#b50b0b">AML</font></a></font></small>&nbsp;<br><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><a href="sitemap.html"><font color="#b50b0b">Site Map</font></a></font></font></small>
</small>


					</div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>